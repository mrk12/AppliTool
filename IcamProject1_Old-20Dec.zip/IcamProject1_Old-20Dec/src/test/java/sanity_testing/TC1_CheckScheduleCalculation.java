package sanity_testing;

import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Set;

import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.digital.itops.testng.PDFReporter;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.IcamExcelUtils;
import com.ge.icam.common.page.LoginObjects;

public class TC1_CheckScheduleCalculation{
	@Test(priority = 1,enabled=true)
	@Documentation(step = "verify the schedule is calculated", expected = "Successully scheduled")
	@FailureMessage("Schedule is not completed")
			public void calculate_schedule() throws Throwable {		      
				LoginObjects.schedule();
				GenericFunctions.checkAlert();
				LoginObjects.Validate_Table();
				
			}
}
