package sanity_testing;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.digital.itops.testng.PDFReporter;

import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;

import com.ge.icam.common.page.LoginObjects;

public class TC7_CheckRepairReplaceReport {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Check if RRR is coming properly", expected = "RRR is coming properly")
	@FailureMessage("RRR is not coming properly")

	public void checkRepairReplaceReport() throws Throwable {

		// Calling Common
		//Common.validate_user_logged_into_Applicaction();

		GenericFunctions.staticWait(3);

		// Calculate Schedule if it is in Red Color

		if (LoginObjects.checkRedSchedule()) {
			LoginObjects.schedule();
			GenericFunctions.staticWait(3);
		}

		// Calculate Finance if it is in Red Color

		if (LoginObjects.checkRedFinance()) {
			LoginObjects.finance();

			GenericFunctions.driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);

			GenericFunctions.staticWait(3);
		}

		// Calculate RRR
		LoginObjects.repairReplaceReport();

		GenericFunctions.staticWait(3);
		PDFReporter.takeExtraScreenshot();
		System.out.println("Taking Screenshot");

	}

}
