package sanity_testing;

import org.testng.annotations.Test;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.digital.itops.testng.PDFReporter;
import com.ge.digital.itops.webdriver.BaseWebDriver;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC2_CheckFinanceCalculation{
	
	@Test(priority = 1,enabled=true)
	@Documentation(step = "verify the finance is calculated", expected = "Successfully calculated finance")
	@FailureMessage("finance is not calculated")
		public static void calculate_finance() throws Throwable {
		   // Common.validate_user_logged_into_Applicaction();
			LoginObjects.finance();
			GenericFunctions.checkAlert();
			GenericFunctions.staticWait(60);
			LoginObjects.Pricing();
			System.out.println("pricing screen appeared and it is in bold");
      		PDFReporter.takeExtraScreenshot();
		}
}
