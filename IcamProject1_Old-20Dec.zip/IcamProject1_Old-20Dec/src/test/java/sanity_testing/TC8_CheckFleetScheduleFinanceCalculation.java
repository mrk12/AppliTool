package sanity_testing;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.exceptions.TimeoutException;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;
import java.util.Iterator;
import java.util.Set;

public class TC8_CheckFleetScheduleFinanceCalculation{
	
	@Test(priority = 1,enabled=true)
	@Documentation(step = "verify the fleet is calculated", expected = "Successully calculated fleet")
	@FailureMessage("fleet is not calculated")
	public void fleet() throws Throwable {
		
		//Common_8.validate_user_logged_into_Applicaction();
		//click on the inventory
		LoginObjects.Inventory();
		GenericFunctions.checkAlert();
		GenericFunctions.staticWait(3);
		//click on managefleets
		LoginObjects.ManageFleets();
		GenericFunctions.checkAlert();
		String currentWindow=GenericFunctions.driver.getWindowHandle(); 
		LoginObjects.SaveAsFleet();
		
		Set<String> set =GenericFunctions.driver.getWindowHandles();
		Iterator<String> itr= set.iterator();
		 
		 
		 GenericFunctions.staticWait(1);
		 String Window2="";
			
try {
	while(itr.hasNext()){
		 System.out.println("True");
	  Window2=itr.next();
	}
if(!currentWindow.equals(Window2)){
	GenericFunctions.driver.switchTo().window(Window2); 
		 System.out.println("True");
	GenericFunctions.staticWait(20);
	//Entering data in fleet
	WebElement fleet = GenericFunctions.driver.findElement(By.xpath("/html/body/form/table/tbody/tr/td/table/tbody/tr[2]/td/table/tbody/tr[2]/td[2]/input"));
	fleet.sendKeys("Text");
		}
			//selecting fleet from dropdown
			LoginObjects.selectfleet();
			
			LoginObjects.SaveAsNewFleet();
			BrowserAction.closeActiveWindow();
}
finally {
	 System.out.println("false");
	}
	 GenericFunctions.driver.switchTo().window(currentWindow);
		
			LoginObjects.schedule();			
			LoginObjects.finance();	 
	}
	}
