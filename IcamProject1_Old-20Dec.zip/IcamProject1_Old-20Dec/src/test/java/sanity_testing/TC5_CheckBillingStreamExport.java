package sanity_testing;

import java.util.concurrent.TimeUnit;

import org.testng.annotations.Test;

import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC5_CheckBillingStreamExport{

	@Test(priority = 1, enabled = true)
	@Documentation(step = "verify the Schedule and finance are calculated", expected = "Successully calculated Schedule and finance")
	@FailureMessage("Schedule or finance is not calculated")

	public void Billing() throws Throwable {

		//Common.validate_user_logged_into_Applicaction();
		LoginObjects.checkRedSchedule();
		if (LoginObjects.checkRedSchedule()) {
			LoginObjects.schedule();
			GenericFunctions.staticWait(3);
		}

		// Calculate Finance if it is in Red Color

		if (LoginObjects.checkRedFinance()) {
			LoginObjects.finance();

			GenericFunctions.driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);

			GenericFunctions.staticWait(3);
		}

		LoginObjects.Billing();
		GenericFunctions.checkAlert();
		GenericFunctions.staticWait(60);
		LoginObjects.ActiveVersion();

	}
}