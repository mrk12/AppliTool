package sanity_testing;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.digital.itops.testng.PDFReporter;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC4_CheckBillinStreamOpening{
	@Test(priority = 1,enabled=true)
	@Documentation(step = "verify the billing stream is opening", expected = "billing stream opened successfully")
	@FailureMessage("failed to open billing")
	public void open_billing() throws Throwable {
		//Common.validate_user_logged_into_Applicaction();
		
		// Calculate Schedule if it is in Red Color

		if (LoginObjects.checkRedSchedule()) {
			LoginObjects.schedule();
			GenericFunctions.staticWait(3);
		}

		// Calculate Finance if it is in Red Color

		if (LoginObjects.checkRedFinance()) {
			LoginObjects.finance();

			GenericFunctions.driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);

			GenericFunctions.staticWait(3);
		}
		
		
		
		LoginObjects.Billing();
		GenericFunctions.checkAlert();
		GenericFunctions.staticWait(60);
		LoginObjects.ActiveVersion();
		LoginObjects.Validate_Billing();
		PDFReporter.takeExtraScreenshot();
}

}

