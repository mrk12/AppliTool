package sanity_testing;

import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.digital.itops.testng.PDFReporter;
import com.ge.digital.itops.webdriver.BaseWebDriver;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC3_CheckCR_Report{

	@Test(priority = 1, enabled = true)
	@Documentation(step = "verify the CR report is pulled", expected = "CR report pulled successfully")
	@FailureMessage("failed to pull CR report")

	public void pull_CR() throws Throwable {
		//Common.validate_user_logged_into_Applicaction();
		
		// Calculate Schedule if it is in Red Color

		if (LoginObjects.checkRedSchedule()) {
			LoginObjects.schedule();
			GenericFunctions.staticWait(3);
		}

		// Calculate Finance if it is in Red Color

		if (LoginObjects.checkRedFinance()) {
			LoginObjects.finance();

			GenericFunctions.driver.manage().timeouts().implicitlyWait(600, TimeUnit.SECONDS);

			GenericFunctions.staticWait(3);
		}
	
		LoginObjects.report();	
		BrowserAction.maximizeCurrentWindow();
		String currentWindow = GenericFunctions.driver.getWindowHandle();
		Set<String> set = GenericFunctions.driver.getWindowHandles();
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			String Window2 = itr.next();
			if (!currentWindow.equals(Window2)) {
				GenericFunctions.driver.switchTo().window(Window2);
				BrowserAction.click(LoginPageObjects.Download_XPATH);
				System.out.println("report is downloading");
				GenericFunctions.staticWait(5);
				new Actions(GenericFunctions.driver).sendKeys(Keys.chord(Keys.ENTER)).perform();
				BrowserAction.closeActiveWindow();
				PDFReporter.takeExtraScreenshot();
			}
		}
	}
}