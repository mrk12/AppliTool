package Regression_testing.PGS;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.By;

import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.IcamExcelUtils;
import com.ge.icam.common.page.LoginObjects;

public class Common_17 extends BaseTest {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Verify user successfully logged in into system", expected = "Successully logged IN")
	@FailureMessage("User didn't login into application")
	public static void validate_user_logged_into_Applicaction() throws Throwable {
		String user = IcamExcelUtils.storeUserCredential("user1", "user");
		String password = IcamExcelUtils.storeUserCredential("user1", "pswd");
		System.out.println(user);
		System.out.println("*********");
		
		LoginObjects.loginIntoApplication_via_SSO(user, password);
		
		LoginObjects.selectPGSBusinessList();	
		LoginObjects.selectrolelist();
		LoginObjects.selectButton();
		

		GenericFunctions.checkAlert();
		System.out.println("popup got handled");
		String modelid_value = IcamExcelUtils.storeTestData_FromGenericTestData_sheet_BasedOn_key("Regression_TC_5-6_17-18_20_PGS");
		System.out.println(modelid_value);
		LoginObjects.modelid(modelid_value);
		
		LoginObjects.versiontypeBillingUSER174();
			
		GenericFunctions.checkAlert();
		LoginObjects.new_version();
		BrowserAction.maximizeCurrentWindow();
		String currentWindow = driver.getWindowHandle();
		Set<String> set = driver.getWindowHandles();
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			String Window2 = itr.next();
			if (!currentWindow.equals(Window2)) {
				driver.switchTo().window(Window2);
				GenericFunctions.staticWait(5);

				// GenericFunctions.selectValueFromDropdownByLabelID("lstSaveAsVersionTypID","RETAIN38");
				Select s = new Select(driver.findElement(By.id("lstSaveAsVersionTypID")));
				s.selectByIndex(2);
				LoginObjects.enterversion_description("test");
				LoginObjects.saveversion();

			}
		}
		driver.switchTo().window(currentWindow);
		GenericFunctions.checkAlert();
		GenericFunctions.staticWait(2);

		System.out.println("Alert Clicked");
	}
}
