package Regression_testing;

import org.testng.annotations.Test;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;



public class TC_10_CatAdminCatalogDownload {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "category admin catalog download", expected = "downloaded successfully")
	@FailureMessage("failed downloading")
	public void catalogdownload() throws Throwable {
		try {
		LoginObjects.CatalogDownload();
		}
  
	finally {
		GenericFunctions.staticWait(6000);
	}
}}
