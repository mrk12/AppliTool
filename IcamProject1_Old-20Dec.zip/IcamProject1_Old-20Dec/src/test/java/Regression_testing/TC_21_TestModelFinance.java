package Regression_testing;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.Test;

import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC_21_TestModelFinance{
	
	@Test(priority = 1,enabled=true)
	@Documentation(step = "verify the model finance", expected = "Successully tested model finance")
	@FailureMessage("failed")
	public void modelfinance() throws Throwable {
		
		String Filename1="ExportFinance";
		String Filename2="ExportFinance";
		LoginPageObjects  DownloadReportXpath= LoginPageObjects.Export_Finance_XPATH;
		GenericFunctions.staticWait(3);
		LoginObjects.Finance_tab();
		
		String FileDownload_Path_01 = LoginObjects.download_and_ReturnFilePath(DownloadReportXpath,Filename1);
		GenericFunctions.staticWait(20);
		LoginObjects.SaveChanges();
		GenericFunctions.checkAlert();
		
		String currentWindow = GenericFunctions.driver.getWindowHandle();
		Set<String> set = GenericFunctions.driver.getWindowHandles();
		GenericFunctions.driver.switchTo().window(currentWindow);
		
		LoginObjects.schedule();
		LoginObjects.finance();

		LoginObjects.FinancialScreen();
		
		String FileDownload_Path_02 = LoginObjects.download_and_ReturnFilePath_MultipleFiles(DownloadReportXpath,Filename2);
		GenericFunctions.staticWait(2);
		LoginObjects.ExcelCompare(FileDownload_Path_01,FileDownload_Path_02);

}
}
