package Regression_testing;

import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.IcamExcelUtils;
import com.ge.icam.common.page.LoginObjects;



public class TC_09_EOTETermLengthTestcausedbyEvents {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "EOTETermLengthTestcausedbyFFH", expected = "EOTETermLengthTestcausedbyFFH is successful")
	@FailureMessage("failed to open billing")
	public void EOTETermLengthTestcausedbyFFH() throws Throwable {

		BrowserAction.click(LoginPageObjects.schedule_Tab_XPATH);
		
		List<String> List1 = new ArrayList<String>();
		List<String> List2 = new ArrayList<String>();
		
		List<WebElement> rows1 =  GenericFunctions.driver.findElements(By.xpath("//table[@id='eventData']//tr"));
	
		int Row_count1 = rows1.size();
		for (int i = 2; i<= Row_count1; i++) 
		{
			
		   List<WebElement> columns =  GenericFunctions.driver.findElements(By.xpath("//table[@id='eventData']//tr["+i+"]//td/div/img"));
		   int Col_Count = columns.size();
			
		   for(int j =0;j<Col_Count;j++)
			    {
			
			     int Version = 1;
			     String Event_Details = GenericFunctions.driver.findElements(By.xpath("//table[@id='eventData']//tr["+i+"]//td/div/img")).get(j).getAttribute("alt");
			   
			    // System.out.println("the event name is " + Event_Details);
			     if (Event_Details.contains("EOTE") )
			     {
				   System.out.println("the number "+i+" EOTE event detail is "+Event_Details );
				   List1.add(Event_Details);
			     }
			      Version++;
			
			     }
	      }
		
		LoginObjects.schedule();
		
		List<WebElement> rows2 =  GenericFunctions.driver.findElements(By.xpath("//table[@id='eventData']//tr"));
		
		int Row_count2 = rows2.size();
		for (int i = 2; i<= Row_count2; i++) 
		{
			
		   List<WebElement> columns =  GenericFunctions.driver.findElements(By.xpath("//table[@id='eventData']//tr["+i+"]//td/div/img"));
		   int Col_Count = columns.size();
			
		   for(int j =0;j<Col_Count;j++)
			    {
			
			     int Version = 1;
			     String Event_Details = GenericFunctions.driver.findElements(By.xpath("//table[@id='eventData']//tr["+i+"]//td/div/img")).get(j).getAttribute("alt");
			   
			     if (Event_Details.contains("EOTE") )
			     {
				   System.out.println("the number "+i+" EOTE event detail is "+Event_Details );
				   List2.add(Event_Details);
			     }
			      Version++;
			
			     }
	      }
		
		if(List1.equals(List2))
		{
			System.out.println("the 2 lists are same and the EOTE event deatils before schedule and after schedule are same");
		}
		else
		{
			System.out.println("the 2 lists are unequal");
		}
		
}
}