package Regression_testing;



import org.testng.annotations.Test;

import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.digital.itops.testng.PDFReporter;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC_24_ModelCreationAndConfiguration {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Model creation and configuration", expected = "Model successfully created and configured")
	@FailureMessage("Failed to create model")
	public void check_pricing_data() throws Throwable {

		
			// Create Blank Model
			LoginObjects.createModel();

			LoginObjects.AddSite();

			LoginObjects.addEquipment();

			LoginObjects.configurePartKits();

			LoginObjects.savePartKits();

			// Calculate Schedule
			LoginObjects.schedule();
			GenericFunctions.staticWait(3);

			// Calculate Finance
			LoginObjects.finance();
			GenericFunctions.staticWait(3);
			
			//Check if schedule and finance calculated
			if (!LoginObjects.checkRedSchedule()) {
				System.out.println("Scheduled is not in red color, Hence calculated");
				if(!LoginObjects.checkRedFinance()) {
					System.out.println("Finance is not in red color, Hence calculated");
				}				
			}

			System.out.println("Test case passed");

			PDFReporter.takeExtraScreenshot();
			System.out.println("Taking Screenshot");
		
	}
}
