package Regression_testing;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.ge.digital.itops.exceptions.TimeoutException;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;
import java.util.Iterator;
import java.util.Set;

public class TC_30_FleetLevelReliablity{
	
	@Test(priority = 1,enabled=true)
	@Documentation(step = "verify the fleet is calculated", expected = "Successully calculated fleet")
	@FailureMessage("fleet is not calculated")
	public void fleet() throws Throwable {
		
		String Filename1="RepairReplace";
		String Filename2="RepairReplace";
		LoginPageObjects  DownloadReportXpath= LoginPageObjects.Excel_all_XPATH;
		
		LoginObjects.FleetRepairReport();
		
		String FileDownload_Path_01 = LoginObjects.download_and_ReturnFilePath(DownloadReportXpath,Filename1);
		
		String currentWindow = GenericFunctions.driver.getWindowHandle();
		Set<String> set = GenericFunctions.driver.getWindowHandles();
		GenericFunctions.driver.switchTo().window(currentWindow);
		
		LoginObjects.schedule();
		
		LoginObjects.finance();
		
		LoginObjects.FleetReport();
		LoginObjects.FleetRepairReport();
		
		String FileDownload_Path_02 = LoginObjects.download_and_ReturnFilePath_MultipleFiles(DownloadReportXpath,Filename2);
		
		GenericFunctions.staticWait(2);
		
		LoginObjects.ExcelCompare(FileDownload_Path_01,FileDownload_Path_02);
		
}
}
