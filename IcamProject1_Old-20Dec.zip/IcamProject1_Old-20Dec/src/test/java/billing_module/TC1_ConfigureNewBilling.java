package billing_module;

import org.junit.AfterClass;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;

import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC1_ConfigureNewBilling {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "verify the billing stream is opening", expected = "billing stream opened successfully")
	@FailureMessage("failed to open billing")
	public void open_billing() throws Throwable {

		LoginObjects.Billing();
		GenericFunctions.checkAlert();
		LoginObjects.Billing_ContractLevel_Configure();
		GenericFunctions.staticWait(5);
		LoginObjects.Validate_Billing();
	}

}
