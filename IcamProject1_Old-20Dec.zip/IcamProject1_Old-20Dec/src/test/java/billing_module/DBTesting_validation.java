package billing_module;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.ProxySettings;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.StdoutLogHandler;
import com.applitools.eyes.TestResults;
import com.applitools.eyes.selenium.Eyes;
import com.applitools.eyes.selenium.StitchMode;

public class DBTesting_validation {

	  BatchInfo batch = new BatchInfo("Tableau");
	
	//Eyes eyes1 = new Eyes();
      public  void firstTablueTest() {
        //DriverUtils.getPathForChromeDriverFromMachine();
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\503114663\\Documents\\AutomationUseCase\\src\\test\\resources\\Config\\chromedriver.exe"); 
    	WebDriver driver = new ChromeDriver();

        try {
        	
           LoginToGE(driver,  "503088227", "Igate@123ge");
            Thread.sleep(10000);

        } catch (Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
        } finally {
           
        }
    }
    
      private Eyes getEyes() {
    	  Eyes eyes = new Eyes();
          eyes.setBatch(batch);
       //   eyes.setLogHandler(new StdoutLogHandler(true));
          eyes.setForceFullPageScreenshot(true);
          eyes.setStitchMode(StitchMode.CSS);
          System.out.println("Testing");
          //New API Key
          eyes.setApiKey("T98Bwp8nW6KPGrQTpdVY9102QAWqdIWbgEy991LO6fBCG54110"); 
          eyes.setProxy(new ProxySettings("http://PITC-Zscaler-Americas-Cincinnati3PR.proxy.corporate.ge.com:80")); 
          return eyes;
      }
    public void LoginToGE(WebDriver driver, String UserName, String Password) throws InterruptedException {
    	//Thread.sleep(5000);
    	
    	   Eyes eyes = getEyes();
    	try {
    	//BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Fleet_dropdwn_XPATH);
    	driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
        driver.get("https://tableau.cloud.digital.ge.com/#/workbooks/24340/views");
    	eyes.open(driver, "Tableau", "Login", new RectangleSize(800,500));
    	driver.findElement(By.id("username")).sendKeys(UserName);
    	Thread.sleep(2000);
    	driver.findElement(By.id("password")).sendKeys(Password);
    	//Thread.sleep(5000);
    	driver.findElement(By.id("submitFrm")).click();
    	Thread.sleep(8000);
    	eyes.checkWindow("After login");
    	TestResults testResults = eyes.close(false);
        System.out.println("Visual Test results: " + testResults);
        
      //Test Case 1 -Validation of ECR Report
        eyes = getEyes();
        eyes.open(driver, "Tableau", "Validation of ECR Report", new RectangleSize(800,500));    	
    	driver.findElement(By.xpath("//*[@id='ng-app']/div/div/div/div[2]/span/div/a")).click();
    	eyes.checkWindow("HomePage");
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("//*[@class='tb-card-view-name ng-binding'][text()='PG Engineering']")).click();
    	Thread.sleep(5000);
    	eyes.checkWindow("PG_Engineering");    	
    	driver.findElement(By.xpath("//*[@class='tb-thumbnail-caption-link ng-binding'][text()='ECR New']")).click();
    	Thread.sleep(4000);
    	eyes.checkWindow("ECR_New_Dashboard");
    	driver.findElement(By.xpath("//*[@class='tb-thumbnail-caption-link ng-binding'][text()='ECR Weekly Volume']")).click();
    	Thread.sleep(5000);
    eyes.checkWindow("ECR_Volume_Status_Report");
    	TestResults testResults1 = eyes.close(false);
        System.out.println("Visual Test results1: " + testResults1);
        
        
      //Test Case 2 -Validation ECR History data 
        eyes = getEyes();
        eyes.open(driver, "Tableau", "Validation of ECR History Data", new RectangleSize(800,500));    	   	
    	driver.findElement(By.xpath("//*[@aria-label='ECR New'][text()='ECR New']")).click();
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("//*[@class='tb-thumbnail-caption-link ng-binding'][text()='ECR History Data']")).click();
    	Thread.sleep(9000);
    	eyes.checkWindow("ECR_History_Data");
    	TestResults testResults2 = eyes.close(false);
        System.out.println("Visual Test results2: " + testResults2);
    	/*
    	//Test Case 3 - Validation of Workbooks with NO Recent Usage
    	 */
        eyes = getEyes();
        eyes.open(driver, "Tableau", "Validation of Workbooks with No Recent Usage", new RectangleSize(800,500));        
    	driver.findElement(By.xpath("//*[@id='ng-app']/div/div/div/div[2]/span/div/a")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@class='tb-card-view-name ng-binding'][text()='@Start Here']")).click();
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("//*[@class='tb-thumbnail-caption-link ng-binding'][text()='Workbooks with NO Recent Usage']")).click();
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("//*[@class='tb-thumbnail-caption-link ng-binding'][text()='Workbooks with NO Recent Usage']")).click();
    	Thread.sleep(10000);
    	eyes.checkWindow("Workbooks_with_NO_Recent_Usage");
    	//eyes.checkWindow();
    	TestResults testResults3 = eyes.close(false);
        System.out.println("Visual Test results2: " + testResults3);
    	
    	//Test Case 4
        eyes = getEyes();
        eyes.open(driver, "Tableau", "Validation of History Report", new RectangleSize(800,500));
        
    	driver.findElement(By.xpath("//*[@id='ng-app']/div/div/div/div[2]/span/div/a")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@class='tb-card-view-name ng-binding'][text()='@Start Here']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@class='tb-thumbnail-caption-link ng-binding'][text()='Workbook Modification Log']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@class='tb-thumbnail-caption-link ng-binding'][text()='Workook Modification Log']")).click();
    	Thread.sleep(7000);
    	eyes.checkWindow("Report");
    	TestResults testResults4 = eyes.close(false);
        System.out.println("Visual Test results2: " + testResults4);
    	
    	//Test Case 5 -Validation of IBAT Unit report        
        eyes = getEyes();
        eyes.open(driver, "Tableau", "Validation of IBAT Unit Report", new RectangleSize(800,500));
        
    	driver.findElement(By.xpath("//*[@id='ng-app']/div/div/div/div[2]/span/div/a")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@class='tb-card-view-name ng-binding'][text()='Self Service Templates and Data Sources']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@class='tb-thumbnail-caption-link ng-binding'][text()='0U PG Installed Base - IBAT']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//*[@class='tb-thumbnail-caption-link ng-binding'][text()='Ex: Units Report']")).click();
    	Thread.sleep(7000);
    	eyes.checkWindow("IBAT Unit Report");
    	
    	TestResults testResults5 = eyes.close(false);
        System.out.println("Visual Test results2: " + testResults5);
        
        //Test case - 6 Font, Color and Font Type validation
        driver.findElement(By.xpath("//*[@id='ng-app']/div/div/div/div[2]/span/div/a")).click();
    	Thread.sleep(2000);
        Map<String, String> WorkBook = new HashMap<>();
		 WebElement BookTab = driver.findElement(By.xpath("//*[@class='tb-label'][text()='Workbooks']")); 
		 WorkBook.put("color", BookTab.getCssValue("color"));		 		
	     WorkBook.put("size", BookTab.getCssValue("font-size"));
		 WorkBook.put("familyType", BookTab.getCssValue("font-family"));
		 System.out.println(BookTab.getCssValue("color"));
	      System.out.println(BookTab.getCssValue("font-size"));
	      System.out.println(BookTab.getCssValue("font-family"));
		 
      Map<String, String> PGEng = new HashMap<>();       
      WebElement DealsTab = driver.findElement(By.xpath("//*[@class='tb-card-view-name ng-binding'][text()='PG Engineering']")); 
      PGEng.put("color", DealsTab.getCssValue("color"));		 		
      PGEng.put("size", DealsTab.getCssValue("font-size"));
      PGEng.put("familyType", DealsTab.getCssValue("font-family"));
      System.out.println(DealsTab.getCssValue("color"));
      System.out.println(DealsTab.getCssValue("font-size"));
      System.out.println(DealsTab.getCssValue("font-family"));
		
		/*Assert.assertEquals(Deals.get("familyType"), Book.get("familyType"), "FamilyType not matched"); 	
		Assert.assertEquals(Deals.get("color"), Book.get("color"), "Color not matched"); 
		Assert.assertEquals(Deals.get("size"), Book.get("size"), "Size not matched"); */
		
		if(PGEng.get("color").equals(WorkBook.get("color"))){
			System.out.println("Color matched");
		}else {
			System.out.println("Font Color not matched");	
		}
		if(PGEng.get("size").equals(WorkBook.get("size"))){
			System.out.println("Font size matched");
		}else {
			System.out.println("Font size not matched");	
		}
		
		if(PGEng.get("familyType").equals(WorkBook.get("familyType"))){
			System.out.println("Font Family type matched");
		}
		else {
			System.out.println("Font Family type not matched");	
		}
    	} finally {
    		TestResults testResults = eyes.abortIfNotClosed();
        	System.out.println("Finally block: Testing");
            System.out.println("Visual Test results: " + testResults);
    	}
    }
    
       
    
    

    public static void main(String[] args) throws InterruptedException {
       // new GEPower_HelloWorld().verifyHelloWorld(2); // hellow world example 
        new DBTesting_validation().firstTablueTest();
        //new DBTesting_validation().TC_1_HomePage_Validation();
        
     
    }
}
