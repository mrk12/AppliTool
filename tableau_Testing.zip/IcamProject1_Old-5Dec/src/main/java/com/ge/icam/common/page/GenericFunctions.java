package com.ge.icam.common.page;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import com.ge.digital.itops.testng.PDFReporter;
import com.ge.digital.itops.webdriver.BaseWebDriver;
import com.ge.digital.itops.webdriver.WebDriverAccess;

import io.selendroid.exceptions.NoSuchElementException;




public class GenericFunctions extends BaseWebDriver {
	
	public static WebDriver driver = WebDriverAccess.getDriver();

	public static void staticWait(int time){
		System.out.println("Total time to wait :: "+time+" sec..");
		try{
			for(int t=1; t<=time; t++){
				Thread.sleep(1000);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	
	public static void waitForLoad(WebDriver driver) {
        ExpectedCondition<Boolean> pageLoadCondition = new
                ExpectedCondition<Boolean>() {
                    public Boolean apply(WebDriver driver) {
                        return ((JavascriptExecutor)driver).executeScript("return document.readyState").equals("complete");
                    }
                };
        WebDriverWait wait = new WebDriverWait(driver, 30);
        wait.until(pageLoadCondition);
    }
	
    public static void checkAlert() {
  	    try {
  	    	  	    	
  	        WebDriverWait wait = new WebDriverWait(driver, 5);
  	           	            	     
  	        if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
  	        	Alert alert = driver.switchTo().alert();
      	        alert.accept();
				}
  	        else {
					System.out.println("No Alert Present");
				}
  	        
  	    } catch (Exception e) {
  	        //exception handling
  	    }
  	}
    
    public static void checkAlertDismiss() {
  	    try {
  	    	  	    	
  	        WebDriverWait wait = new WebDriverWait(driver, 5);
  	           	            	     
  	        if (wait.until(ExpectedConditions.alertIsPresent()) != null) {
  	        	Alert alert = driver.switchTo().alert();
      	        alert.dismiss();
				}
  	        else {
					System.out.println("No Alert Present");
				}
  	        
  	    } catch (Exception e) {
  	        //exception handling
  	    }
  	} 
    

    public static void Validate_Table(LinkedList<String> columnName){
    	staticWait(2);
    	System.out.println("Validate_Table_columnNames method called");
    	try{
    		//LinkedList<String> columnList = new LinkedList<String>();
    		WebElement rowCont = WebDriverAccess.getElement(By.xpath("//*[@id=\"siteEquip\"]/tbody/tr"));
    		WebElement colmCont = WebDriverAccess.getElement(By.xpath("//*[@id=\"siteEquip\"]/tbody/td"));
    		System.out.println("row count" +rowCont);
    		System.out.println("colm count" +colmCont);
    		List<WebElement> rows = rowCont.findElements(By.xpath("//tr"));
    		rows.size();
//    		System.out.println("rowsObj "+rowsObj.size());
//    		for(int i=0; i<rowsObj.size(); i++){
//    			WebElement row = rowsObj.get(i);
//    			scrollToElement(row);
//    			String colobjtext = colobj.getText().trim();
//    			columnList.add(colobjtext);
//    		}
////    		column comparison====================
//    		for(int i=0; i<columnName.size(); i++){
//    			String colVl = columnName.get(i);
//    			if(columnList.contains(colVl)){
//    				System.out.println(colVl +" found ");
//    			}else {
//    				System.out.println(colVl +" not found ");
//    			}
//    		}
//    		captureScreenshot();
    	}catch(Exception e){
    		System.out.println("Validate_Table_rowNames exception occured :: "+e.getMessage());
    		captureScreenshot();
    		Assert.fail("Validate_Table_columnNames exception occured :: "+e.getMessage());
    	}
    }


public static void captureScreenshot(){
	try {
		staticWait(1);
		PDFReporter.takeExtraScreenshot();
		System.out.println("screenshot is captured");
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

public static void scrollToElement(WebElement element){
	try{
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		Thread.sleep(500); 
	}catch(Exception e){
		System.out.println("scrollToElement "+e.getMessage());
	}
}

public static String getTable_columnName(String columnName){
	String colvl =null;
	System.out.println("getTable_columnName method called");
	try{
		WebElement headerCont = WebDriverAccess.getElement(By.xpath("(//div[@class='ui-jqgrid-hbox']/table[@class='ui-jqgrid-htable']/thead/tr[@class='ui-jqgrid-labels ui-sortable'])[2]"));
		List<WebElement> colnamesObj = headerCont.findElements(By.xpath("//th"));
		int colnum = 1;
		int chk = 0;
		System.out.println("colnamesObj "+colnamesObj.size());
		for(int i=0; i<colnamesObj.size(); i++){
			WebElement colobj = colnamesObj.get(i);
			scrollToElement(colobj);
			String colobjtext = colobj.getText().trim();
			if(colobjtext.trim().length()>1){
				colnum++;
				System.out.println("colobjtext "+colobjtext+"  lenght "+colobjtext.trim().length()+" actual lenght "+columnName.length());
				if(columnName.equalsIgnoreCase(colobjtext.trim())){
					chk =1;
					System.out.println(" column number "+colnum);
					System.out.println(columnName+" column name matched !! "+colobjtext);
					colvl = colobjtext;
					break;
				}
			}
		}
		if(chk!=1){
			System.out.println(columnName +" column name not found");
		}
		captureScreenshot();
	}catch(Exception e){
		captureScreenshot();
		System.out.println("getTable_columnName exception occured :: "+e.getMessage());
	}
	return colvl;
}


public static void waitUntillElementIsClickable(WebElement element, int time){
	try{
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.elementToBeClickable(element));
	}catch(Exception e){
		System.out.println("waitUntillElementIsClickable "+ e.getMessage());
	}
}

public static WebElement waitforDownload(int time){
	try{
		Wait<WebDriver> wait = new FluentWait<WebDriver>(driver).
				withTimeout(time, TimeUnit.SECONDS).
				pollingEvery(30, TimeUnit.SECONDS).
				ignoring(NoSuchElementException.class); 
			WebElement element1 = wait.until(new Function<WebDriver,WebElement>(){
			public WebElement apply(WebDriver driver) {
			WebElement	ele = driver.findElement(By.xpath("//table/tbody/tr/td[@class=\"tbl_bg2_content_hdr\"][contains(text(),'Catalog Administration')]"));
			if(ele.isDisplayed()) {
				
				System.out.println("displayed "+ ele);
				return ele; 
			}
			else{
				return ele;
			}
			}			
			});		
	
	}catch(Exception e){
		System.out.println("waitUntillElementIsClickable "+ e.getMessage());
	}
	return null;
}


public static void waitUntillElementIsClickable(By by, int time){
	try{
		WebDriverWait wait = new WebDriverWait(driver, time);
		wait.until(ExpectedConditions.elementToBeClickable(by));
	}catch(Exception e){
		System.out.println("waitUntillElementIsClickable "+ e.getMessage());
	}
}


public static void selectValueFromDropdownByLabelID(String labelID, String value){
	try{
	GenericFunctions.staticWait(5);
	WebElement element = driver.findElement(By.xpath("//table/tbody/tr[*]/td[*]/table/tbody/tr[*]/td[*]/select[@id='"+labelID+"']"));
	//table/tbody/tr[*]/td[*]/table/tbody/tr[*]/td[*]/select[@id='lstSaveAsVersionTypID']
	//scrollToElement(element);
	element.isDisplayed();
	element.click();
	System.out.println("Successfully clicked on dropdown");
//	WebElement comboboxElement = driver.findElement(By.xpath("//ul[@role='combobox'][not(contains(@style, 'none'))]"));
//	comboboxElement.isDisplayed();
	//table/tbody/tr[*]/td[*]/table/tbody/tr[*]/td[*]/select[@id='"+labelID+"']/option[contains(text(),'"+value+"')]
	//System.out.println("Combobox displayed successfully");
	WebElement valueLocator = driver.findElement(By.xpath("	//table/tbody/tr[*]/td[*]/table/tbody/tr[*]/td[*]/select[@id='"+labelID+"']/option[contains(text(),'"+value+"')]"));
	valueLocator.click();
	System.out.println("Dropdown value: "+value+" selected successfully");
	
	}catch(Exception e){
		System.out.println("selectValueFromDropdown :: Exception :: "+e.getMessage());
		Assert.fail("selectValueFromDropdown :: Exception :: "+e.getMessage());
	}
}

public static String getCurrentTimeStamp() {
    SimpleDateFormat formDate = new SimpleDateFormat("MM/dd/yyyy");
    String strDate = formDate.format(new Date());
    return strDate;
} 

public static void selectValueFromDropdownByName(String name, String value){
	try{
	GenericFunctions.staticWait(5);
	WebElement element = driver.findElement(By.xpath("//table/tbody/tr[*]/td[*]/table/tbody/tr[*]/td[*]/select[@name='"+name+"']"));
	element.isDisplayed();
	element.click();
	System.out.println("Successfully clicked on dropdown");
	WebElement valueLocator = driver.findElement(By.xpath("//table/tbody/tr[*]/td[*]/table/tbody/tr[*]/td[*]/select[@name='"+name+"']/option[contains(text(),'"+value+"')]"));
	valueLocator.click();
	System.out.println("Dropdown value: "+value+" selected successfully");
	
	}catch(Exception e){
		System.out.println("selectValueFromDropdown :: Exception :: "+e.getMessage());
		Assert.fail("selectValueFromDropdown :: Exception :: "+e.getMessage());
	}
} 
}
