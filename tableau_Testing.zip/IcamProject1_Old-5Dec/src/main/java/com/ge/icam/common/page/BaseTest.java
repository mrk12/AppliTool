package com.ge.icam.common.page;




import org.apache.log4j.Logger;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterClass;

import org.testng.annotations.BeforeClass;

import org.testng.annotations.Parameters;
import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.exceptions.TimeoutException;
import com.ge.digital.itops.webdriver.BaseWebDriver;

	public class BaseTest extends BaseWebDriver {
		
	private static final Logger log = Logger.getLogger(BaseTest.class);

		@BeforeClass
		@Parameters({ "url","env"})
		public void setUp(String url, String env) throws Exception {
			try {
				System.out.println("Opening URL: " + url + "=========" + env);
				System.out.println("Opening URL: " + url + "=========" + env);
				BrowserAction.openBrowser(url);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (NoSuchElementException e) {
				Assert.fail("Unable to enter user id in user id editbox.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("Something went wrong.\n" + e.getMessage());
			}
		}

		/*@AfterClass
		public void tearDown() throws Exception {
				
			GenericFunctions.checkAlert();
			Actions keyAction = new Actions(driver);
			keyAction.sendKeys(Keys.chord(Keys.ESCAPE)).build().perform();
			GenericFunctions.staticWait(5);
			BrowserAction.closeBrowser();
			 
	         log.info("Chrome Browser is killed");
		}*/
	}

