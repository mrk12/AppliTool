package com.ge.icam.common.page;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.HashMap;


import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class IcamExcelUtils {
		
	public static Path path = FileSystems.getDefault().getPath(System.getProperty("user.home"), "Documents");
	
	private static String ICAM_Testdata = path +"\\IcamProject1\\resource\\TestData\\ICAM_Testdata.xlsx";
	
	
	
	public static void main(String []args){
		
		System.out.println(ICAM_Testdata);
		
	}
	

	public static String storeUserCredential(String profile_name, String user_details){
		System.out.println("storeUserCredential called");
		XSSFWorkbook workbook = null;
		String userdetails = null;
		try{
			FileInputStream FIS = new FileInputStream(new File(ICAM_Testdata));
			//ceating the workbook instance
			workbook = new XSSFWorkbook(FIS);
	        XSSFSheet firstSheet = workbook.getSheet("User_Test_Data_Sheet");
	        
			//string actual number of rows to int
			int Row_count = return_total_excel_row(firstSheet);
			boolean rst = false;
			//Loop through the driver sheet
			for (int j = 1; j <= Row_count; j++) {
				XSSFRow row_obj = firstSheet.getRow(j);
				//get profile name
				XSSFCell profileCell = row_obj.getCell(0);
				String profileCellVl = getCellDataBasedOnDataType(profileCell);
				System.out.println("Profile Name "+profileCellVl);
				if(profile_name.equalsIgnoreCase(profileCellVl)){
					rst = true;
					System.out.println("Profile Name "+profileCellVl+" matched");
					if(user_details.equalsIgnoreCase("user")){
						//lable name
						XSSFCell user_name_cellobj = row_obj.getCell(1);
						String user_name_cellvalue = getCellDataBasedOnDataType(user_name_cellobj);
						System.out.println("user_name_cellvalue "+user_name_cellvalue);
						userdetails = user_name_cellvalue;
					}else if(user_details.equalsIgnoreCase("pswd")){
						//lable name
						XSSFCell user_pswd_cellobj = row_obj.getCell(2);
						String user_pswd_cellvalue = getCellDataBasedOnDataType(user_pswd_cellobj);
						System.out.println("user_pswd_cellvalue "+user_pswd_cellvalue);
						userdetails = user_pswd_cellvalue;
					}else{
						System.out.println("user details column not found");
					}
					break;
				}
			}	
			
			if(rst!=true){
				System.out.println(profile_name+" profile didn't match");
			}
			
		}catch(Exception e){
			System.out.println(e);
			e.printStackTrace();
		}finally{
			try {
				workbook.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				e.printStackTrace();
			}
		}
		return  userdetails;
	}

	public static int return_total_excel_row(XSSFSheet Wsheet_obj){
		int introw = 0;
		// Row count operation
		int Row_c = Wsheet_obj.getLastRowNum() + 1;// Total number of rows
		// Loop through all the rows in the excel sheet and checks if there
		// is a blank row if there is a blank row then reduces the count of
		// the rows
		for (int f = 1; f < Row_c; f++) {
			boolean rw_rs = isRowEmptyInExcel(Wsheet_obj.getRow(f));
					
			if (rw_rs != true) {
				introw++;
			}
		}
		System.out.println("Total row " + introw);
		return introw;
	}
	
	//This function checks if there is a 
	@SuppressWarnings("deprecation")
	private static boolean isRowEmptyInExcel(Row row) {
		try {
			for (int c = row.getFirstCellNum(); c < row.getLastCellNum(); c++) {
				Cell cell = row.getCell(c);
				if (cell != null && cell.getCellType() != Cell.CELL_TYPE_BLANK) {
					return false;
				}
			}
		} catch (Exception e) {
		}
		return true;
	}

	
	public static String storeTestData_FromGenericTestData_sheet_BasedOn_key(String keyNme){
		System.out.println("storeTestData_FromGenericTestData_sheet_BasedOn_key called");
		XSSFWorkbook workbook = null;
		String keydetails = null;
		try{
			FileInputStream FIS = new FileInputStream(new File(ICAM_Testdata));
			//ceating the workbook instance
			workbook = new XSSFWorkbook(FIS);
	        XSSFSheet firstSheet = workbook.getSheet("Generic_Test_Data");
	        
			//string actual number of rows to int
			int Row_count = return_total_excel_row(firstSheet);
			boolean rst = false;
			//Loop through the driver sheet
			for (int j = 1; j <= Row_count; j++) {
				XSSFRow row_obj = firstSheet.getRow(j);
				//get profile name
				XSSFCell keyNmeCell = row_obj.getCell(0);
				String keyNmeCellVl = getCellDataBasedOnDataType(keyNmeCell);
				System.out.println("keyNme "+keyNmeCellVl);
				if(keyNme.equalsIgnoreCase(keyNmeCellVl)){
					rst = true;
					System.out.println("keyNme "+keyNmeCellVl+" matched");
					XSSFCell keyNme_cellobj = row_obj.getCell(1);
					String keyNme_cellvalue = getCellDataBasedOnDataType(keyNme_cellobj);
					System.out.println("keyNme_cellvalue "+keyNme_cellvalue);
					keydetails = keyNme_cellvalue;
					break;
				}
			}	
			
			if(rst!=true){
				System.out.println(keyNme+" key details didn't match");
			}
			
		}catch(Exception e){
			System.out.println(e);
			e.printStackTrace();
		}finally{
			try {
				workbook.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				e.printStackTrace();
			}
		}
		return  keydetails;
	}
	

	
	public static String storeTestData_FromMasterTestData_sheet_BasedOn_TestCaseID_and_key(String testCaseID, String keyNme){
		System.out.println("storeTestData_FromMasterTestData_sheet_BasedOn_TestCaseID_and_key called");
		XSSFWorkbook workbook = null;
		String keydetails = null;
		try{
			FileInputStream FIS = new FileInputStream(new File(ICAM_Testdata));
			//ceating the workbook instance
			workbook = new XSSFWorkbook(FIS);
	        XSSFSheet firstSheet = workbook.getSheet("Master_Test_Data_Sheet");
			//string actual number of rows to int
			int Row_count = return_total_excel_row(firstSheet);
			boolean rst = false;
			//Loop through the driver sheet
			for (int j = 1; j <= Row_count; j++) {
				XSSFRow row_obj = firstSheet.getRow(j);
				//get profile name
				XSSFCell testCaseIDCell = row_obj.getCell(0);
				String testCaseIDCellVl = getCellDataBasedOnDataType(testCaseIDCell);
				System.out.println("testCaseIDCellVl "+testCaseIDCellVl);
				if(testCaseID.equalsIgnoreCase(testCaseIDCellVl)){
					rst = true;
					System.out.println("test case iD "+testCaseIDCellVl+" matched");
					int lastCellNum = row_obj.getLastCellNum();
					int chk = 0;
					System.out.println("lastCellNum "+lastCellNum+" ");
					for(int i=1; i<lastCellNum; i++){
						XSSFCell keyNme_cellobj = row_obj.getCell(i);
						String keyNme_cellName = getCellDataBasedOnDataType(keyNme_cellobj);
						System.out.println("keyNme_cellColName "+keyNme_cellName);
						if(keyNme.equalsIgnoreCase(keyNme_cellName)){
							XSSFCell keyNme_value_cellobj = row_obj.getCell(i+1);
							String keyNme_value = getCellDataBasedOnDataType(keyNme_value_cellobj);
							System.out.println("keyNme_cellColValue "+keyNme_value);
							keydetails 	= keyNme_value;
							chk = 1;
							break;
						}
					}
					if(chk!=1){
						System.out.println("colum key not found for "+testCaseID);
					}
					break;
				}
			}	
			if(rst!=true){
				System.out.println(testCaseID+" test case ID not found");
			}
			
		}catch(Exception e){
			System.out.println(e);
			e.printStackTrace();
		}finally{
			try {
				workbook.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				e.printStackTrace();
			}
		}
		return  keydetails;
	}
	
	
	@SuppressWarnings("deprecation")
	public static HashMap<String,String> storeAllTestData_FromMasterTestDatasheet_BasedOn_TestCaseID(String testCaseID){
		System.out.println("storeAllTestData_FromMasterTestDatasheet_BasedOn_TestCaseID called");
		XSSFWorkbook workbook = null;
		HashMap<String,String> keydetails = new HashMap<String,String>();
		try{
			FileInputStream FIS = new FileInputStream(new File(ICAM_Testdata));
			//ceating the workbook instance
			workbook = new XSSFWorkbook(FIS);
	        XSSFSheet firstSheet = workbook.getSheet("Master_Test_Data_Sheet");
			//string actual number of rows to int
			int Row_count = return_total_excel_row(firstSheet);
			boolean rst = false;
			//Loop through the driver sheet
			for (int j = 1; j <= Row_count; j++) {
				XSSFRow row_obj = firstSheet.getRow(j);
				//get profile name
				XSSFCell testCaseIDCell = row_obj.getCell(0);
				String testCaseIDCellVl = getCellDataBasedOnDataType(testCaseIDCell);
				System.out.println("testCaseIDCellVl "+testCaseIDCellVl);
				if(testCaseID.equalsIgnoreCase(testCaseIDCellVl)){
					rst = true;
					System.out.println("test case iD "+testCaseIDCellVl+" matched");
					int lastCellNum = row_obj.getLastCellNum();
					System.out.println("lastCellNum "+lastCellNum+" ");
					for(int i=1; i<lastCellNum; i++){
						//store key
						XSSFCell keyNme_cellobj = row_obj.getCell(i);
						if(keyNme_cellobj!=null && keyNme_cellobj.getCellType() != Cell.CELL_TYPE_BLANK){
							String keyNme_cellName = getCellDataBasedOnDataType(keyNme_cellobj);
							XSSFCell keyNme_value_cellobj = row_obj.getCell(i+1);
							String keyNme_value = getCellDataBasedOnDataType(keyNme_value_cellobj);
							System.out.println("keyNme "+keyNme_cellName+" and keyValue "+keyNme_value);
							keydetails.put(keyNme_cellName, keyNme_value);
						}
						i = i+1;
					}
					
					break;
				}
			}	
			
			if(rst!=true){
				System.out.println(testCaseID+" test case ID not found");
			}
			
		}catch(Exception e){
			System.out.println(e);
			e.printStackTrace();
		}finally{
			try {
				workbook.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				e.printStackTrace();
			}
		}
		return  keydetails;
	}
	
	//return all data in string format
	private static String getCellDataBasedOnDataType(XSSFCell cell){
		String value = null ;
		@SuppressWarnings("deprecation")
		CellType type = cell.getCellTypeEnum();
        if (type == CellType.STRING) {
        	value = cell.getRichStringCellValue().toString().trim(); 
        } else if (type == CellType.NUMERIC) {
        	double nm = cell.getNumericCellValue();
        	int x = (int) nm ;
        	value =  Integer.toString(x);
        } else if (type == CellType.BOOLEAN) {
        	
        } else if (type == CellType.BLANK) {
        	
        }
        return value ;
	}
	
	
	public static HashMap<String,String> storeUserCredentialBasedOn_Module_role_Position_and_Responsebility(String module,String role,String position,String responsibility){
		System.out.println("storeUserCredentialBasedOn_Module_role_Position_and_Responsebility called");
		XSSFWorkbook workbook = null;
		HashMap<String,String> keydetails = new HashMap<String,String>();
		try{
			FileInputStream FIS = new FileInputStream(new File(ICAM_Testdata));
			//creating the workbook instance
			workbook = new XSSFWorkbook(FIS);
	        XSSFSheet firstSheet = workbook.getSheet("User_Credentials");
			//string actual number of rows to int
			int Row_count = return_total_excel_row(firstSheet);
			boolean rst = false;
			//Loop through the driver sheet
			for (int j = 1; j <= Row_count; j++) {
				XSSFRow row_obj = firstSheet.getRow(j);
				//get profile name
				XSSFCell ModuleCell = row_obj.getCell(0);
				String ModuleCellCellVl = getCellDataBasedOnDataType(ModuleCell);
				if(module.equalsIgnoreCase(ModuleCellCellVl)){
					XSSFCell role_cellobj = row_obj.getCell(1);
					String role_cellName = getCellDataBasedOnDataType(role_cellobj);
					
					XSSFCell position_value_cellobj = row_obj.getCell(2);
					String position_value = getCellDataBasedOnDataType(position_value_cellobj);

					XSSFCell reponsibility_value_cellobj = row_obj.getCell(3);
					String reponsibility_value = getCellDataBasedOnDataType(reponsibility_value_cellobj);
					
					if(role_cellName.equalsIgnoreCase(role) && position_value.equalsIgnoreCase(position)
							&& reponsibility_value.equalsIgnoreCase(responsibility)){
						rst = true;
						XSSFCell user_value_cellobj = row_obj.getCell(4);
						String usere_value = getCellDataBasedOnDataType(user_value_cellobj);

						XSSFCell pswd_value_cellobj = row_obj.getCell(5);
						String pswd_value = getCellDataBasedOnDataType(pswd_value_cellobj);
						keydetails.put("user", usere_value);
						keydetails.put("pswd", pswd_value);
						System.out.println("role_cellName "+role_cellName+" position_value "+position_value+" reponsibility_value "+reponsibility_value);
						System.out.println("usere_value "+usere_value+" pswd_value "+pswd_value);
						break;
					}
				}
			}	
			
			
			if(rst!=true){
				System.out.println("module "+module+" !!");
				System.out.println("role_cellName "+role+" position_value "+position+" reponsibility_value "+responsibility+" mot found !!");
			}
			
		}catch(Exception e){
			System.out.println(e);
			e.printStackTrace();
		}finally{
			try {
				workbook.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				e.printStackTrace();
			}
		}
		return  keydetails;
	}
	
	
	//naina
	
	public static String storeVersion_FromVersionTestData_sheet_BasedOn_key(String keyNme){
		System.out.println("storeVersion_FromVersionTestData_sheet_BasedOn_key called");
		XSSFWorkbook workbook = null;
		String keydetails = null;
		try{
			FileInputStream FIS = new FileInputStream(new File(ICAM_Testdata));
			//ceating the workbook instance
			workbook = new XSSFWorkbook(FIS);
	        XSSFSheet firstSheet = workbook.getSheet("Version_Test_Data");
	        
			//string actual number of rows to int
			int Row_count = return_total_excel_row(firstSheet);
			boolean rst = false;
			//Loop through the driver sheet
			for (int j = 1; j <= Row_count; j++) {
				XSSFRow row_obj = firstSheet.getRow(j);
				//get profile name
				XSSFCell keyNmeCell = row_obj.getCell(0);
				String keyNmeCellVl = getCellDataBasedOnDataType(keyNmeCell);
				System.out.println("keyNme "+keyNmeCellVl);
				if(keyNme.equalsIgnoreCase(keyNmeCellVl)){
					rst = true;
					System.out.println("keyNme "+keyNmeCellVl+" matched");
					XSSFCell keyNme_cellobj = row_obj.getCell(1);
					String keyNme_cellvalue = getCellDataBasedOnDataType(keyNme_cellobj);
					System.out.println("keyNme_cellvalue "+keyNme_cellvalue);
					keydetails = keyNme_cellvalue;
					break;
				}
			}	
			
			if(rst!=true){
				System.out.println(keyNme+" key details didn't match");
			}
			
		}catch(Exception e){
			System.out.println(e);
			e.printStackTrace();
		}finally{
			try {
				workbook.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println(e);
				e.printStackTrace();
			}
		}
		return  keydetails;
	}
	
	
	
	
	
	
	
	
	
	
}
