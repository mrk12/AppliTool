package com.ge.icam.common.page;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.testng.Assert;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.browser.BrowserVerify;
import com.ge.digital.itops.browser.BrowserWait;
import com.ge.digital.itops.exceptions.TimeoutException;
import com.ge.digital.itops.testng.PDFReporter;
import com.ge.icam.common.page.GenericFunctions;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.ge.icam.common.map.LoginPageObjects;
//import com.ge.icam.common.map.loginpage_objects;

public class LoginObjects extends BaseTest {

	// private static final Logger logger =
	// Logger.getLogger(LoginPageObjects.class);

	public static void enterUserID_SSO(String username) {

		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_SSO_username_NAME);
			BrowserAction.clear(LoginPageObjects.ICAM_SSO_username_NAME);
			BrowserAction.enterFieldValue(LoginPageObjects.ICAM_SSO_username_NAME, username);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (NoSuchElementException e) {
			Assert.fail("Unable to enter user id in user id editbox.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("Something went wrong.\n" + e.getMessage());
		}
	}

	public static void enterPassword_SSO(String password) {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_SSO_password_NAME);
			BrowserAction.clear(LoginPageObjects.ICAM_SSO_password_NAME);
			BrowserAction.enterFieldValue(LoginPageObjects.ICAM_SSO_password_NAME, password);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (NoSuchElementException e) {
			Assert.fail("Unable to enter password in password id editbox.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("Something went wrong.\n" + e.getMessage());
		}
	}

	public static void pressLoginBtn_SSO() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_SSO_submit_button_NAME);
			BrowserAction.click(LoginPageObjects.ICAM_SSO_submit_button_NAME);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressLoginBtn \n" + e.getMessage());
		}

	}

	public static void pressacceptBtn() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_accept_button_NAME);
			BrowserAction.click(LoginPageObjects.ICAM_accept_button_NAME);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void selectPGSBusinessList() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_Selectbusiness_PGS_XPATH);
			// WebDriver wb
			// =driver.findElement(By.xpath(LoginPageObjects.ICAM_Selectbusiness_XPATH_PGS.toString()));
			BrowserAction.click(LoginPageObjects.ICAM_Selectbusiness_PGS_XPATH);

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	// Paste other BU

	public static void selectAeroBusinessList() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_Selectbusiness_Aero_XPATH);
			BrowserAction.click(LoginPageObjects.ICAM_Selectbusiness_Aero_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void selectAlstomBusinessList() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_Selectbusiness_Alstom_XPATH);
			BrowserAction.click(LoginPageObjects.ICAM_Selectbusiness_Alstom_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void selectJenbacherBusinessList() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_Selectbusiness_Jenbacher_XPATH);
			BrowserAction.click(LoginPageObjects.ICAM_Selectbusiness_Jenbacher_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void selectONGBusinessList() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_Selectbusiness_ONG_XPATH);
			BrowserAction.click(LoginPageObjects.ICAM_Selectbusiness_ONG_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void selectrolelist() {
		try {
			GenericFunctions.staticWait(2);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_Selectrole_XPATH);
			BrowserAction.click(LoginPageObjects.ICAM_Selectrole_XPATH);

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void selectButton() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_Select__button_XPATH);
			BrowserAction.click(LoginPageObjects.ICAM_Select__button_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void enterModelid(String modelid) {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_Modelid_XPATH);
			BrowserAction.clear(LoginPageObjects.ICAM_Modelid_XPATH);
			BrowserAction.enterFieldValue(LoginPageObjects.ICAM_Modelid_XPATH, modelid);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (NoSuchElementException e) {
			Assert.fail("Unable to enter password in password id editbox.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("Something went wrong.\n" + e.getMessage());
		}
	}

	public static void searchButton() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ICAM_SEARCH_XPATH);
			BrowserAction.click(LoginPageObjects.ICAM_SEARCH_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void imageButton() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.SEARCH_IMAGE_XPATH);
			BrowserAction.click(LoginPageObjects.SEARCH_IMAGE_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypePGS() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_PGS_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_PGS_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeAero() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Aero_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Aero_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeJenbacher() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Jenbacher_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Jenbacher_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeONG() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_ONG_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_ONG_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeAlstom() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Alstom_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Alstom_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	// Billing
	
	public static void ChildBrowserWindow_Close() {
		try {
			
            String currentWindow = driver.getWindowHandle();		
			Set<String> Windows = driver.getWindowHandles();
			int Window_Count = Windows.size();
			System.out.println(": the number of windows opened are "+Window_Count);
			if(Window_Count>1)
			{
				Iterator<String> itr = Windows.iterator();
				while (itr.hasNext()) {
					String childWindow = itr.next();
					if (!currentWindow.equals(childWindow)) {
						GenericFunctions.driver.switchTo().window(childWindow);
						driver.close();
						System.out.println("the child window is closed ");
						driver.switchTo().window(currentWindow);
						
			       }

			   }
			}
		
		} catch (Exception e) {
		Assert.fail("Unable to Close the Child window");
	}
			}


	public static void versiontypeBillingRETAIN27() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_RETAIN27_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_RETAIN27_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER4026() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER4026_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER4026_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingUSER04() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER04_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER04_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
 
	
	public static void versiontypeBillingUSER100() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER100_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER100_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingUSER59() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER59_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER59_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER4033() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER4033_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER4033_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingRETAIN3() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_RETAIN3_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_RETAIN3_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER06() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER06_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER06_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingAlstomUSER60() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_Alstom_USER60_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_Alstom_USER60_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingAlstomUSER101() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_Alstom_USER101_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_Alstom_USER101_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingAlstomUSER05() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_Alstom_USER05_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_Alstom_USER05_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	public static void versiontypeBillingUSER60() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER60_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER60_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingAlstom_Yearly_USER02() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_Alstom_USER02_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_Alstom_USER02_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	

	public static void versiontypeBillingUSER106() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER106_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER106_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingUSER322() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER322_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER322_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER101() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER101_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER101_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER105() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER105_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER105_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingRETAIN14() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_RETAIN14_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_RETAIN14_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingRETAIN16() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_RETAIN16_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_RETAIN16_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER215() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER215_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER215_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingRETAIN26() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_RETAIN26_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_RETAIN26_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingRETAIN29() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_RETAIN29_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_RETAIN29_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	
	public static void versiontypeBillingUSER119() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER119_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER119_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER11() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER11_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER11_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingUSER57() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER57_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER57_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER131() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER131_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER131_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingOTR_FC() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_OTR_FC_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_OTR_FC_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER4036() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER4036_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER4036_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER05() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER05_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER05_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingRETAIN30() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_RETAIN30_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_RETAIN30_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingRETAIN25() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_RETAIN25_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_RETAIN25_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingRETAIN2() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_RETAIN2_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_RETAIN2_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER112() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER112_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER112_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER09() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER09_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER09_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER02() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER02_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER02_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingUSER178() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER178_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER178_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER103() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER103_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER103_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	//versiontypeBillingUSER110
	
	public static void versiontypeBillingUSER110() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER110_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER110_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void versiontypeBillingUSER109() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER109_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER109_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}
	}

	public static void versiontypeBillingUSER512() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER512_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER512_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
	public static void versiontypeBillingUSER173() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER101_XPATH);
			BrowserAction.click(LoginPageObjects.Version_type_Billing_USER101_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	} 
	
	
		
		public static void versiontypeBillingUSER173_Model() {
				try {
					GenericFunctions.staticWait(1);
					BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER173_XPATH);
					BrowserAction.click(LoginPageObjects.Version_type_Billing_USER173_XPATH);
				} catch (TimeoutException e) {
					Assert.fail("Unable to locate the element.\n" + e.getMessage());
				} catch (Exception e) {
					Assert.fail("pressacceptBtn \n" + e.getMessage());
				}

			} 
		
		public static void versiontypeBillingUSER227() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER227_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER227_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		 
		
		public static void versiontypeBillingUSER174() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER174_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER174_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		
		public static void versiontypeBillingUSER166() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER166_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER166_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}

	public static void versiontypeBillingUSER152() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER152_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER152_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		
		public static void versiontypeBillingUSER175() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER175_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER175_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		
		public static void versiontypeBillingUSER339() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER339_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER339_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		
		public static void versiontypeBillingUSER222() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER222_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER222_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		
		public static void versiontypeBillingUSER223() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER223_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER223_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
	 
		public static void versiontypeARCheck72() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_AR72_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_AR72_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		} 
		
		public static void versiontypeBillingUSER364() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER364_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER364_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		
		public static void versiontypeBillingUSER366() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER366_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER366_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		} 
		
		public static void versiontypeBillingUSER108() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER108_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER108_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		
		public static void versiontypeBillingUSER03() {
			try {
				GenericFunctions.staticWait(1);
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_Billing_USER03_XPATH);
				BrowserAction.click(LoginPageObjects.Version_type_Billing_USER03_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		public static void RRR_RegressionButton() {
			try {

				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.RRR_RegressionImage_XPATH);
				BrowserAction.click(LoginPageObjects.RRR_RegressionImage_XPATH);
			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		
		public static void click_RRR_regression() {
			try {

				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.RRR_Regression_XPATH);
				BrowserAction.click(LoginPageObjects.RRR_Regression_XPATH);

				System.out.println("RRR clicked");

			} catch (TimeoutException e) {
				Assert.fail("Unable to locate the element.\n" + e.getMessage());
			} catch (Exception e) {
				Assert.fail("pressacceptBtn \n" + e.getMessage());
			}

		}
		
		
		

	public static void new_version() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.NEW_VERSION_XPATH);
			BrowserAction.click(LoginPageObjects.NEW_VERSION_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}
	
		public static void schedule() {

				try {

					GenericFunctions.staticWait(1);
					BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.schedule_XPATH);
					BrowserAction.click(LoginPageObjects.schedule_XPATH);
					GenericFunctions.checkAlert();
					WebElement schedule = GenericFunctions.driver
							.findElement(By.xpath(LoginPageObjects.schedule_bold_XPATH.toString()));
					GenericFunctions.waitUntillElementIsClickable(schedule, 90);
					BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.schedule_bold_XPATH);

					BrowserVerify.verifyElementIsDisplayed(LoginPageObjects.schedule_bold_XPATH);
					System.out.println("schedule calculated");
					
					String CurrentWindow = driver.getWindowHandle();
					Set<String> set =driver.getWindowHandles();
					Iterator<String> itr= set.iterator();
					while(itr.hasNext())
					   {  
						 String WindowName = itr.next();
						 driver.switchTo().window(WindowName);
						 String Title = driver.getTitle();
						 if(Title.equalsIgnoreCase("ICAM - Download Unused parts details"))				 
						 {
							driver.close();
							driver.switchTo().window(CurrentWindow);
							break;					
						 }
						 else
						 {
							 driver.switchTo().window(CurrentWindow);
						 }
				        } 
				}catch (TimeoutException e) {
					Assert.fail("Unable to locate the element.\n" + e.getMessage());
				} catch (Exception e) {
					Assert.fail("pressacceptBtn \n" + e.getMessage());
				}

			} 
		 


	public static void clickSchedule() {

		try {

			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.schedule_Tab_XPATH);
			BrowserAction.click(LoginPageObjects.schedule_Tab_XPATH);
			System.out.println("schedule clicked");
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void finance() {
		try {
			GenericFunctions.staticWait(1);
			GenericFunctions.checkAlert();
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Finance_XPATH);
			BrowserAction.click(LoginPageObjects.Finance_XPATH);
			GenericFunctions.checkAlert();

			WebElement finance = GenericFunctions.driver
					.findElement(By.xpath(LoginPageObjects.finance_bold_XPATH.toString()));
			GenericFunctions.waitUntillElementIsClickable(finance, 90);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.finance_bold_XPATH);

			BrowserVerify.verifyElementIsDisplayed(LoginPageObjects.finance_bold_XPATH);
			System.out.println("Finance calculated");

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static boolean checkRedSchedule() {
		boolean present;
		try {
			GenericFunctions.driver.findElement(By.xpath("//*[@id=\"statusBarEventSch\"]/a/font[@color='red']"));

			present = true;
		} catch (Exception e) {
			present = false;
		}

		return present;
	}

	public static boolean checkRedFinance() {
		boolean present;

		try {

			GenericFunctions.driver.findElement(By.xpath("//*[@id=\"statusBarFinance\"]/a/font[@color='red']"));
			present = true;
		} catch (Exception e) {
			present = false;
		}

		return present;

	}

	public static void selectversion() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.select_list_XPATH);
			BrowserAction.click(LoginPageObjects.select_list_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void enterversion_description(String name) {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.version_XPATH);
			BrowserAction.clear(LoginPageObjects.version_XPATH);
			BrowserAction.enterFieldValue(LoginPageObjects.version_XPATH, name);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (NoSuchElementException e) {
			Assert.fail("Unable to enter password in password id editbox.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("Something went wrong.\n" + e.getMessage());
		}
	}

	public static void saveversion() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.save_version_XPATH);
			BrowserAction.click(LoginPageObjects.save_version_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void Pricing() {
		try {

			WebElement pricing = driver.findElement(By.xpath(LoginPageObjects.pricing_XPATH.toString()));
			GenericFunctions.waitUntillElementIsClickable(pricing, 60);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.pricing_XPATH);
			BrowserVerify.verifyElementIsDisplayed(LoginPageObjects.pricing_XPATH);
			System.out.println("Finance calculated and pricing is in bold");
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}


	public static void loginIntoApplication_via_SSO(String username, String password) throws Exception {
		
		String PageTitle = driver.getTitle();
		if(PageTitle.equalsIgnoreCase("GE : Single Sign On"))
		{
		GenericFunctions.staticWait(3);
		LoginObjects.enterUserID_SSO(username);
		LoginObjects.enterPassword_SSO(password);
		PDFReporter.takeExtraScreenshot();
		LoginObjects.pressLoginBtn_SSO();
		LoginObjects.pressacceptBtn();
		}
		else
		{
			LoginObjects.pressacceptBtn();
		}
		// LoginObjects.selectbusinesslist();
		// LoginObjects.selectrolelist();
		// LoginObjects.selectButton();
	}

	public static void modelid(String modelid) throws Exception {
		GenericFunctions.staticWait(3);
		LoginObjects.enterModelid(modelid);
		LoginObjects.searchButton();
		LoginObjects.imageButton();
		// LoginObjects.versiontype();
	}

	public static void RRR_ImageButton() {
		try {

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.RRR_IMAGE_XPATH);
			BrowserAction.click(LoginPageObjects.RRR_IMAGE_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void click_RRR() {
		try {

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.RRR_XPATH);
			BrowserAction.click(LoginPageObjects.RRR_XPATH);

			System.out.println("RRR clicked");

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void selectPartKits() {
		try {

			// int size = GenericFunctions.driver.findElements(By.tagName("iframe")).size();
			// System.out.println(size);
			GenericFunctions.driver.switchTo().frame(1);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.PartKits_XPATH);
			BrowserAction.click(LoginPageObjects.PartKits_XPATH);

			System.out.println("Part Kits selected");

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void assignPartKits() {
		try {

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.KitsAssign_XPATH);
			BrowserAction.click(LoginPageObjects.KitsAssign_XPATH);

			System.out.println("Part kits assigned");

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void showReports() {
		try {

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.showReport_XPATH);
			BrowserAction.click(LoginPageObjects.showReport_XPATH);

			System.out.println("Showing part kits report");

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void downloadReport() {
		try {

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.downloadReport_XPATH);
			BrowserAction.click(LoginPageObjects.downloadReport_XPATH);

			System.out.println("Downloading report");

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void repairReplaceReport() throws Exception {
		GenericFunctions.staticWait(3);

		LoginObjects.RRR_ImageButton();
		LoginObjects.click_RRR();
		GenericFunctions.staticWait(3);

		LoginObjects.selectPartKits();
		GenericFunctions.staticWait(3);

		LoginObjects.assignPartKits();
		GenericFunctions.staticWait(3);

		LoginObjects.showReports();
		GenericFunctions.driver.manage().timeouts().implicitlyWait(900, TimeUnit.SECONDS);
		GenericFunctions.staticWait(3);


	}

	// Haripriya

	public static void modelid_8(String modelid) throws Exception {
		GenericFunctions.staticWait(3);
		LoginObjects.enterModelid(modelid);
		LoginObjects.searchButton();
		LoginObjects.imageButton();

	}

	public static void Inventory() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Inventory_XPATH);
			BrowserAction.click(LoginPageObjects.Inventory_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void ManageFleets() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Manage_Fleet_XPATH);
			BrowserAction.click(LoginPageObjects.Manage_Fleet_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void SaveAsFleet() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Save_as_fleet_XPATH);
			BrowserAction.click(LoginPageObjects.Save_as_fleet_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void SaveAsNewFleet() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Save_as_new_fleet_XPATH);
			BrowserAction.click(LoginPageObjects.Save_as_new_fleet_XPATH);
			System.out.println("clicked");
			// GenericFunctions.staticWait(60);
			GenericFunctions.driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
			String currentWindow = GenericFunctions.driver.getWindowHandle();
			Set<String> set = GenericFunctions.driver.getWindowHandles();
			Iterator<String> itr = set.iterator();
			while (itr.hasNext()) {
				String Window2 = itr.next();
				if (!currentWindow.equals(Window2)) {
					GenericFunctions.driver.switchTo().window(Window2);
					System.out.println("fleet is saved");

				}
			}
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void selectfleet() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Fleet_dropdwn_XPATH);
			BrowserAction.click(LoginPageObjects.Fleet_dropdwn_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	// Shree

	public static void Billing() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_XPATH);
			BrowserAction.click(LoginPageObjects.Billing_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void ActiveVersion() {

		try {

			GenericFunctions.staticWait(1);

			WebElement colmCont = GenericFunctions.driver
					.findElement(By.xpath(LoginPageObjects.Table_Xpath.toString()));
			WebElement rowCont = GenericFunctions.driver.findElement(By.xpath(LoginPageObjects.Table_Xpath.toString()));
			int rows = rowCont.findElements(By.xpath(LoginPageObjects.Table_Xpath.toString() + "//tr")).size();
			int colms = colmCont.findElements(By.xpath(LoginPageObjects.Table_Xpath.toString() + "//tr//td")).size();

			int i;
			System.out.println("row count" + rows);
			System.out.println("colm count" + colms);
			for (i = 2; i <= rows; i++) {
				System.out.println("loop start");
				String yesXpath = "//*/table[@class='tbl_bg2']/tbody/tr[" + i + "]/td[4]/b[contains(., \"Y\")]";
				boolean present;
				try {
					driver.findElement(By.xpath(yesXpath));
					present = true;
					System.out.println("Y found in " + i + " row");
				} catch (NoSuchElementException e) {
					present = false;
				}
				if (present) {

					String radio = "/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/form/table/tbody/tr[2]/td/table[1]/tbody/tr["
							+ i + "]/td[1]/input ";
					WebElement wb = GenericFunctions.driver.findElement(By.xpath(radio));
					wb.click();
					System.out.println("Radio button clicked");
					break;

				}

			}

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.OpenButton_XPATH);
			BrowserAction.click(LoginPageObjects.OpenButton_XPATH);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Export_XPATH);
			BrowserAction.click(LoginPageObjects.Export_XPATH);

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void selectActiveVersion() {
		try {

			GenericFunctions.staticWait(1);

			WebElement colmCont = GenericFunctions.driver
					.findElement(By.xpath(LoginPageObjects.Table_Xpath.toString()));
			WebElement rowCont = GenericFunctions.driver.findElement(By.xpath(LoginPageObjects.Table_Xpath.toString()));
			int rows = rowCont.findElements(By.xpath(LoginPageObjects.Table_Xpath.toString() + "//tr")).size();
			int colms = colmCont.findElements(By.xpath(LoginPageObjects.Table_Xpath.toString() + "//tr//td")).size();

			int i;
			System.out.println("row count" + rows);
			System.out.println("colm count" + colms);
			for (i = 2; i <= rows; i++) {
				System.out.println("loop start");
				String yesXpath = "//*/table[@class='tbl_bg2']/tbody/tr[" + i + "]/td[4]/b[contains(., \"Y\")]";
				boolean present;
				try {
					driver.findElement(By.xpath(yesXpath));
					present = true;
					System.out.println("Y found in " + i + " row");
				} catch (NoSuchElementException e) {
					present = false;
				}
				if (present) {

					String radio = "/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/form/table/tbody/tr[2]/td/table[1]/tbody/tr["
							+ i + "]/td[1]/input ";
					WebElement wb = GenericFunctions.driver.findElement(By.xpath(radio));
					wb.click();
					System.out.println("Radio button clicked");
					break;

				}
			}
			/*
			 * }
			 * 
			 * 
			 * BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ActiveVersion_XPATH)
			 * ; System.out.println("Active version column is present");
			 * BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Yes_XPATH);
			 * System.out.println("Active version is Y"); WebElement button =
			 * GenericFunctions.driver
			 */

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	// Naina
	public static void Validate_Table() {
		GenericFunctions.staticWait(2);
		try {

			WebElement colmCont = driver.findElement(By.xpath(LoginPageObjects.schedule_table_XPATH.toString()));
			WebElement rowCont = driver.findElement(By.xpath(LoginPageObjects.schedule_table_XPATH.toString()));
			int rows = rowCont.findElements(By.xpath(LoginPageObjects.schedule_table_XPATH.toString() + "//tr")).size();
			int colms = colmCont.findElements(By.xpath(LoginPageObjects.schedule_table_XPATH.toString() + "//tr//td"))
					.size();

			System.out.println("row count" + rows);
			System.out.println("colm count" + colms);

			for (int i = 2; i <= rows; i++) {
				WebElement col = driver.findElement(
						By.xpath(LoginPageObjects.schedule_table_XPATH.toString() + "/tbody/tr[" + i + "]/td[2]"));
				String equipVl = col.getText();
				System.out.println("equipment  " + equipVl);

				WebElement colm = driver.findElement(By.xpath(LoginPageObjects.year_table_XPATH.toString() + "//tr[" + i
						+ "]/td[*]/div/a/b/span[contains(text(),'EOTE')]"));
				String res = colm.getText();
				if (res.equals("EOTE")) {
					System.out.println("EOTE found ");
				} else {
					System.out.println("EOTE not found ");
				}

			}
		} catch (Exception e) {
			System.out.println("Validate_Table exception occured :: " + e.getMessage());
			GenericFunctions.captureScreenshot();
			Assert.fail("Validate_Table exception occured :: " + e.getMessage());
		}
	}

	public static void Validate_Billing() {
		GenericFunctions.staticWait(2);
		try {
			WebElement colmCont = driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()));
			WebElement rowCont = driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()));
			int rows = rowCont.findElements(By.xpath(LoginPageObjects.billing_table_XPATH.toString() + "//tr")).size();
			int colms = colmCont.findElements(By.xpath(LoginPageObjects.billing_table_XPATH.toString() + "//tr//td"))
					.size();
			int i = rows - 1;
			System.out.println("row count" + rows);
			System.out.println("colm count" + colms);

			WebElement cumubilling = driver.findElement(
					By.xpath(LoginPageObjects.billing_table_XPATH.toString() + "//tr[" + i + "]//td[1]/input"));
			String value = cumubilling.getAttribute("value");
			System.out.println("cumu billing " + value);
			WebElement totalbilling = driver.findElement(By.xpath(
					LoginPageObjects.billing_table_XPATH.toString() + "//tr[" + rows + "]//td[@id='totalAP']/input"));
			String total = totalbilling.getAttribute("value");
			System.out.println("total billing " + total);
			if (value.trim().equals(total)) {
				System.out.println("verified");
			} else {
				System.out.println("failed");

			}
		} catch (Exception e) {
			System.out.println("Validate_billing exception occured :: " + e.getMessage());
			GenericFunctions.captureScreenshot();
			Assert.fail("Validate_billing exception occured :: " + e.getMessage());
		}
	}

	// Sanjay
	public static void Schedule_ProjectedEvent() throws Exception {
		// List <WebElement> proj_events =
		// driver.findElements(By.xpath("//span[contains(@style,'color: #0000FF')]"));

		List<WebElement> proj_events = driver.findElements(By.xpath(LoginPageObjects.Projected_event_XPATH.toString()));
		int count = proj_events.size();
		for (int i = 0; i < count; i++) {
			String Event_Name = proj_events.get(i).getText();
			System.out.println("the event name is " + Event_Name);
			if (!Event_Name.equals("EOTE") || !Event_Name.equals("Recon")) {
				System.out.println(" Condition is successful");
				proj_events.get(i).click();
				GenericFunctions.staticWait(10);
				BrowserAction.maximizeCurrentWindow();

				String currentWindow = driver.getWindowHandle();
				Set<String> set = driver.getWindowHandles();
				Iterator<String> itr = set.iterator();
				while (itr.hasNext()) {
					String Window2 = itr.next();
					if (!currentWindow.equals(Window2)) {
						driver.switchTo().window(Window2);
						GenericFunctions.staticWait(2);
						BrowserAction.closeActiveWindow();
						driver.switchTo().window(currentWindow);
						GenericFunctions.staticWait(2);
					}
				}
			} else {
				System.out.println("Condition Failed");
			}
		}

	}

	// Billing 10

	public static void copyBilling() throws Exception {

		try {
			GenericFunctions.staticWait(3);

			LoginObjects.clickCopyButton();
			GenericFunctions.staticWait(3);

			LoginObjects.changeVersionName();
			GenericFunctions.staticWait(3);

			try {
				// Clicking Fixed billing next button
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_Fixed_Next_XPATH);
				BrowserAction.click(LoginPageObjects.Billing_Fixed_Next_XPATH);
				System.out.println("Next Clicked...Moving to variable billing tab");
				GenericFunctions.staticWait(3);
			} catch (Exception e) {

			}
			try {
				// Clicking Variable billing next button
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_Variable_Next_XPATH);
				BrowserAction.click(LoginPageObjects.Billing_Variable_Next_XPATH);

				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_Variable_Next2_XPATH);
				BrowserAction.click(LoginPageObjects.Billing_Variable_Next2_XPATH);

				System.out.println("Next Clicked...Moving to Milestone billingn tab");
				GenericFunctions.staticWait(3);
			} catch (Exception e) {

			}

			try {
				// Clicking Milestone billing next button
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_Milestone_Next_XPATH);
				BrowserAction.click(LoginPageObjects.Billing_Milestone_Next_XPATH);
				System.out.println("Next Clicked...Moving to Bonus/LD billing tab");
				GenericFunctions.staticWait(3);
			} catch (Exception e) {

			}
			// Clicking Bonus/LD billing next button
			try {
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_Bonus_Next_XPATH);
				BrowserAction.click(LoginPageObjects.Billing_Bonus_Next_XPATH);
				System.out.println("Next Clicked...Moving to Billing Stream tab");
				GenericFunctions.staticWait(3);
			} catch (Exception e) {

			}
			GenericFunctions.checkAlert();
			System.out.println("Handling popup");

			// add billing stream in try/catch

			// Clicking on save
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_Copy_Save_XPATH);
			BrowserAction.click(LoginPageObjects.Billing_Copy_Save_XPATH);
			System.out.println("Clicking on Save button");
			GenericFunctions.staticWait(3);

			GenericFunctions.checkAlert();

			// Calculate Finance
			GenericFunctions.checkAlert();
			LoginObjects.finance();

			// Open Billing
			LoginObjects.Billing();
			GenericFunctions.staticWait(3);

			LoginObjects.ActiveVersion();
			GenericFunctions.staticWait(3);

			System.out.println("Downloaded....Compare the report");

		}

		catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void clickCopyButton() {
		try {

			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_Copy_XPATH);
			BrowserAction.click(LoginPageObjects.Billing_Copy_XPATH);
			System.out.println("Copy button clicked");

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void changeVersionName() {
		try {

			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_Change_VersionName_XPATH);

			WebElement wb = GenericFunctions.driver
					.findElement(By.xpath(LoginPageObjects.Billing_Change_VersionName_XPATH.toString()));
			wb.clear();
			wb.sendKeys("Test");
			System.out.println("Version name changed");

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_Next_XPATH);
			BrowserAction.click(LoginPageObjects.Billing_Next_XPATH);
			GenericFunctions.checkAlert();
			System.out.println("Next Clicked...Moving to fixed billing");
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void openActiveVersion() {

		try {

			GenericFunctions.staticWait(1);

			WebElement colmCont = GenericFunctions.driver
					.findElement(By.xpath(LoginPageObjects.Table_Xpath.toString()));
			WebElement rowCont = GenericFunctions.driver.findElement(By.xpath(LoginPageObjects.Table_Xpath.toString()));
			int rows = rowCont.findElements(By.xpath(LoginPageObjects.Table_Xpath.toString() + "//tr")).size();
			int colms = colmCont.findElements(By.xpath(LoginPageObjects.Table_Xpath.toString() + "//tr//td")).size();

			int i;
			System.out.println("row count" + rows);
			System.out.println("colm count" + colms);
			for (i = 2; i <= rows; i++) {
				System.out.println("loop start");
				String yesXpath = "//*/table[@class='tbl_bg2']/tbody/tr[" + i + "]/td[4]/b[contains(., \"Y\")]";
				boolean present;
				try {
					driver.findElement(By.xpath(yesXpath));
					present = true;
					System.out.println("Y found in " + i + " row");
				} catch (NoSuchElementException e) {
					present = false;
				}
				if (present) {

					String radio = "/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/form/table/tbody/tr[2]/td/table[1]/tbody/tr["
							+ i + "]/td[1]/input ";
					WebElement wb = GenericFunctions.driver.findElement(By.xpath(radio));
					wb.click();
					System.out.println("Radio button clicked");
					break;

				}

			}

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.OpenButton_XPATH);
			BrowserAction.click(LoginPageObjects.OpenButton_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void validateBilling() {

		GenericFunctions.staticWait(2);
		try{
			 WebElement colmCont = driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()));
			 WebElement rowCont = driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()));
		     int rows = rowCont.findElements(By.xpath(LoginPageObjects.billing_table_XPATH.toString()+"//tr")).size();
		     int colms = colmCont.findElements(By.xpath(LoginPageObjects.billing_table_XPATH.toString()+"//tr//td")).size();
			int i ;
			
		    System.out.println("row count" +rows);
			System.out.println("colm count" +colms);
			
			for (i = 1;i<=rows-1;i++)
			{
		
			String str="(//*/table[@class ='int_tbl_bg2']//ancestor::table)[6]/tbody/tr[2]/td[2]//table/tbody/tr["+i+"]/td[4]/select";
			Select s = new Select(driver.findElement(By.xpath(str)));
			System.out.println("Select..");
			
			WebElement option =s.getFirstSelectedOption();
			String selected = option.getText();	
			
			if(selected.equals("Projected")) 
			{
			
			String comm="(//*[@class ='txtarea_bg comments'])["+i+"]";
			System.out.println("comment");
			GenericFunctions.staticWait(3);
			try{
				WebElement comment=driver.findElement(By.xpath(comm.toString()));
				comment.sendKeys("Testing");
				if (comment.isEnabled()) {
					comment.clear();
				System.out.println("Comment"+comment);
				GenericFunctions.staticWait(3);
				}
			} catch (Exception e) {
				System.out.println("catch block");	
			}
			s.selectByIndex(1);
			GenericFunctions.staticWait(10);
			//String fixedbilling=LoginPageObjects.billing_table_XPATH.toString()+"//tr["+i+"]//td[19]/input";
			try{
				WebElement fixedbilling=driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()+"//tr["+i+"]//td[19]/input"));
				if (fixedbilling.isEnabled()) {
					fixedbilling.clear();
				System.out.println("Comment"+fixedbilling);
				GenericFunctions.staticWait(3);
				fixedbilling.sendKeys("10000");	}
			} catch (Exception e) {
				
			}

			try{
				WebElement variablebilling=driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()+"//tr["+i+"]//td[20]/input"));
				if (variablebilling.isEnabled()) {
					variablebilling.clear();
				System.out.println("Comment"+variablebilling);
				GenericFunctions.staticWait(3);
				variablebilling.sendKeys("10000");	}
			} catch (Exception e) {
				
			}

			try{
				WebElement FMVCarveout=driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()+"//tr["+i+"]//td[22]/input"));
				if (FMVCarveout.isEnabled()) {
					FMVCarveout.clear();
				System.out.println("Comment"+FMVCarveout);
				GenericFunctions.staticWait(3);
				FMVCarveout.sendKeys("10000");	}
			} catch (Exception e) {
				
			}
			try{
				WebElement milestonebilling=driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()+"//tr["+i+"]//td[23]/input"));
				if (milestonebilling.isEnabled()) {
					milestonebilling.clear();
				System.out.println("Comment"+milestonebilling);
				GenericFunctions.staticWait(3);
				milestonebilling.sendKeys("10000");	}
			} catch (Exception e) {
				
			}
		
			try{
				WebElement extrawork=driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()+"//tr["+i+"]//td[27]/input"));
				if (extrawork.isEnabled()) {
					extrawork.clear();
				System.out.println("Comment"+extrawork);
				GenericFunctions.staticWait(3);
				extrawork.sendKeys("10000");	}
			} catch (Exception e) {
				
			}
			break;

			}}}catch(Exception e){
			System.out.println("Validate_billing exception occured :: "+e.getMessage());
			GenericFunctions.captureScreenshot();
			Assert.fail("Validate_billing exception occured :: "+e.getMessage());
		}
	}

	public static void monthlyvalidatebilling() {
		GenericFunctions.staticWait(2);
		try {
			WebElement colmCont = driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()));
			WebElement rowCont = driver.findElement(By.xpath(LoginPageObjects.billing_table_XPATH.toString()));
			int rows = rowCont.findElements(By.xpath(LoginPageObjects.billing_table_XPATH.toString() + "//tr")).size();
			int colms = colmCont.findElements(By.xpath(LoginPageObjects.billing_table_XPATH.toString() + "//tr//td"))
					.size();
			int i;

			System.out.println("row count" + rows);
			System.out.println("colm count" + colms);

			for (i = 1; i <= rows - 1; i++) {

				String str = "(//*/table[@class ='int_tbl_bg2']//ancestor::table)[6]/tbody/tr[2]/td[2]//table/tbody/tr["
						+ i + "]/td[4]/select";
				Select s = new Select(driver.findElement(By.xpath(str)));
				System.out.println("Select..");

				WebElement option = s.getFirstSelectedOption();
				String selected = option.getText();

				if (selected.equals("Projected")) {
					String comm = "(//*[@class ='txtarea_bg comments'])[" + i + "]";
					System.out.println("comment");
					GenericFunctions.staticWait(3);
					driver.findElement(By.xpath(comm)).sendKeys("Testing");
					s.selectByIndex(1);
					GenericFunctions.staticWait(10);
					System.out.println("19");
					String fixedbilling = LoginPageObjects.billing_table_XPATH.toString() + "//tr[" + i
							+ "]//td[25]/input";
					driver.findElement(By.xpath(fixedbilling)).clear();
					System.out.println("Comment" + fixedbilling);
					GenericFunctions.staticWait(3);
					driver.findElement(By.xpath(fixedbilling)).sendKeys("10000");

					String variablebilling = LoginPageObjects.billing_table_XPATH.toString() + "//tr[" + i
							+ "]//td[26]/input";
					driver.findElement(By.xpath(variablebilling)).clear();
					System.out.println("Comment" + variablebilling);
					GenericFunctions.staticWait(3);
					driver.findElement(By.xpath(variablebilling)).sendKeys("10000");

					String FMVCarveout = LoginPageObjects.billing_table_XPATH.toString() + "//tr[" + i
							+ "]//td[28]/input";
					driver.findElement(By.xpath(FMVCarveout)).clear();
					System.out.println("Comment" + FMVCarveout);
					GenericFunctions.staticWait(3);
					driver.findElement(By.xpath(FMVCarveout)).sendKeys("10000");

					String milestonebilling = LoginPageObjects.billing_table_XPATH.toString() + "//tr[" + i
							+ "]//td[29]/input";
					driver.findElement(By.xpath(milestonebilling)).clear();
					System.out.println("Comment" + milestonebilling);
					GenericFunctions.staticWait(3);
					driver.findElement(By.xpath(milestonebilling)).sendKeys("10000");

					String extrawork = LoginPageObjects.billing_table_XPATH.toString() + "//tr[" + i
							+ "]//td[23]/input";
					driver.findElement(By.xpath(extrawork)).clear();
					System.out.println("Comment" + extrawork);
					GenericFunctions.staticWait(3);
					driver.findElement(By.xpath(extrawork)).sendKeys("10000");

					break;

				}
			}
		} catch (Exception e) {
			System.out.println("Validate_billing exception occured :: " + e.getMessage());
			GenericFunctions.captureScreenshot();
			Assert.fail("Validate_billing exception occured :: " + e.getMessage());
		}
	}

	public static void saveActualization() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Save_button_XPATH);
			BrowserAction.click(LoginPageObjects.Save_button_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void exportActualizationTable() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Export_XPATH);
			BrowserAction.click(LoginPageObjects.Export_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

	public static void billingStreamFX() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_StreamFX_XPATH);
			BrowserAction.click(LoginPageObjects.Billing_StreamFX_XPATH);

			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Billing_StreamFX_XPATH);
			BrowserAction.click(LoginPageObjects.Billing_StreamFX_XPATH);

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}
	}

	public static void exportVersion() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Export_XPATH);
			BrowserAction.click(LoginPageObjects.Export_XPATH);

		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}
	}

	public static void Billing_ContractLevel_Configure() throws Exception {
		
		BrowserAction.click(LoginPageObjects.Billing_Stream_Name_Radio_NAME);
		BrowserAction.click(LoginPageObjects.Billing_Stream_NewVersion_Button_NAME);
		GenericFunctions.staticWait(1);
		BrowserAction.enterFieldValue(LoginPageObjects.Billing_VersionName_XPATH, "2Q16 LEG VA AFT");
		BrowserAction.enterFieldValue(LoginPageObjects.Billing_Version_Desc_NAME, "Automation Test");
		BrowserAction.selectDropdownOptionByText(LoginPageObjects.Billing_Frequency_DD_NAME, "Quarterly");
		BrowserAction.click(LoginPageObjects.Billing_BonusLD_Yes_XPATH);
		BrowserAction.click(LoginPageObjects.Billing_Constraint_YES_XPATH);
		BrowserAction.click(LoginPageObjects.Billing_Extrawork_Yes_XPATH);
		BrowserAction.click(LoginPageObjects.Billing_FMV_Carveout_Yes_XPATH);
		GenericFunctions.staticWait(1);
		BrowserAction.click(LoginPageObjects.Billing_Escxaltion_NO_XPATH);
		BrowserAction.click(LoginPageObjects.Billing_ForiegnExchange_Yes_XPATH);
		GenericFunctions.checkAlert();
		BrowserAction.selectDropdownOptionByText(LoginPageObjects.Billing_Currency_DD_NAME, "Euro");
		BrowserAction.enterFieldValue(LoginPageObjects.Billing_FX_RATE_NAME, "10");
		BrowserAction.click(LoginPageObjects.Billing_ContractLevel_XPATH);
		BrowserAction.click(LoginPageObjects.Billing_Next_NAME);
		GenericFunctions.staticWait(1);
		BrowserAction.click(LoginPageObjects.Billing_Fixed_EntireContract_XPATH);
		BrowserAction.enterFieldValue(LoginPageObjects.Billing_FixedAmoutInput_NAME, "10000");
		BrowserAction.click(LoginPageObjects.Billing_Next_NAME);
		GenericFunctions.staticWait(1);
		BrowserAction.click(LoginPageObjects.Billing_AutomaticSelection_OperatingMode_XPATH);
		BrowserAction.click(LoginPageObjects.Billing_FFH_XPATH);
		BrowserAction.click(LoginPageObjects.Billing_OneRate_XPATH);
		BrowserAction.click(LoginPageObjects.Billing_Next_NAME);
		GenericFunctions.staticWait(1);
		BrowserAction.enterFieldValue(LoginPageObjects.Billing_FFH_Rate_XPATH, "11");
		BrowserAction.click(LoginPageObjects.Billing_Next_NAME);
		GenericFunctions.staticWait(1);
		BrowserAction.click(LoginPageObjects.Billing_Event_Millestone_Radio_NAME);
		BrowserAction.click(LoginPageObjects.Billing_Event_Millestone_AddRow_NAME);
		//BrowserAction.selectDropdownOptionByText(LoginPageObjects.Billing_Event_Millestone_Equipment_DD_NAME,"ALL Gas 's");
		WebElement Equip_Name = BrowserAction.getElement(LoginPageObjects.Billing_Event_Millestone_Equipment_DD_NAME);
		select_by_index(Equip_Name,1);
		GenericFunctions.staticWait(1);
		WebElement Equip_Type = BrowserAction.getElement(LoginPageObjects.Billing_Event_Millestone_Type_DD_NAME);
		select_by_index(Equip_Type,2);	
		//BrowserAction.selectDropdownOptionByValue(LoginPageObjects.Billing_Event_Millestone_Equipment_DD_NAME, "2_1%");		
		//GenericFunctions.staticWait(1);
		//BrowserAction.selectDropdownOptionByText(LoginPageObjects.Billing_Event_Millestone_Type_DD_NAME, "HGP");
		GenericFunctions.staticWait(3);
		BrowserAction.click(LoginPageObjects.Billing_Event_Millestone_Occurance_DD_NAME);
		BrowserAction.selectDropdownOptionByText(LoginPageObjects.Billing_Event_Millestone_Occurance_DD_NAME, "1");
		GenericFunctions.staticWait(3);
		BrowserAction.click(LoginPageObjects.Billing_Event_Millestone_Months_DD_NAME);
		BrowserAction.selectDropdownOptionByText(LoginPageObjects.Billing_Event_Millestone_Months_DD_NAME, "1");
		BrowserAction.enterFieldValue(LoginPageObjects.Billing_Event_Millestone_Amount_NAME, "10000");
		BrowserAction.click(LoginPageObjects.Billing_Next_NAME);
		GenericFunctions.staticWait(3);
		BrowserAction.enterFieldValue(LoginPageObjects.Billing_BonusLD_LD_Period_Field_XPATH, "50000");
		BrowserAction.enterFieldValue(LoginPageObjects.Billing_BonusLD_Bonus_Period_Field_XPATH, "50000");
		BrowserAction.click(LoginPageObjects.Billing_Next_NAME);
		GenericFunctions.staticWait(1);
		BrowserAction.enterFieldValue(LoginPageObjects.Billing_FMVCarveout_Carveout1_Period_Field_XPATH, "10000");
		BrowserAction.click(LoginPageObjects.Billing_Next_NAME);
		GenericFunctions.staticWait(1);
		GenericFunctions.checkAlert();
	}

	public static String Billing_verify_DownloadTemplate(String Filename) throws Exception {

		GenericFunctions.staticWait(2);
		BrowserAction.click(LoginPageObjects.Billing_DownloadExcel_NAME);
		GenericFunctions.staticWait(5);
		Path path = FileSystems.getDefault().getPath(System.getProperty("user.home"), "Downloads");
		String DownloadedPATH = path + "\\" + Filename;
		System.out.println("Excel DownloadPath is " + DownloadedPATH);
		return DownloadedPATH;

	}

	public static String Billing_verify_ExportTemplate(String Filename) throws Exception {

		GenericFunctions.staticWait(2);
		BrowserAction.click(LoginPageObjects.Billing_ExportExcel_NAME);
		GenericFunctions.staticWait(5);
		Path path = FileSystems.getDefault().getPath(System.getProperty("user.home"), "Downloads");
		String ExportedPATH = path + "\\" + Filename;
		System.out.println("Excel DownloadPath is " + ExportedPATH);
		return ExportedPATH;

	}

	public static int Excel_Download_Modify_Data(String DownloadedPATH, double Cell_Value) throws IOException {
		// String Filename
		// ="C://Users//sanjanar//Downloads//BillingImportTemplate.xlsx";
		FileInputStream fis = new FileInputStream(DownloadedPATH);
		Workbook WB = new XSSFWorkbook(fis);
		GenericFunctions.staticWait(5);
		Sheet Sheet = WB.getSheetAt(0);

		int row_count = Sheet.getLastRowNum() - Sheet.getFirstRowNum();
		int CurrentRowCount = 0;
		outerloop: for (int i = 5; i < row_count; i++) {
			Row row = Sheet.getRow(i);

			for (int j = 0; j < 3; j++) {
				String cellvalue = row.getCell(j).getStringCellValue();
				if (cellvalue.equals("Projected")) {
					CurrentRowCount = row.getRowNum();
					Cell cell = row.getCell(5);

					cell.setCellValue(Cell_Value);
					FileOutputStream fos = new FileOutputStream(DownloadedPATH);
					WB.write(fos);
					GenericFunctions.staticWait(5);
					WB.close();
					System.out.println("the data in the downloaded excel file has been modified successfully");

					break outerloop;
				}
				j++;

			}
			// return CurrentRowCount;
		}
		return CurrentRowCount;
	}

	public static void Excel_Export_Verify_Data(String DownloadedPATH, String FixedBilling_Value,String VariableBilling_Value,String Adjustment_Value,String MilestoneBilling_Value,String Comments, int RowCount)
			throws IOException {
		// String Filename ="C://Users//sanjanar//Downloads//BillingStreamReport.xlsx";
		FileInputStream fis = new FileInputStream(DownloadedPATH);
		Workbook WB = new XSSFWorkbook(fis);
		GenericFunctions.staticWait(5);
		Sheet Sheet = WB.getSheetAt(0);
		int Expected_RowCount = RowCount + 4;
		Row row = Sheet.getRow(Expected_RowCount);
		//FixedBilling
		Cell cell = row.getCell(6);
		String FixedBilling = Double.toString(cell.getNumericCellValue());
		System.out.println("the data present in the cell is " + cell);		
		if(FixedBilling.equals(FixedBilling_Value))
		{
			System.out.println("the FixedBilling data in the exported excel file is verified Succesfully");
		}
		else
		{
			System.out.println("the data verification in the exported excel file is failed");
		}
	}

	public static void Billing_verify_Upload(String DownloadedPATH, double Cell_Value) throws Exception {
		BrowserAction.click(LoginPageObjects.Billing_UploadExcel_NAME);
		BrowserAction.maximizeCurrentWindow();
		String currentWindow = driver.getWindowHandle();
		Set<String> set = driver.getWindowHandles();
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			String Window2 = itr.next();
			if (!currentWindow.equals(Window2)) {
				driver.switchTo().window(Window2);
				GenericFunctions.staticWait(2);
				BrowserAction.click(LoginPageObjects.Billing_ChooseFile_NAME);
				// Copy file path into the window clipboard
				Robot robo = new Robot();
				StringSelection str = new StringSelection(DownloadedPATH);
				GenericFunctions.staticWait(2);
				Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str, str);
				// Pressing Control+V
				robo.keyPress(KeyEvent.VK_CONTROL);
				robo.keyPress(KeyEvent.VK_V);
				// Releasing Control+V
				robo.keyRelease(KeyEvent.VK_CONTROL);
				robo.keyRelease(KeyEvent.VK_V);
				GenericFunctions.staticWait(2);
				// Pressing Enter
				robo.keyPress(KeyEvent.VK_ENTER);
				GenericFunctions.staticWait(2);
				// Releasing Enter
				robo.keyRelease(KeyEvent.VK_ENTER);

				BrowserAction.click(LoginPageObjects.Billing_SubmitFile_NAME);
				GenericFunctions.staticWait(3);
				GenericFunctions.checkAlert();
				GenericFunctions.staticWait(2);
				GenericFunctions.checkAlert();
				GenericFunctions.staticWait(2);
				driver.switchTo().window(currentWindow);
				GenericFunctions.staticWait(2);

				WebElement element = driver.findElement(By.xpath("//td[6]//input[@style='BACKGROUND-COLOR:Lime']"));
				((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
				Thread.sleep(500);
				String Data = element.getAttribute("value");
				Double expected_Data = Double.parseDouble(Data);
				GenericFunctions.staticWait(2);
				if (expected_Data.equals(Cell_Value)) {
					System.out.println(" the uploaded data has been verified successfully");
				} else {
					System.out.println(" the uploaded data verification failed");
				}

			}

		}
		BrowserAction.click(LoginPageObjects.Billing_Save_NAME);
		GenericFunctions.staticWait(4);
		GenericFunctions.checkAlert();
		GenericFunctions.checkAlert();
		GenericFunctions.staticWait(2);
		// BrowserAction.click(LoginPageObjects.Billing_Calculate_Finance_XPATH);

	}

	public static void File_Verify_DownloadExcel(String Filename) throws Exception {
		Path path = FileSystems.getDefault().getPath(System.getProperty("user.home"), "Downloads");
		File file = new File(path + "//" + Filename);

		if (file.exists()) {
			System.out.println(" the Excel file has been downloaded successfully");
		} else {
			System.out.println(" the Excel file doesn't exists");
		}
	}

	public static void validatebilling_5(String month, String year) {
		GenericFunctions.staticWait(2);
		try {
			WebElement colmCont = driver.findElement(By.xpath(LoginPageObjects.billing_period_XPATH.toString()));
			WebElement rowCont = driver.findElement(By.xpath(LoginPageObjects.billing_period_XPATH.toString()));
			int rows = rowCont.findElements(By.xpath(LoginPageObjects.billing_period_XPATH.toString() + "//tr")).size();
			int colms = colmCont.findElements(By.xpath(LoginPageObjects.billing_period_XPATH.toString() + "//tr//td"))
					.size();
			int i;

			System.out.println("row count" + rows);
			System.out.println("colm count" + colms);

			for (i = 1; i <= rows - 1; i++) {
				try {
					System.out.println(i + " found");
					driver.findElement(By.xpath(LoginPageObjects.billing_period_XPATH.toString() + "//tr[" + i + "]"
							+ "//td[contains(text()," + month + ")and contains(text()," + year + ")]"));

					String str = "(//*/table[@class ='int_tbl_bg2']//ancestor::table)[6]/tbody/tr[2]/td[2]//table/tbody/tr["
							+ i + "]/td[4]/select";
					Select s = new Select(driver.findElement(By.xpath(str)));
					WebElement option = s.getFirstSelectedOption();
					String selected = option.getText();

					if (selected.equals("Actualized")) {
						System.out.println("Succesful");

					}
					break;
				} catch (Exception e) {
					// System.out.println("Select..");
				}
			}

		} catch (Exception e) {
			// System.out.println("Select..");
		}
	}
	
	public static void Import_actuals() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.import_actuals_XPATH);
			BrowserAction.click(LoginPageObjects.import_actuals_XPATH);
			
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}
	} 
	
	public static void Billing_save() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.billing_save_XPATH);
			BrowserAction.click(LoginPageObjects.billing_save_XPATH);
			
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}
	}
	
	public static void ok_button() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.ok_XPATH);
			BrowserAction.click(LoginPageObjects.ok_XPATH);
			
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}
	}
	
	public static int Excel_FX_Download_Modify_Data(String DownloadedPATH, String FixedBilling_Value,String Argument_Value,String MilestoneBilling_Value,String Comments)throws IOException{
		//String Filename ="C://Users//sanjanar//Downloads//BillingImportTemplate.xlsx";
		FileInputStream fis = new FileInputStream(DownloadedPATH);
		Workbook WB = new XSSFWorkbook(fis);
		GenericFunctions.staticWait(5);
		Sheet Sheet= WB.getSheetAt(0);
		
		int row_count =  Sheet.getLastRowNum()-Sheet.getFirstRowNum();
		int CurrentRowCount = 0;
		outerloop:
		for(int i=5;i<row_count;i++)
		{   
			Row row = Sheet.getRow(i);
			
					
			for(int j=0;j<3;j++){
			String cellvalue = row.getCell(j).getStringCellValue();
		    if(cellvalue.equals("Projected"))
		     {  
		    	CurrentRowCount = row.getRowNum();
		    	Cell cell=row.getCell(4);
		        cell.setCellValue(FixedBilling_Value);	
		        row.getCell(6).setCellValue(Argument_Value);
		        row.getCell(7).setCellValue(MilestoneBilling_Value);
		        row.getCell(9).setCellValue(Comments);
		        FileOutputStream fos = new FileOutputStream(DownloadedPATH);			        
	            WB.write(fos);
	            GenericFunctions.staticWait(5);
	            WB.close();
		    	System.out.println("the data in the downloaded excel file has been modified successfully");	
		    	
		    	break outerloop;
		     }
		      j++;
		      
			}
			//return CurrentRowCount;
	    }
		return CurrentRowCount;
	}
	
	
	/*public static int Excel_Download_Modify_Data(String DownloadedPATH, String FixedBilling_Value,String Argument_Value,String MilestoneBilling_Value,String Comments)throws IOException{
		//String Filename ="C://Users//sanjanar//Downloads//BillingImportTemplate.xlsx";
		FileInputStream fis = new FileInputStream(DownloadedPATH);
		Workbook WB = new XSSFWorkbook(fis);
		GenericFunctions.staticWait(5);
		Sheet Sheet= WB.getSheetAt(0);
		
		int row_count =  Sheet.getLastRowNum()-Sheet.getFirstRowNum();
		int CurrentRowCount = 0;
		outerloop:
		for(int i=5;i<row_count;i++)
		{   
			Row row = Sheet.getRow(i);
			
					
			for(int j=0;j<3;j++){
			String cellvalue = row.getCell(j).getStringCellValue();
		    if(cellvalue.equals("Projected"))
		     {  
		    	CurrentRowCount = row.getRowNum();
		    	Cell cell=row.getCell(4);
		        cell.setCellValue(FixedBilling_Value);	
		        row.getCell(8).setCellValue(Argument_Value);
		        row.getCell(11).setCellValue(MilestoneBilling_Value);
		        row.getCell(18).setCellValue(Comments);
		        FileOutputStream fos = new FileOutputStream(DownloadedPATH);			        
	            WB.write(fos);
	            GenericFunctions.staticWait(5);
	            WB.close();
		    	System.out.println("the data in the downloaded excel file has been modified successfully");	
		    	
		    	break outerloop;
		     }
		      j++;
		      
			}
			//return CurrentRowCount;
	    }
		return CurrentRowCount;
	}
	*/
	public static int Excel_Download_Modify_Data(String DownloadedPATH, String FixedBilling_Value,String VariableBilling_Value,String Adjustment_Value,String MilestoneBilling_Value,String Comments)throws IOException{
		//String Filename ="C://Users//sanjanar//Downloads//BillingImportTemplate.xlsx";
		FileInputStream fis = new FileInputStream(DownloadedPATH);
		Workbook WB = new XSSFWorkbook(fis);
		GenericFunctions.staticWait(5);
		Sheet Sheet= WB.getSheetAt(0);
		
		int row_count =  Sheet.getLastRowNum()-Sheet.getFirstRowNum();
		int CurrentRowCount = 0;
		outerloop:
		for(int i=5;i<row_count;i++)
		{   
			Row row = Sheet.getRow(i);
			
					
			for(int j=0;j<3;j++){
			String cellvalue = row.getCell(j).getStringCellValue();
		    if(cellvalue.equals("Projected"))
		     {  
		    	CurrentRowCount = row.getRowNum();
		    	Cell cell=row.getCell(4);
		        cell.setCellValue(FixedBilling_Value);
		        //row.getCell(6).setCellValue(VariableBilling_Value);
		        row.getCell(8).setCellValue(Adjustment_Value);
		        row.getCell(11).setCellValue(MilestoneBilling_Value);
		        row.getCell(18).setCellValue(Comments);
		        FileOutputStream fos = new FileOutputStream(DownloadedPATH);			        
	            WB.write(fos);
	            GenericFunctions.staticWait(5);
	            WB.close();
		    	System.out.println("the data in the downloaded excel file has been modified successfully");	
		    	
		    	break outerloop;
		     }
		      j++;
		      
			}
			//return CurrentRowCount;
	    }
		return CurrentRowCount;
	}
	
	
	public static void Billing_verify_Upload(String DownloadedPATH, String FixedBilling_Value,String VariableBilling_Value,String Adjustment_Value,String MilestoneBilling_Value,String Comments) throws Exception{
//		try {
		BrowserAction.click(LoginPageObjects.Billing_UploadExcel_NAME);
		BrowserAction.maximizeCurrentWindow();
		String currentWindow=driver.getWindowHandle(); 
		Set<String> set =driver.getWindowHandles();
		Iterator<String> itr= set.iterator();
		 while(itr.hasNext())
		 {
		 String Window2=itr.next();
		 if(!currentWindow.equals(Window2))
		 {
			 driver.switchTo().window(Window2);
			 GenericFunctions.staticWait(2);
			 BrowserAction.click(LoginPageObjects.Billing_ChooseFile_NAME);
			 //Copy file path into the window clipboard
			 Robot robo = new Robot();
			 StringSelection str = new StringSelection(DownloadedPATH);
			 GenericFunctions.staticWait(2);
			 Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str,str);
			 //Pressing Control+V
			 robo.keyPress(KeyEvent.VK_CONTROL);
			 robo.keyPress(KeyEvent.VK_V);
			//Releasing Control+V
			 robo.keyRelease(KeyEvent.VK_CONTROL);
			 robo.keyRelease(KeyEvent.VK_V);
			 GenericFunctions.staticWait(2);
			//Pressing Enter
			 robo.keyPress(KeyEvent.VK_ENTER);
			 GenericFunctions.staticWait(2);
			//Releasing Enter
			 robo.keyRelease(KeyEvent.VK_ENTER);
			 
			 BrowserAction.click(LoginPageObjects.Billing_SubmitFile_NAME);
			 GenericFunctions.staticWait(3);
			 GenericFunctions.checkAlert();
			 GenericFunctions.staticWait(2);
			 GenericFunctions.checkAlert();
			 GenericFunctions.staticWait(2);
			 driver.switchTo().window(currentWindow);
			 GenericFunctions.staticWait(2);
			// double FixedBilling_Value,double Argument_Value,double MilestoneBilling_Value,String Comments
			//FixedBilling
				 WebElement FixedBilling_element = driver.findElement(By.xpath("//td[5]//input[@style='BACKGROUND-COLOR:Lime']"));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", FixedBilling_element);
			 String FixedBilling_Data = (FixedBilling_element.getAttribute("value")).replaceAll(",", "");
			 // String data_abc = FixedBilling_Data.replaceAll(",", "");
			 System.out.println(FixedBilling_Data);
			 GenericFunctions.staticWait(2);
			 if(FixedBilling_Value.equals(FixedBilling_Data))
			 {
				 System.out.println(" the FixedBilling Data has been verified successfully");
			 }
			 else
			 {
				 System.out.println(" the FixedBilling Data verification failed");
			 }
			 //Adjustments
			 WebElement Adjustments_Value_element = driver.findElement(By.xpath("//td[10]//input[@style='BACKGROUND-COLOR:Lime']"));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Adjustments_Value_element);
			 Thread.sleep(500); 
			 String Argument_Value_Data = (Adjustments_Value_element.getAttribute("value")).replaceAll(",", "");;
			 System.out.println(Argument_Value_Data);
			 GenericFunctions.staticWait(2);
			 if(Argument_Value_Data.equals(Adjustment_Value))
			 {
				 System.out.println(" the Argument_Value Data has been verified successfully");
			 }
			 else
			 {
				 System.out.println(" the Argument_Value Data verification failed");
			 }
		     //Milestone
			 WebElement Milestone_Data_element = driver.findElement(By.xpath("//td[13]//input[@style='BACKGROUND-COLOR:Lime']"));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Milestone_Data_element);
			 Thread.sleep(500); 
			 String Milestone_Data = (Milestone_Data_element.getAttribute("value")).replaceAll(",", "");;
			 System.out.println(Milestone_Data);
			 GenericFunctions.staticWait(2);
			 if(Milestone_Data.equals(MilestoneBilling_Value))
			 {
				 System.out.println(" Milestone data has been verified successfully");
			 }
			 else
			 {
				 System.out.println(" Milestone data verification failed");
			 }
			 //Comments
			 WebElement comments_elements = driver.findElement(By.xpath("//textarea[contains(text(),'"+Comments+"')]"));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", comments_elements);
			 Thread.sleep(500); 
			 String comments_Data = (comments_elements.getText()).replaceAll(",", "");;
			 System.out.println(comments_Data);
			 GenericFunctions.staticWait(2);
			 if(comments_Data.equals(Comments))
			 {
				 System.out.println(" Comments data has been verified successfully");
			 }
			 else
			 {
				 System.out.println(" Comments data verification failed");
			 }
		     
		     
		 }	 
		
	} 
		 BrowserAction.click(LoginPageObjects.Billing_Save_NAME);
		 GenericFunctions.staticWait(4);		
		 GenericFunctions.checkAlert();
		 GenericFunctions.checkAlert();	
		 GenericFunctions.staticWait(2);
		 
		//}catch(Exception e)
		{
			System.out.println("uploading and verify_Fx_billing is failed");
		}
		// BrowserAction.click(loginpage_objects.Billing_Calculate_Finance_XPATH);			 			
		 
 }
	
	public static void Excel_Delete(String Excel_Path)
	{
	File file = new File(Excel_Path);
	 if(file.delete())
    System.out.println("file deleted");
	}
	
	
	public static void Billing_verify_Fx_Upload(String DownloadedPATH, String FixedBilling_Value,String Argument_Value,String MilestoneBilling_Value,String Comments) throws Exception{
		try{BrowserAction.click(LoginPageObjects.Billing_UploadExcel_NAME);
		BrowserAction.maximizeCurrentWindow();
		String currentWindow=driver.getWindowHandle(); 
		Set<String> set =driver.getWindowHandles();
		Iterator<String> itr= set.iterator();
		 while(itr.hasNext())
		 {
		 String Window2=itr.next();
		 if(!currentWindow.equals(Window2))
		 {
			 driver.switchTo().window(Window2);
			 GenericFunctions.staticWait(2);
			 BrowserAction.click(LoginPageObjects.Billing_ChooseFile_NAME);
			 //Copy file path into the window clipboard
			 Robot robo = new Robot();
			 StringSelection str = new StringSelection(DownloadedPATH);
			 GenericFunctions.staticWait(2);
			 Toolkit.getDefaultToolkit().getSystemClipboard().setContents(str,str);
			 //Pressing Control+V
			 robo.keyPress(KeyEvent.VK_CONTROL);
			 robo.keyPress(KeyEvent.VK_V);
			//Releasing Control+V
			 robo.keyRelease(KeyEvent.VK_CONTROL);
			 robo.keyRelease(KeyEvent.VK_V);
			 GenericFunctions.staticWait(2);
			//Pressing Enter
			 robo.keyPress(KeyEvent.VK_ENTER);
			 GenericFunctions.staticWait(2);
			//Releasing Enter
			 robo.keyRelease(KeyEvent.VK_ENTER);
			 
			 BrowserAction.click(LoginPageObjects.Billing_SubmitFile_NAME);
			 GenericFunctions.staticWait(3);
			 GenericFunctions.checkAlert();
			 GenericFunctions.checkAlert();
			 GenericFunctions.staticWait(2);
			 GenericFunctions.checkAlert();
			 GenericFunctions.staticWait(2);
			 driver.switchTo().window(currentWindow);
			 GenericFunctions.staticWait(2);
			//FixedBilling
				 WebElement FixedBilling_element = driver.findElement(By.xpath("//td[4]//input[@style='BACKGROUND-COLOR:Lime']"));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", FixedBilling_element);
			 String FixedBilling_Data = (FixedBilling_element.getAttribute("value")).replaceAll(",", "");
			 // String data_abc = FixedBilling_Data.replaceAll(",", "");
			 System.out.println(FixedBilling_Data);
			 GenericFunctions.staticWait(2);
			 if(FixedBilling_Value.equals(FixedBilling_Data))
			 {
				 System.out.println(" the FixedBilling Data has been verified successfully");
			 }
			 else
			 {
				 System.out.println(" the FixedBilling Data verification failed");
			 }
			 //adjustments
			 WebElement Argument_Value_element = driver.findElement(By.xpath("//td[7]//input[@style='BACKGROUND-COLOR:Lime']"));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Argument_Value_element);
			 Thread.sleep(500); 
			 String Argument_Value_Data = (Argument_Value_element.getAttribute("value")).replaceAll(",", "");;
			 System.out.println(Argument_Value_Data);
			 GenericFunctions.staticWait(2);
			 if(Argument_Value_Data.equals(Argument_Value))
			 {
				 System.out.println(" the Argument_Value Data has been verified successfully");
			 }
			 else
			 {
				 System.out.println(" the Argument_Value Data verification failed");
			 }
		     //Milestone
			 WebElement Milestone_Data_element = driver.findElement(By.xpath("//td[8]//input[@style='BACKGROUND-COLOR:Lime']"));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", Milestone_Data_element);
			 Thread.sleep(500); 
			 String Milestone_Data = (Milestone_Data_element.getAttribute("value")).replaceAll(",", "");;
			 System.out.println(Milestone_Data);
			 GenericFunctions.staticWait(2);
			 if(Milestone_Data.equals(MilestoneBilling_Value))
			 {
				 System.out.println(" Milestone data has been verified successfully");
			 }
			 else
			 {
				 System.out.println(" Milestone data verification failed");
			 }
			 //Comments
			 WebElement comments_elements = driver.findElement(By.xpath("//textarea[contains(text(),'"+Comments+"')]"));
			 ((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", comments_elements);
			 Thread.sleep(500); 
			 String comments_Data = (comments_elements.getText()).replaceAll(",", "");;
			 System.out.println(comments_Data);
			 GenericFunctions.staticWait(2);
			 if(comments_Data.equals(Comments))
			 {
				 System.out.println(" Comments data has been verified successfully");
			 }
			 else
			 {
				 System.out.println(" Comments data verification failed");
			 }
		 }	 
		
	 } 
		 BrowserAction.click(LoginPageObjects.Billing_Save_NAME);
		 GenericFunctions.staticWait(4);		
		 GenericFunctions.checkAlert();
		 GenericFunctions.checkAlert();	
		 GenericFunctions.staticWait(2);
		 
		 File file = new File(DownloadedPATH);
		 if(file.delete())
	     System.out.println("file deleted");
		}catch(Exception e)
		{
			System.out.println("uploading and verify_Fx_billing is failed");
		}
		// BrowserAction.click(loginpage_objects.Billing_Calculate_Finance_XPATH);		
	}
		 
		 public static void Excel_Export_FX_Verify_Data(String DownloadedPATH,int RowCount,String FixedBilling_Value,String Argument_Value,String MilestoneBilling_Value,String Comments )throws IOException{
				//String Filename ="C://Users//sanjanar//Downloads//BillingStreamReport.xlsx";
				FileInputStream fis = new FileInputStream(DownloadedPATH);
				Workbook WB = new XSSFWorkbook(fis);
				GenericFunctions.staticWait(2);
				Sheet Sheet= WB.getSheetAt(0);
				int Expected_RowCount = RowCount+4;
				Row row = Sheet.getRow(Expected_RowCount);
				//FixedBilling
				Cell cell = row.getCell(4);		
				String FixedBilling = Double.toString(cell.getNumericCellValue());
				System.out.println("the data present in the cell is "+cell);
				if(FixedBilling.equals(FixedBilling_Value))
				{
					System.out.println("the FixedBilling data in the exported excel file is verified Succesfully");
				}
				else
				{
					System.out.println("the data verification in the exported excel file is failed");
				}
			}
		 
		 /*public static void select_by_VisibleText(WebElement Ele,String Text)
		 {
			 Select select1 = new Select(Ele);
				select1.selectByVisibleText(Text);
		 }
		 */
		 
		 public static void select_by_index(WebElement Ele,int Index)
		 {
			 Select select = new Select(Ele);
				select.selectByIndex(Index);
		 }
		 
		 
		 
		 
		 public static String Store_Schedule_event_Year() throws Exception
		 {  
			 BrowserAction.click(LoginPageObjects.Reconfigure_Schedule_XPATH);
			 //driver.findElement(By.xpath("//*[@id='statusBarEventSch']//font[contains(text(),'Schedule')]")).click();
			 GenericFunctions.staticWait(1);
			 WebElement ele_text =  driver.findElement(By.xpath("//span[contains(@style,'color: #0000FF')][1]/../.."));
			 WebElement ele_desc =  driver.findElement(By.xpath("//span[contains(@style,'color: #0000FF')][1]/../.."));
			 String text_EventName = ele_text.getText();
			 System.out.println("the first event name is "+text_EventName);
		     String desc_EventDetail= ele_desc.getAttribute("title");
			 System.out.println(desc_EventDetail);
			 String[] parts = desc_EventDetail.split("/");
			 String str1 = parts[0]; // 004
			 String str2 = parts[1];
			 String str3 = parts[2];
			 System.out.println(str3);
			 String res = str3.substring(0, 4);
			 //String res = str2.substring(0, 10);
			 return res;
			 
		 }
		 
		 public static String Store_Schedule_event_date() throws Exception
		 {  
			 BrowserAction.click(LoginPageObjects.Reconfigure_Schedule_XPATH);
			 //driver.findElement(By.xpath("//*[@id='statusBarEventSch']//font[contains(text(),'Schedule')]")).click();
			 GenericFunctions.staticWait(1);
			 WebElement ele_text =  driver.findElement(By.xpath("//span[contains(@style,'color: #0000FF')][1]/../.."));
			 WebElement ele_desc =  driver.findElement(By.xpath("//span[contains(@style,'color: #0000FF')][1]/../.."));
			 String EventName = ele_text.getText();
			 System.out.println("the first event name is "+EventName);
		     String desc_EventDetail= ele_desc.getAttribute("title");
			 System.out.println(desc_EventDetail);
			 String[] parts = desc_EventDetail.split("Start Date:");
			 String str1 = parts[0]; // 004
			 String str2 = parts[1];
			 String res = str2.substring(0, 10);
			 System.out.println(res);
			 return res;
			 
		 }
		 
		 public static String Store_Schedule_event_name() throws Exception
		 {  
			 BrowserAction.click(LoginPageObjects.Reconfigure_Schedule_XPATH);
			 //driver.findElement(By.xpath("//*[@id='statusBarEventSch']//font[contains(text(),'Schedule')]")).click();
			 GenericFunctions.staticWait(1);
			 WebElement ele_text =  driver.findElement(By.xpath("//span[contains(@style,'color: #0000FF')][1]/../.."));
			 WebElement ele_desc =  driver.findElement(By.xpath("//span[contains(@style,'color: #0000FF')][1]/../.."));
			 String EventName = ele_text.getText();
			 System.out.println("the first event name is "+EventName);
			 return EventName;
			 
		 }
		 
		 public static void AddCPL(String Event_Name,String Custom_Section) throws Exception
		 {  
			String Window2= "";
			String Window3="";
			String Partkit_Desc = "";
			String Window4= "";
			String Window5="";
			
			 driver.findElement(By.xpath("//span[text()='"+Event_Name+"']")).click();
			 GenericFunctions.staticWait(5);
			 
			    String Window1=driver.getWindowHandle(); 
				Set<String> set1 =driver.getWindowHandles();
				Iterator<String> itr1= set1.iterator();
				 while(itr1.hasNext())
				 {
				 Window2=itr1.next();
				 if(!Window1.equals(Window2))
				 {
					 driver.switchTo().window(Window2);
					 GenericFunctions.staticWait(2);
					 Partkit_Desc= BrowserAction.getElementText(LoginPageObjects.AddCPL_TablefirstPartKit_XPATH).trim();
					 BrowserAction.click(LoginPageObjects.AddCPL_TablefirstPartKit_XPATH);
					 GenericFunctions.staticWait(3);
					 Set<String> set2 =driver.getWindowHandles();
						Iterator<String> itr2= set2.iterator();
						 while(itr2.hasNext())
						 {  
							 String WindowName = itr2.next();
							 if (!WindowName.equals(Window1) && !WindowName.equals(Window2))
							 {
						         Window3=WindowName;					         
							     driver.switchTo().window(Window3);	
							     BrowserAction.maximizeCurrentWindow();
							     GenericFunctions.staticWait(2);
						         break;
							 }   
						 }
					 
				 }
				 }
				 
				 if(Custom_Section.equalsIgnoreCase("Custom Section Limits"))
				 
				{  driver.findElement(By.xpath("//table[@class='tbl_bg2_content']//*[contains(text(),'"+Custom_Section+"')]")).click();
				 
				   int count = driver.getWindowHandles().size();
				   System.out.println(" the window count is "+count);
				 
				    Set<String> set5 =driver.getWindowHandles();
				    Iterator<String> itr5= set5.iterator();
				    while(itr5.hasNext())
				   {  
					 String WindowName01 = itr5.next();
					 driver.switchTo().window(WindowName01);
					 String Title = driver.getTitle();
					 if(Title.equalsIgnoreCase("ICAM Config - Custom Section Limits"))
						 
					 {
						 break;
					 }
					 
				    }
				}
				 
				 if(Custom_Section.equalsIgnoreCase("Custom Part Kit"))
					 
					{  driver.findElement(By.xpath("//table[@class='tbl_bg2_content']//*[contains(text(),'"+Custom_Section+"')]")).click();
					 
					   int count = driver.getWindowHandles().size();
					   System.out.println(" the window count is "+count);
					 
					    Set<String> set5 =driver.getWindowHandles();
					    Iterator<String> itr5= set5.iterator();
					    while(itr5.hasNext())
					   {  
						 String WindowName01 = itr5.next();
						 driver.switchTo().window(WindowName01);
						 String Title = driver.getTitle();
						 if(Title.equalsIgnoreCase("ICAM Config - Custom Part Limits"))
							 
						 {
							 break;
						 }
						 
					    }
					}
					 
				 
				 Thread.sleep(4000);
				 
				 BrowserAction.maximizeCurrentWindow();
				
				 BrowserAction.click(LoginPageObjects.AddCPL_AddCustomDetails_XPATH);	 
			
				 String Current_Date = GenericFunctions.getCurrentTimeStamp();
				 String End_Date = add_Days_tothe_CurrentDate();
				 
				 BrowserAction.enterFieldValue(LoginPageObjects.AddCPL_StartDate_XPATH, Current_Date);
				 BrowserAction.enterFieldValue(LoginPageObjects.AddCPL_EndDate_XPATH, End_Date);
				 System.out.println(Current_Date);
				 System.out.println(End_Date);	
				 BrowserAction.selectDropdownOptionByText(LoginPageObjects.AddCPL_Reason_NAME, "Other");
				 BrowserAction.click(LoginPageObjects.AddCPL_Save_XPATH);
				 GenericFunctions.staticWait(2);
 				 driver.switchTo().window(Window2);				
 				 BrowserAction.click(LoginPageObjects.AddCPL_Save_ICAMEventDetail_XPATH);
 				 GenericFunctions.checkAlert();	
 				 GenericFunctions.staticWait(10);
 				 driver.switchTo().window(Window1);	
 				 
 				 if( driver.findElements(By.xpath("//span[contains(@style,'color: #0000FF')][1]/../..")).size() != 0)
 				   {System.out.println("The Schedule is not cleared");}
 				 else
 				   {System.out.println("The Schedule is cleared successfully");}
 				 
 				LoginObjects.schedule();
				 
 				 driver.findElement(By.xpath("//span[text()='"+Event_Name+"']")).click();
 				 GenericFunctions.staticWait(5);
 				 
 				    
 					Set<String> set3 =driver.getWindowHandles();
 					Iterator<String> itr3= set3.iterator();
 					 while(itr3.hasNext())
 					 {
 					 Window4=itr3.next();
 					 if(!Window1.equals(Window4))
 					 {
 						 driver.switchTo().window(Window4);
 						 GenericFunctions.staticWait(2);
 						 Partkit_Desc= BrowserAction.getElementText(LoginPageObjects.AddCPL_TablefirstPartKit_XPATH).trim();
 						 BrowserAction.click(LoginPageObjects.AddCPL_TablefirstPartKit_XPATH);
 						 GenericFunctions.staticWait(2);
 						 Set<String> set4 =driver.getWindowHandles();
 							Iterator<String> itr4= set4.iterator();
 							 while(itr4.hasNext())
 							 {  
 								 String WindowName = itr4.next();
 								 if (!WindowName.equals(Window1) && !WindowName.equals(Window4))
 								 {
 							         Window5=WindowName;					         
 								     driver.switchTo().window(Window5);							    
 							         break;
 								 }   
 							 }
 						 
 					 }
 					 }
 					 
 					 
 					if(Custom_Section.equalsIgnoreCase("Custom Section Limits"))
 						 
 					{  driver.findElement(By.xpath("//table[@class='tbl_bg2_content']//*[contains(text(),'"+Custom_Section+"')]")).click();
 					 
 					   int count = driver.getWindowHandles().size();
 					   System.out.println(" the window count is "+count);
 					 
 					    Set<String> set5 =driver.getWindowHandles();
 					    Iterator<String> itr5= set5.iterator();
 					    while(itr5.hasNext())
 					   {  
 						 String WindowName01 = itr5.next();
 						 driver.switchTo().window(WindowName01);
 						 String Title = driver.getTitle();
 						 if(Title.equalsIgnoreCase("ICAM Config - Custom Section Limits"))
 							 
 						 {
 							 break;
 						 }
 						 
 					    }
 					}
 					 
 					 if(Custom_Section.equalsIgnoreCase("Custom Part Kit"))
 						 
 						{  driver.findElement(By.xpath("//table[@class='tbl_bg2_content']//*[contains(text(),'"+Custom_Section+"')]")).click();
 						 
 						   int count = driver.getWindowHandles().size();
 						   System.out.println(" the window count is "+count);
 						 
 						    Set<String> set5 =driver.getWindowHandles();
 						    Iterator<String> itr5= set5.iterator();
 						    while(itr5.hasNext())
 						   {  
 							 String WindowName01 = itr5.next();
 							 driver.switchTo().window(WindowName01);
 							 String Title = driver.getTitle();
 							 if(Title.equalsIgnoreCase("ICAM Config - Custom Part Limits"))
 								 
 							 {
 								 break;
 							 }
 							 
 						    }
 						}
 						 
 					 
 					 Thread.sleep(4000);
 					 
 					 BrowserAction.maximizeCurrentWindow();
 					
 					 
 					 BrowserAction.click(LoginPageObjects.AddCPL_AddCustomDetails_XPATH);
 					 
 				    String Current_Date_After_Schedule = BrowserAction.getElementAttributeValue(LoginPageObjects.AddCPL_StartDate_XPATH, "value");
 					String End_Date_After_Schedule = BrowserAction.getElementAttributeValue(LoginPageObjects.AddCPL_EndDate_XPATH, "value");
 					
 					if (Current_Date_After_Schedule.equals(Current_Date))
					 {System.out.println("the Start date is matched successfully");}
 					if (End_Date_After_Schedule.equals(End_Date))
					 {System.out.println("the Start date is matched successfully");} 
			
 					
		 }
		 
		
		 public static String add_Days_tothe_CurrentDate()
		 {   
			 SimpleDateFormat formDate = new SimpleDateFormat("MM/dd/yyyy");
			 Calendar cal = Calendar.getInstance();  
			 cal.add(Calendar.DAY_OF_MONTH,30);
			 String newDate = formDate.format(cal.getTime());  
			 return newDate;
		 }
		 
		 public static String get_equipment_name() throws Exception
		 {  
			 String Name1= BrowserAction.getElementText(LoginPageObjects.Reconfigure_FirstEquipmet_XPATH);
			//String Name1=  driver.findElement(By.xpath("//input[@id='equipid1']/..")).getText();
			String Name2 = Name1.replace("\n","");	
			String Equip_Name  = Name2.replace("(1)","");
			System.out.println(Equip_Name);
			return Equip_Name.trim();	
			
		 }
		 
		 public static void Reconfigure(String EquipmentName) throws Exception
		 {
			 String EquipName = " "+EquipmentName;
			 String PartKit_ID ="";
			 String PartKit_Desc = "";
			 System.out.println(EquipName);
			 BrowserAction.click(LoginPageObjects.Reconfigure_ReconfigureButton_XPATH);
			 String currentWindow=driver.getWindowHandle(); 
				Set<String> set1 =driver.getWindowHandles();
				Iterator<String> itr1= set1.iterator();
				 while(itr1.hasNext())
				 {
				 String Window2=itr1.next();
				 if(!currentWindow.equals(Window2))
				 {
					 driver.switchTo().window(Window2);
					 GenericFunctions.staticWait(5);
					 BrowserAction.click(LoginPageObjects.Reconfigure_RenconfigSelection_DD_XPATH);
					 //select_by_VisibleText(LoginPageObjects.Reconfigure_RenconfigSelection_DD_XPATH,EquipName);
					 BrowserAction.selectDropdownOptionByText(LoginPageObjects.Reconfigure_RenconfigSelection_DD_XPATH,EquipName);
					 GenericFunctions.staticWait(3);
					 BrowserAction.click(LoginPageObjects.Reconfigure_ChooseRenconfig_Radio_XPATH);
					 BrowserAction.click(LoginPageObjects.Reconfigure_AddButton_XPATH);
					 GenericFunctions.staticWait(2);				 
					 BrowserAction.click(LoginPageObjects.Reconfigure_DateDependNo_XPATH);
					 BrowserAction.click(LoginPageObjects.Reconfigure_DateDependNext_XPATH);
					 //Set<String> set2 =driver.getWindowHandles();
					 driver.switchTo().window(Window2);
					 
					 WebElement partkit_Select = driver.findElement(By.id("prtKitID_14_9"));
					 PartKit_ID = PartKitgetSelected_DDValue(partkit_Select);
					 BrowserAction.click(LoginPageObjects.Reconfigure_DeterminPartKit_XPATH);
					 GenericFunctions.staticWait(2);	
					 //Set<String> set3 =driver.getWindowHandles();
					 driver.switchTo().window(Window2);
					 System.out.println(driver.getTitle());
					 PartKit_Desc = get_Selected_PartKit_Desc_CAP();
					 System.out.println(PartKit_Desc);
					 driver.switchTo().window(currentWindow);
					 System.out.println(driver.getTitle());
					 BrowserAction.click(LoginPageObjects.schedule_XPATH);
					 GenericFunctions.checkAlert();
					 GenericFunctions.staticWait(2);
					 if(driver.findElement(By.xpath("//span[contains(text(),'Recon') and contains(@style,'color: #0000FF')]")).isDisplayed())
					 {
						 System.out.println("the Reconf is successfull and is present in the event table");
					 }
					 else
					 {
						 System.out.println("the Reconf is failed");
					 }
					 WebElement ele_text =  driver.findElement(By.xpath("//span[contains(@style,'color: #0000FF')][1]/../.."));
					 ele_text.click();
					 GenericFunctions.staticWait(1);	
					 System.out.println(driver.getTitle());
                     
				 }
				 }
				 Set<String> set4 =driver.getWindowHandles();
				 Iterator<String> itr2= set4.iterator();
				 System.out.println(driver.getTitle());
				 while(itr2.hasNext())
				 {
				 String Window2=itr2.next();
				 if(!currentWindow.equals(Window2))
				 {    
					 System.out.println(driver.getTitle());			 
					driver.switchTo().window(Window2);
					System.out.println(driver.getTitle());
					validate_PartDesc_Flow(PartKit_Desc);
					
					
				 }
				 }
				 
		 }
		 
		 public static void validate_PartDesc_Flow(String PartKit_Desc)
		 {
			 WebElement ele =  driver.findElement(By.xpath("//*[contains(text(),'"+PartKit_Desc+"')]"));
			 //driver.findElement(By.xpath("//*[contains(text(),"+PartKit_Desc+")]")).click();
			 if(ele!=null)
			 {
				 String PartKit_Flow = driver.findElement(By.xpath("//*[contains(text(),'"+PartKit_Desc+"')]/../../..//td[2]//*[contains(text(),'OUT')]")).getText();
				 if(PartKit_Flow.equals("OUT"))
				 {
					 System.out.println("the partkit is successfully reconfigured and the flow for the "+PartKit_Desc+" is "+PartKit_Flow);
				 }
				 else
				 {
					 System.out.println("the partkit reconfiguration is failed and the flow is not as expected");
				 }
			 }
			 
		 }
		 
		 public static String get_Selected_PartKit_Desc_CAP() throws Exception
		 {   
			 String PartKit_Desc = "";
			 WebElement ele = driver.findElement(By.xpath("//table[@id='LowerDataTable']//tr[1]//td[3][contains(text(),'CAP')]"));

			 if(ele!= null)
			     {
				PartKit_Desc = driver.findElement(By.xpath("//table[@id='LowerDataTable']//tr[1]//td[3][contains(text(),'CAP')]")).getText();
				Select select = new Select(driver.findElement(By.xpath("//select[@name='prtStatus_0']")));
				select.selectByValue("SCRAP");				
				driver.findElement(By.xpath("//select[@name='prtStatus_0']/../../td/input")).click(); 
				System.out.println("Element is Present");
				BrowserAction.click(LoginPageObjects.Reconfigure_AddReplaceButton_XPATH);
				
				GenericFunctions.checkAlert();
				GenericFunctions.checkAlert();
				//return PartKit_Desc;
				}
			 else{
				 System.out.println("Element is Absent");
				 }
			return PartKit_Desc;		 
		 }

		 
		 
		 public static String PartKitgetSelected_DDValue(WebElement Ele)
		 {  
			String PartKit_ID = "";
			Select select = new Select(Ele);
			WebElement Option  = select.getFirstSelectedOption();
			String PartKitID_Before = (Option.getText()).trim();
			String PartKitID_After ="";
			List<WebElement> PartKit_Options = select.getOptions();
			int count = PartKit_Options.size();
			for (int i = 0; i < count; i++) {
				PartKit_ID = (PartKit_Options.get(i).getText()).trim();
				//if (!Event_Name.equals("EOTE") || !Event_Name.equals("Recon")) {
				if(!PartKit_ID.equals(PartKitID_Before) && !PartKit_ID.equals("Select"))
				{
					select.selectByValue(PartKit_ID);
					break;
				}
							
			}
			return PartKit_ID;
		 }
		
		 public static void ExcelCompare(String Filename1, String Filename2) {
		        try {
		            // get input excel files
		            System.out.println("Welcome");
		            FileInputStream excellFile1 = new FileInputStream(Filename1);
		            FileInputStream excellFile2 = new FileInputStream(Filename2);

		            // Create Workbook instance holding reference to .xlsx file
		            XSSFWorkbook workbook1 = new XSSFWorkbook(excellFile1);
		            XSSFWorkbook workbook2 = new XSSFWorkbook(excellFile2);

		            // Get first/desired sheet from the workbook
		            XSSFSheet sheet1 = workbook1.getSheetAt(0);
		            XSSFSheet sheet2 = workbook2.getSheetAt(0);

		            // Compare sheets
		            if(LoginObjects.compareTwoSheets(sheet1, sheet2)) {
		                System.out.println("\n\nThe two excel sheets are Equal");
		            } else {
		                System.err.println("\n\nThe two excel sheets are Not Equal");
		            }
		           
		            //close files
		            excellFile1.close();
		            excellFile2.close();

		        } catch (Exception e) {
		            e.printStackTrace();
		        }

		    }
		 
		 public static boolean compareTwoSheets(XSSFSheet sheet1, XSSFSheet sheet2) {
			  // TODO Auto-generated method stub
			   int firstRow1 = sheet1.getFirstRowNum();
			         int lastRow1 = sheet1.getLastRowNum();
			         boolean equalSheets = true;
			         for(int i=firstRow1; i <= lastRow1; i++) {
			           
			             System.out.println("\n\nComparing Row "+i);
			           
			             XSSFRow row1 = sheet1.getRow(i);
			             XSSFRow row2 = sheet2.getRow(i);
			             if(!compareTwoRows(row1, row2)) {
			                 equalSheets = false;
			                 System.err.println("Row "+i+" - Not Equal");
			                 break;
			             } else {
			                 System.out.println("Row "+i+" - Equal");
			             }
			         }
			         return equalSheets;
			 }

			 public static boolean compareTwoRows(XSSFRow row1, XSSFRow row2) {
		
			   if((row1 == null) && (row2 == null)) {
			             return true;
			         } else if((row1 == null) || (row2 == null)) {
			             return false;
			         }
			       
			         int firstCell1 = row1.getFirstCellNum();
			         int lastCell1 = row1.getLastCellNum();
			         boolean equalRows = true;
			       
			         // Compare all cells in a row
			         for(int i=firstCell1; i <= lastCell1; i++) {
			             XSSFCell cell1 = row1.getCell(i);
			             XSSFCell cell2 = row2.getCell(i);
			             if(!compareTwoCells(cell1, cell2)) {
			                 equalRows = false;
			                 System.err.println("       Cell "+i+" - NOt Equal");
			                 break;
			             } else {
			                 System.out.println("       Cell "+i+" - Equal");
			             }
			         }
			         return equalRows;
			 }

			 @SuppressWarnings("deprecation")
			public static boolean compareTwoCells(XSSFCell cell1, XSSFCell cell2) {
			   if((cell1 == null) && (cell2 == null)) {
			             return true;
			         } else if((cell1 == null) || (cell2 == null)) {
			             return false;
			         }
			       
			         boolean equalCells = false;
			         int type1 = cell1.getCellType();
			         int type2 = cell2.getCellType();
			         if (type1 == type2) {
			             if (cell1.getCellStyle().equals(cell2.getCellStyle())) {
			                 // Compare cells based on its type
			                 switch (cell1.getCellType()) {
			                 case HSSFCell.CELL_TYPE_FORMULA:
			                     if (cell1.getCellFormula().equals(cell2.getCellFormula())) {
			                         equalCells = true;
			                     }
			                     break;
			                 case HSSFCell.CELL_TYPE_NUMERIC:
			                     if (cell1.getNumericCellValue() == cell2
			                             .getNumericCellValue()) {
			                         equalCells = true;
			                     }
			                     break;
			                 case HSSFCell.CELL_TYPE_STRING:
			                     if (cell1.getStringCellValue().equals(cell2
			                             .getStringCellValue())) {
			                         equalCells = true;
			                     }
			                     break;
			                 case HSSFCell.CELL_TYPE_BLANK:
			                     if (cell2.getCellType() == HSSFCell.CELL_TYPE_BLANK) {
			                         equalCells = true;
			                     }
			                     break;
			                 case HSSFCell.CELL_TYPE_BOOLEAN:
			                     if (cell1.getBooleanCellValue() == cell2
			                             .getBooleanCellValue()) {
			                         equalCells = true;
			                     }
			                     break;
			                 case HSSFCell.CELL_TYPE_ERROR:
			                     if (cell1.getErrorCellValue() == cell2.getErrorCellValue()) {
			                         equalCells = true;
			                     }
			                     break;
			                 default:
			                     if (cell1.getStringCellValue().equals(
			                             cell2.getStringCellValue())) {
			                         equalCells = true;
			                     }
			                     break;
			                 }
			             } else {
			                 return false;
			             }
			         } else {
			             return false;
			         }
			         return equalCells;
			 }

			 public static String download_and_ReturnFilePath(LoginPageObjects downloadreportXpath,String Filename) {
					

						try {
							BrowserWait.waitUntilElementIsDisplayed(downloadreportXpath);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						try {
							BrowserAction.click(downloadreportXpath);
							
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						System.out.println("Downloading report");
						
						SimpleDateFormat formDate = new SimpleDateFormat("MM-dd-yyyy");
					    String strDate = formDate.format(new Date());
					    
					    GenericFunctions.staticWait(8);
					    
					    SimpleDateFormat formTime = new SimpleDateFormat("HH-mm-ss");
					    String strtime = formTime.format(new Date());
					    
					    GenericFunctions.staticWait(4);
					    
						Path path = FileSystems.getDefault().getPath(System.getProperty("user.home"), "Downloads");
			            String DownloadedPATH = path + "\\" +Filename+"_"+strDate+".xlsx" ;
			            String NewPathName =  path + "\\" +Filename+"_"+strDate+strtime+".xlsx";
			            
			            GenericFunctions.staticWait(2);
			            
			            File file = new File(DownloadedPATH);
			            GenericFunctions.staticWait(1);
			            File newFile = new File(NewPathName);
			            
			            GenericFunctions.staticWait(7);
			            
			            file.renameTo(newFile);
			            
			            System.out.println("the downloaded excel is renamed from "+DownloadedPATH+" to "+ NewPathName);
						return NewPathName;
						//return new String[]{DownloadedPATH, NewPathName};


				}
			 
			 
			 public static void RevPdfdownload_17(){
				 try {
					 	LoginObjects.report();
						GenericFunctions.driver.switchTo().frame(1);
						BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Priordropdown_XPATH);
						LoginObjects.selectValueFrompriorDropdownByName("priorMdlVer","USER174");
						GenericFunctions.staticWait(10);
						LoginObjects.SelectPrior();
						GenericFunctions.staticWait(10);
					} catch (TimeoutException e) {
						Assert.fail("Unable to locate the element.\n" + e.getMessage());
					} catch (Exception e) {
						Assert.fail("pressacceptBtn \n" + e.getMessage());
					} 
			 }
			 
			 public static void RevPdfdownload_18(){
				 try {
					 	LoginObjects.report();
						GenericFunctions.driver.switchTo().frame(1);
						BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Priordropdown_XPATH);
						LoginObjects.selectValueFrompriorDropdownByName("priorMdlVer","USER175");
						GenericFunctions.staticWait(10);
						LoginObjects.SelectPrior();
						GenericFunctions.staticWait(10);
					} catch (TimeoutException e) {
						Assert.fail("Unable to locate the element.\n" + e.getMessage());
					} catch (Exception e) {
						Assert.fail("pressacceptBtn \n" + e.getMessage());
					} 
			 }
			 
			 public static void RevPdfdownload_19(){
				 try {
					 	LoginObjects.report();
						GenericFunctions.driver.switchTo().frame(1);
						BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Priordropdown_XPATH);
						LoginObjects.selectValueFrompriorDropdownByName("priorMdlVer","USER152");
						GenericFunctions.staticWait(10);
						LoginObjects.SelectPrior();
						GenericFunctions.staticWait(10);
					} catch (TimeoutException e) {
						Assert.fail("Unable to locate the element.\n" + e.getMessage());
					} catch (Exception e) {
						Assert.fail("pressacceptBtn \n" + e.getMessage());
					} 
			 }
			 
			 public static void RevPdfdownload_20(){
				 try {
					 	LoginObjects.report();
						GenericFunctions.driver.switchTo().frame(1);
						BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Priordropdown_XPATH);
						LoginObjects.selectValueFrompriorDropdownByName("priorMdlVer","USER173");
						GenericFunctions.staticWait(10);
						LoginObjects.SelectPrior();
						GenericFunctions.staticWait(10);
					} catch (TimeoutException e) {
						Assert.fail("Unable to locate the element.\n" + e.getMessage());
					} catch (Exception e) {
						Assert.fail("pressacceptBtn \n" + e.getMessage());
					} 
			 }
			 
			 public static void RevExceldownload(){
				 try {
					 	GenericFunctions.driver.switchTo().defaultContent();
						GenericFunctions.driver.switchTo().frame("navFrame");
						LoginObjects.RRR_revenue_ImageButton();
						LoginObjects.clickRRRforrevenue();
						GenericFunctions.driver.switchTo().frame(1);
						GenericFunctions.checkAlert();
						LoginObjects.ModelVersion();
						GenericFunctions.checkAlert();
						GenericFunctions.checkAlert();
						
					} catch (TimeoutException e) {
						Assert.fail("Unable to locate the element.\n" + e.getMessage());
					} catch (Exception e) {
						Assert.fail("pressacceptBtn \n" + e.getMessage());
					} 
			 }
			 
			 public static void FleetRepairReport(){
				 try {
					 	LoginObjects.FleetReport();
						LoginObjects.FleetRRR();
						LoginObjects.selectValueFromDropdownFleet("select4", "10016 - Testing AR_FLEET_PG_TestingFleet2_ManualEventIssue_vk_eot1");
						GenericFunctions.staticWait(5);
						LoginObjects.GeneratorButton();
						LoginObjects.PartkitRegression();
					} catch (TimeoutException e) {
						Assert.fail("Unable to locate the element.\n" + e.getMessage());
					} catch (Exception e) {
						Assert.fail("pressacceptBtn \n" + e.getMessage());
					} 
			 }

public static void report() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.CR_REPORT_XPATH);
			BrowserAction.click(LoginPageObjects.CR_REPORT_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}

	}

public static void SelectPrior() {
					try {
						driver.findElement(By.xpath("//*[@id=\"cvlink\"]")).click();
						System.out.println("Link clicked");
					} catch (TimeoutException e) {
						Assert.fail("Unable to locate the element.\n" + e.getMessage());
					} catch (Exception e) {
						Assert.fail("something went wrong \n" + e.getMessage());
					}

				}

 public static void RRR_revenue_ImageButton() {
					try {
						GenericFunctions.staticWait(10);
						driver.findElement(By.xpath("//a[text()=\"Model Reports\"]")).click();
						System.out.println("Button clicked");

					} catch (TimeoutException e) {
						Assert.fail("Unable to locate the element.\n" + e.getMessage());
					} catch (Exception e) {
						Assert.fail("pressacceptBtn \n" + e.getMessage());
					}

				}
			 
public static void clickRRRforrevenue() {
					try {

						BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.RRR_revenue_XPATH);
						BrowserAction.click(LoginPageObjects.RRR_revenue_XPATH);

						System.out.println("RRR clicked");

					} catch (TimeoutException e) {
						Assert.fail("Unable to locate the element.\n" + e.getMessage());
					} catch (Exception e) {
						Assert.fail("pressacceptBtn \n" + e.getMessage());
					}

				}
public static void ModelVersion() {
					try {
						Select s = new Select(driver.findElement(By.xpath("//*[@id=\"select9\"]")));
						s.selectByIndex(2);
						System.out.println("Model version selected");

					} catch (TimeoutException e) {
						Assert.fail("Unable to locate the element.\n" + e.getMessage());
					} catch (Exception e) {
						Assert.fail("pressacceptBtn \n" + e.getMessage());
					}

				}

public static void FleetRegression() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Fleet_RRR_type_XPATH);
		BrowserAction.click(LoginPageObjects.Fleet_RRR_type_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}

}

public static void FleetReport() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Fleet_image_XPATH);
		BrowserAction.click(LoginPageObjects.Fleet_image_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}

}

public static void FleetRRR() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Fleet_Report_XPATH);
		BrowserAction.click(LoginPageObjects.Fleet_Report_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}

}


public static void selectValueFromDropdownFleet(String labelID, String value){
	try{
	GenericFunctions.staticWait(5);
	WebElement element = driver.findElement(By.xpath("//table/tbody/tr[*]/td[*]/table/tbody/tr[*]/td[*]/span/select[@id='"+labelID+"']"));
	element.isDisplayed();
	element.click();
	System.out.println("Successfully clicked on dropdown");
	WebElement valueLocator = driver.findElement(By.xpath("	//table/tbody/tr[*]/td[*]/table/tbody/tr[*]/td[*]/span/select[@id='"+labelID+"']/option[contains(text(),'"+value+"')]"));
	valueLocator.click();
	System.out.println("Dropdown value: "+value+" selected successfully");
	
	}catch(Exception e){
		System.out.println("selectValueFromDropdown :: Exception :: "+e.getMessage());
		Assert.fail("selectValueFromDropdown :: Exception :: "+e.getMessage());
	}
}

public static void selectValueFrompriorDropdownByName(String name, String value){
	try{
	GenericFunctions.staticWait(5);
	WebElement element = driver.findElement(By.xpath("(//table/tbody/tr[*]/td[*]/table/tbody/tr[*]/td[*]/select[@name='"+name+"'])[1]"));
	element.isDisplayed();
	element.click();
	System.out.println("Successfully clicked on dropdown");
	WebElement valueLocator = driver.findElement(By.xpath("(//table/tbody/tr[*]/td[*]/table/tbody/tr[*]/td[*]/select[@name='"+name+"'])[1]/option[contains(text(),'"+value+"')]"));
	valueLocator.click();
	System.out.println("Dropdown value: "+value+" selected successfully");
	
	}catch(Exception e){
		System.out.println("selectValueFromDropdown :: Exception :: "+e.getMessage());
		Assert.fail("selectValueFromDropdown :: Exception :: "+e.getMessage());
	}
}
	
public static void GeneratorButton() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Generator_ID);
		BrowserAction.click(LoginPageObjects.Generator_ID);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
} 


public static void PartkitRegression() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Select_partkit_NAME);
		Select s = new Select(driver.findElement(By.name("partKitId")));
		s.selectByIndex(2);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
} 

public static void Finance_tab() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Finance_Tab_XPATH);
		BrowserAction.click(LoginPageObjects.Finance_Tab_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void SaveChanges() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Save_change_XPATH);
		BrowserAction.click(LoginPageObjects.Save_change_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void FinancialScreen() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Financials_screen_XPATH);
		BrowserAction.click(LoginPageObjects.Financials_screen_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
} 


public static void Schedule_page() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Reconfigure_Schedule_XPATH);
		BrowserAction.click(LoginPageObjects.Reconfigure_Schedule_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
} 

public static void EnterEventDate(String strDate) {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Add_eventdate_XPATH);
		BrowserAction.clear(LoginPageObjects.Add_eventdate_XPATH);
		BrowserAction.enterFieldValue(LoginPageObjects.Add_eventdate_XPATH, strDate);
		System.out.println("start date " +strDate);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (NoSuchElementException e) {
		Assert.fail("Unable to enter event date.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("Something went wrong.\n" + e.getMessage());
	}
}

public static void EnterComments(String comment) {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Add_comment_XPATH);
		BrowserAction.enterFieldValue(LoginPageObjects.Add_comment_XPATH, comment);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (NoSuchElementException e) {
		Assert.fail("Unable to enter comment.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("Something went wrong.\n" + e.getMessage());
	}
}

public static void AddButtonEvent() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Add_button_XPATH);
		BrowserAction.click(LoginPageObjects.Add_button_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void UpdateEvent() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.UpdateEvent_Button_XPATH);
		BrowserAction.click(LoginPageObjects.UpdateEvent_Button_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void DeleteButton() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.DeleteEvent_Button_XPATH);
		BrowserAction.click(LoginPageObjects.DeleteEvent_Button_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void manual_event() {
 try {
		
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Add_manualevent_XPATH);
		BrowserAction.click(LoginPageObjects.Add_manualevent_XPATH);
		BrowserAction.maximizeCurrentWindow();
		String currentWindow = driver.getWindowHandle();
		Set<String> set = driver.getWindowHandles();
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			String Window2 = itr.next();
			if (!currentWindow.equals(Window2)) {
				driver.switchTo().window(Window2);
				GenericFunctions.staticWait(3);
				//site
				GenericFunctions.selectValueFromDropdownByName("siteID", "East Palembang Indonesia");
				System.out.println("site selected");
				
				//equipment
				GenericFunctions.selectValueFromDropdownByName("equipID", "PG9171E-890034");
				System.out.println("selected equipment");
//				Select s1 = new Select(driver.findElement(By.name("equipID")));
//				WebElement option = s1.getFirstSelectedOption();
//				equipment = option.getText();
//				System.out.println("selected equip " +equipment);
				
				//current date
				LoginObjects.EnterEventDate("11/01/2013");
	
				//event type
				GenericFunctions.selectValueFromDropdownByName("eventType", "HGP");
//				Select s2 = new Select(driver.findElement(By.name("eventType")));
//				WebElement option1 = s2.getFirstSelectedOption();
//				event = option1.getText();
//				System.out.println("selected event " +event);
				
				//REASON
				GenericFunctions.selectValueFromDropdownByName("reasonID", "Planned Outage Change");
//				Select s3 = new Select(driver.findElement(By.name("reasonID")));
//				s2.selectByIndex(2);
//				System.out.println("reason given");
				
				LoginObjects.EnterComments("test");
				LoginObjects.AddButtonEvent();
				System.out.println("add button clicked");
				GenericFunctions.checkAlert();
				driver.switchTo().window(currentWindow);
				System.out.println("event got added");
			}
		}
		       
		        
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void ValidateEvent() {
	GenericFunctions.staticWait(2);
	try {

		WebElement colmCont = driver.findElement(By.xpath(LoginPageObjects.schedule_table_XPATH.toString()));
		WebElement rowCont = driver.findElement(By.xpath(LoginPageObjects.schedule_table_XPATH.toString()));
		int rows = rowCont.findElements(By.xpath(LoginPageObjects.schedule_table_XPATH.toString() + "//tr")).size();
		int colms = colmCont.findElements(By.xpath(LoginPageObjects.schedule_table_XPATH.toString() + "//tr//td"))
				.size();

		System.out.println("row count" + rows);
		System.out.println("colm count" + colms);

		for (int i = 2; i <=rows; i++) {
			WebElement col = driver.findElement(By.xpath(LoginPageObjects.schedule_table_XPATH.toString() + "/tbody/tr["+i+"]/td[2]"));
			String equipVl = col.getText();
			System.out.println("event " +equipVl);
			
			
			if (equipVl.contains("PG9171E-")) {
			WebElement colm = driver.findElement(By.xpath(LoginPageObjects.year_table_XPATH.toString() + "//tr["+i+"]/td[*]/div/a/b/span[contains(@style,'color: #0000FF')]"));
			String res = colm.getText();
			System.out.println("event got " + res);
			
			if (res.equals("HGP")) {
				System.out.println("HGP found which was added manually");
				
			} else {
				System.out.println("HGP not found which was added manually");
			}
			}
		}
	} catch (Exception e) {
		System.out.println("Validate_Table exception occured :: " + e.getMessage());
		GenericFunctions.captureScreenshot();
		Assert.fail("Validate_Table exception occured :: " + e.getMessage());
	}
}

public static void MoveAndDeleteEvent() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.MoveAndDelete_Event_XPATH);
		BrowserAction.click(LoginPageObjects.MoveAndDelete_Event_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void MoveEvent() {
	try {
		GenericFunctions.staticWait(1);
		String currentWindow = driver.getWindowHandle();
		Set<String> set = driver.getWindowHandles();
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			String Window2 = itr.next();
			if (!currentWindow.equals(Window2)) {
				driver.switchTo().window(Window2);
				GenericFunctions.staticWait(2);
				
				WebElement rowCont = driver.findElement(By.xpath(LoginPageObjects.MoveAndDelete_table_XPATH.toString()));
				int rows = rowCont.findElements(By.xpath(LoginPageObjects.MoveAndDelete_table_XPATH.toString())).size();
				System.out.println("row count " + rows);
				
				for (int i = 2; i <=rows; i++) {
					WebElement col3 = driver.findElement(By.xpath("(//*/table/tbody/tr["+i+"]/td[@class='tbl_content'])[3]"));
					String event = col3.getText();
					System.out.println("event " +event);
					
					WebElement col5 = driver.findElement(By.xpath("(//*/table/tbody/tr["+i+"]/td[@class='tbl_content'])[5]"));
					String manual = col5.getText();
					System.out.println("manual " +manual);
					
					if (event.equals("HGP") && manual.equals("Yes")) {
						System.out.println("matched");
						WebElement eventdate = driver.findElement(By.xpath("(//*/table/tbody/tr["+i+"]/td[@class='tbl_content'])[4]/span/input"));
						eventdate.clear();
						eventdate.sendKeys("01/01/2015");
						
						WebElement radio = driver.findElement(By.xpath("(//*/table/tbody/tr["+i+"]/td[@class='tbl_content'])[1]/input"));
						radio.click();		
						LoginObjects.UpdateEvent();
						GenericFunctions.checkAlert();
						GenericFunctions.checkAlert();	
						GenericFunctions.staticWait(5);
						//BrowserAction.closeActiveWindow();
				}
			}
				
				driver.switchTo().window(currentWindow);
				
		}
		}
	}
	catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void ValidateMoveEvent() {
	GenericFunctions.staticWait(2);
	try {

		WebElement colmCont = driver.findElement(By.xpath(LoginPageObjects.schedule_table_XPATH.toString()));
		WebElement rowCont = driver.findElement(By.xpath(LoginPageObjects.schedule_table_XPATH.toString()));
		int rows = rowCont.findElements(By.xpath(LoginPageObjects.schedule_table_XPATH.toString() + "//tr")).size();
		int colms = colmCont.findElements(By.xpath(LoginPageObjects.schedule_table_XPATH.toString() + "//tr//td"))
				.size();

		System.out.println("row count" + rows);
		System.out.println("colm count" + colms);

		for (int i = 2; i <=rows; i++) {
			WebElement col = driver.findElement(By.xpath(LoginPageObjects.schedule_table_XPATH.toString() + "/tbody/tr["+i+"]/td[2]"));
			String equipVl = col.getText();
			System.out.println("event " +equipVl);
			
			if (equipVl.equals("PG9171E-")) {
			WebElement colm = driver.findElement(By.xpath(LoginPageObjects.year_table_XPATH.toString() + "//tr["+i+"]/td[*]/div/a/b/span[contains(@style,'color: #0000FF')]"));
			String res = colm.getText();
			if (res.equals("HGP")) {
				System.out.println("HGP found in which it is moved");
				
			} else {
				System.out.println("HGP not found");
			}
			}
		}
	} catch (Exception e) {
		System.out.println("Validate_Table exception occured :: " + e.getMessage());
		GenericFunctions.captureScreenshot();
		Assert.fail("Validate_Table exception occured :: " + e.getMessage());
	}
}

public static void DeleteEvent() {
	try {
		GenericFunctions.staticWait(1);
		String currentWindow = driver.getWindowHandle();
		Set<String> set = driver.getWindowHandles();
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			String Window2 = itr.next();
			if (!currentWindow.equals(Window2)) {
				driver.switchTo().window(Window2);
				GenericFunctions.staticWait(2);
				
				WebElement rowCont = driver.findElement(By.xpath(LoginPageObjects.MoveAndDelete_table_XPATH.toString()));
				int rows = rowCont.findElements(By.xpath(LoginPageObjects.MoveAndDelete_table_XPATH.toString())).size();
				System.out.println("row count" + rows);
				
				for (int i = 2; i <=rows; i++) {
					WebElement col3 = driver.findElement(By.xpath("(//*/table/tbody/tr["+i+"]/td[@class='tbl_content'])[3]"));
					String event = col3.getText();
					
					WebElement col5 = driver.findElement(By.xpath("(//*/table/tbody/tr["+i+"]/td[@class='tbl_content'])[5]"));
					String manual = col5.getText();
					
					if (event.equals("HGP") && manual.equals("Yes")) {
						
						WebElement eventdate = driver.findElement(By.xpath("(//*/table/tbody/tr["+i+"]/td[@class='tbl_content'])[4]/span/input"));
						eventdate.clear();
						eventdate.sendKeys("01/01/2015");
						
						WebElement radio = driver.findElement(By.xpath("(//*/table/tbody/tr["+i+"]/td[@class='tbl_content'])[1]/input"));
						radio.click();		
						
						LoginObjects.DeleteButton();
						GenericFunctions.checkAlert();
						GenericFunctions.checkAlert();
						GenericFunctions.staticWait(5);
						BrowserAction.closeActiveWindow();
						driver.switchTo().window(currentWindow);
						
				}
			}
		}
		}
	}
	catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void CatalogSelect() {
	try {
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Catalog_select_XPATH);
		BrowserAction.click(LoginPageObjects.Catalog_select_XPATH);
	
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}

}

public static void CatalogDownload() {
	try {
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Catalog_download_XPATH);
		BrowserAction.click(LoginPageObjects.Catalog_download_XPATH);
		Thread.sleep(600000);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Catalog_heading_XPATH);
		BrowserVerify.verifyElementIsDisplayed(LoginPageObjects.Catalog_heading_XPATH);
		System.out.println("catalog downloaded");
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
} 

public static void CatalogCopy() {
	try {
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Catalog_copy_XPATH);
		BrowserAction.click(LoginPageObjects.Catalog_copy_XPATH);
		String currentWindow = driver.getWindowHandle();
		Set<String> set = driver.getWindowHandles();
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			String Window2 = itr.next();
			if (!currentWindow.equals(Window2)) {
				driver.switchTo().window(Window2);
				GenericFunctions.staticWait(5);
				SimpleDateFormat formDate = new SimpleDateFormat("MM-dd-yyyy");
			    String strDate = formDate.format(new Date());
			    
			    SimpleDateFormat formTime = new SimpleDateFormat("HH:mm:ss");
			    String strtime = formTime.format(new Date());
			    
			    String NewCopy = "CS 2017 Apr" + "_" +strDate+"_"+strtime;
			    BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.New_copyText_XPATH);					
				BrowserAction.enterFieldValue(LoginPageObjects.New_copyText_XPATH, NewCopy);
				
				BrowserAction.click(LoginPageObjects.New_copybutton_XPATH);
				
				BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.CopySuccess_XPATH);
				BrowserVerify.verifyElementIsDisplayed(LoginPageObjects.CopySuccess_XPATH);
				System.out.println("copied successfull");
				
				GenericFunctions.checkAlert();
				BrowserAction.closeActiveWindow();						
				driver.switchTo().window(currentWindow);
				BrowserAction.selectDropdownOptionByText(LoginPageObjects.Version_dropdown_XPATH, NewCopy);
				LoginObjects.CatalogSelect();
				GenericFunctions.staticWait(10);
				WebElement created = driver.findElement(
						By.xpath(LoginPageObjects.CreatedBy_XPATH.toString()));
				String Created_by = ""+created.getText();
				System.out.println("created by " +Created_by);
				
			}
		}
		
	
	}catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
} 

public static void CatalogAdmin() {
	try {
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Catalog_admin_XPATH);
		BrowserAction.click(LoginPageObjects.Catalog_admin_XPATH);
	
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}

} 

public static void AddSiteButton() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.SiteAddbutton_XPATH);
		BrowserAction.click(LoginPageObjects.SiteAddbutton_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void Equipmentlink() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Equiplink_XPATH);
		BrowserAction.click(LoginPageObjects.Equiplink_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void NextButton() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.SiteNext_XPATH);
		BrowserAction.click(LoginPageObjects.SiteNext_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static void Dropdowns() {
	try {
		Select s = new Select(driver.findElement(By.xpath(LoginPageObjects.HGPRepresentative_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.HGPPartKit_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1bucketRepresentative_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1bucketPartKit_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1nozzleRepresentative_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1nozzlePartKit_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1shroudRepresentative_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1shroudPartKit_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2bucketRepresentative_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2bucketPartKit_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2nozzleRepresentative_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2nozzlePartKit_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2shroudRepresentative_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2shroudPartKit_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3bucketRepresentative_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3bucketPartKit_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3nozzleRepresentative_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3nozzlePartKit_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3shroudRepresentative_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
		s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3shroudPartKit_XPATH.toString())));
		s.selectByIndex(1);
		GenericFunctions.staticWait(1);
		
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}
}

public static String download_and_ReturnFilePath_MultipleFiles(LoginPageObjects downloadreportXpath,String Filename) {
	try {
		BrowserWait.waitUntilElementIsDisplayed(downloadreportXpath);
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	try {
		BrowserAction.click(downloadreportXpath);
		
		GenericFunctions.staticWait(2);
		
        Robot robo = new Robot();
		
        GenericFunctions.staticWait(2);
        
		//Press TAB and release
		robo.keyPress(KeyEvent.VK_TAB);
		robo.keyRelease(KeyEvent.VK_TAB);
		
		//Press TAB and release
		robo.keyPress(KeyEvent.VK_TAB);	
		robo.keyRelease(KeyEvent.VK_TAB);
		
		//Press TAB and release
		robo.keyPress(KeyEvent.VK_TAB);	
		robo.keyRelease(KeyEvent.VK_TAB);
		
		//Press TAB and release
		robo.keyPress(KeyEvent.VK_TAB);	
		robo.keyRelease(KeyEvent.VK_TAB);
		
		//Press TAB and release
		robo.keyPress(KeyEvent.VK_TAB);	
		robo.keyRelease(KeyEvent.VK_TAB);
		
		//Press TAB and release
		robo.keyPress(KeyEvent.VK_TAB);	
		robo.keyRelease(KeyEvent.VK_TAB);
		
		//Press TAB and release
		robo.keyPress(KeyEvent.VK_TAB);	
		robo.keyRelease(KeyEvent.VK_TAB);
		
		// Pressing Enter and release
		robo.keyPress(KeyEvent.VK_ENTER);
		robo.keyRelease(KeyEvent.VK_ENTER);
		
		 GenericFunctions.staticWait(2);
		
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	System.out.println("Downloading report");
	
	SimpleDateFormat formDate = new SimpleDateFormat("MM-dd-yyyy");
    String strDate = formDate.format(new Date());
    
    GenericFunctions.staticWait(8);
    
    SimpleDateFormat formTime = new SimpleDateFormat("HH-mm-ss");
    String strtime = formTime.format(new Date());
    
    GenericFunctions.staticWait(4);
    
	Path path = FileSystems.getDefault().getPath(System.getProperty("user.home"), "Downloads");
    String DownloadedPATH = path + "\\" +Filename+"_"+strDate+".xlsx" ;
    String NewPathName =  path + "\\" +Filename+"_"+strDate+strtime+".xlsx";
    
    GenericFunctions.staticWait(2);
    
    File file = new File(DownloadedPATH);
    GenericFunctions.staticWait(1);
    File newFile = new File(NewPathName);
    
    GenericFunctions.staticWait(7);
    
    file.renameTo(newFile);
    
    System.out.println("the downloaded excel is renamed from "+DownloadedPATH+" to "+ NewPathName);
	return NewPathName;
	//return new String[]{DownloadedPATH, NewPathName};


} 

public static void services() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Service_XPATH);
		BrowserAction.click(LoginPageObjects.Service_XPATH);
		GenericFunctions.checkAlert();

		WebElement finance = GenericFunctions.driver
				.findElement(By.xpath(LoginPageObjects.Service_bold_XPATH.toString()));
		GenericFunctions.waitUntillElementIsClickable(finance, 60);
		Thread.sleep(60);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Service_bold_XPATH);

		BrowserVerify.verifyElementIsDisplayed(LoginPageObjects.Service_bold_XPATH);
		System.out.println("Service tab clicked");

	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}

}





public static void ServiceItem() {

				try {
					GenericFunctions.staticWait(1);
					 String SiteID1 = driver.findElement(By.xpath("//*[@id=\"dataTable\"]/tbody/tr[2]/td[2]")).getText();
					 System.out.println(SiteID1);
					 String SiteItem1 = driver.findElement(By.xpath("//*[@id=\"dataTable\"]/tbody/tr[2]/td[3]")).getText();
					 System.out.println(SiteItem1);
					driver.findElement(By.xpath("//*[@id=\"hdnRemoveSeqNo0\"]")).click();
					BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Copyservices_XPATH);
					BrowserAction.click(LoginPageObjects.Copyservices_XPATH);
					BrowserAction.maximizeCurrentWindow();
					String currentWindow = driver.getWindowHandle();
					Set<String> set = driver.getWindowHandles();
					Iterator<String> itr = set.iterator();
					while (itr.hasNext()) {
					String Window2 = itr.next();
					if (!currentWindow.equals(Window2)) {
					driver.switchTo().window(Window2);
					GenericFunctions.staticWait(5);
					driver.findElement(By.xpath("//*[@id=\"siteList\"]/option[@value='10001586']")).click();
					BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Copybutton_XPATH);
					BrowserAction.click(LoginPageObjects.Copybutton_XPATH);
					GenericFunctions.checkAlert();
					GenericFunctions.staticWait(5);
					
						}
					}
					driver.switchTo().window(currentWindow);
					GenericFunctions.checkAlert();
					GenericFunctions.staticWait(2);
					Select s = new Select(driver.findElement(By.xpath("//*[@id=\"mainScreen\"]/tbody/tr/td/table/tbody/tr[2]/td/table[2]/tbody/tr/td/table/tbody/tr/td[2]/select")));
					s.selectByIndex(2);
					System.out.println("Bouchemma Region selected");
					GenericFunctions.staticWait(1);
					 String SiteID2 = driver.findElement(By.xpath("//*[@id=\"dataTable\"]/tbody/tr[2]/td[2]")).getText();
					 System.out.println(SiteID2);
					 String SiteItem2 = driver.findElement(By.xpath("//*[@id=\"dataTable\"]/tbody/tr[2]/td[3]")).getText();
					 System.out.println(SiteItem2);
				
					 if(SiteID1.equals(SiteID2) || SiteID2.equals(SiteID1)) {
						   System.out.println("site is copied to Bouchemma region");
						}
					 else
					 {
						 System.out.println("site is not copied to Bouchemma region");
					 }
					 
					 if(SiteItem1.equals(SiteItem2) || SiteItem2.equals(SiteItem1)) {
						   System.out.println("site is copied to Bouchemma region");
						}
					 else
					 {
						 System.out.println("site is not copied to Bouchemma region");
					 }

				} catch (TimeoutException e) {
					Assert.fail("Unable to locate the element.\n" + e.getMessage());
				} catch (Exception e) {
					Assert.fail("pressacceptBtn \n" + e.getMessage());
				}

			}

public static void makeSaveAsCopy() throws Exception {
	
	BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Save_Model_XPATH);
	BrowserAction.click(LoginPageObjects.Save_Model_XPATH);
	
	//*/a[contains(.,'save as new version')]
	BrowserAction.maximizeCurrentWindow();
	String currentWindow = driver.getWindowHandle();
	Set<String> set = driver.getWindowHandles();
	Iterator<String> itr = set.iterator();
	while (itr.hasNext()) {
		String Window2 = itr.next();
		if (!currentWindow.equals(Window2)) {
			driver.switchTo().window(Window2);
			GenericFunctions.staticWait(5);

			// GenericFunctions.selectValueFromDropdownByLabelID("lstSaveAsVersionTypID","RETAIN38");
			Select s = new Select(driver.findElement(By.id("lstSaveAsVersionTypID")));
			s.selectByIndex(2);
			LoginObjects.enterversion_description("test");
			LoginObjects.saveversion();

		}
	}
	driver.switchTo().window(currentWindow);
	GenericFunctions.checkAlert();
	GenericFunctions.staticWait(2);

	System.out.println("Alert Clicked");
	

				
}
	public static ArrayList<String> verifyPricingData() throws Exception {
	
	BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Expand_Pricing_XPATH);
	BrowserAction.click(LoginPageObjects.Expand_Pricing_XPATH);
	GenericFunctions.staticWait(1);
	
	WebElement colmCont = GenericFunctions.driver
			.findElement(By.xpath(LoginPageObjects.Pricing_Table_XPATH.toString()));
	WebElement rowCont = GenericFunctions.driver.findElement(By.xpath(LoginPageObjects.Pricing_Table_XPATH.toString()));
	int rows = rowCont.findElements(By.xpath(LoginPageObjects.Pricing_Table_XPATH.toString() + "//tr")).size();
	

	int i;
	System.out.println("row count" + rows);

	ArrayList<String> data=new ArrayList<String>();
	for (i = 2; i <= rows; i++) {
		
		System.out.println("loop start");
		int colms = colmCont.findElements(By.xpath(LoginPageObjects.Pricing_Table_XPATH.toString() + "//tr["+i+"]//td")).size();
		System.out.println("colm count" + colms);
		for(int j=1;j<=colms;j++) {
			WebElement wb=driver.findElement(By.xpath(LoginPageObjects.Pricing_Table_XPATH.toString() + "//tr["+i+"]//td["+j+"]"));
			String value=""+wb.getText();
			data.add(value);
			System.out.println(value);
		}
	

	}
	
	return data;	
				
}


	public static void clickFinance() {

	try {

		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.finance_Tab_XPATH);
		BrowserAction.click(LoginPageObjects.finance_Tab_XPATH);
		GenericFunctions.staticWait(5);
		System.out.println("finance clicked");
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}

}

	public static void clickPricing() {
	try {

		WebElement pricing = driver.findElement(By.xpath(LoginPageObjects.pricing_Tab_XPATH.toString()));
		GenericFunctions.waitUntillElementIsClickable(pricing, 60);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.pricing_Tab_XPATH);
		BrowserAction.click(LoginPageObjects.pricing_Tab_XPATH);
		System.out.println("pricing clicked");
		GenericFunctions.staticWait(3);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}

}

	public static void versiontypeUSER120() {
	try {
		GenericFunctions.staticWait(1);
		BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_type_USER120_XPATH);
		BrowserAction.click(LoginPageObjects.Version_type_USER120_XPATH);
	} catch (TimeoutException e) {
		Assert.fail("Unable to locate the element.\n" + e.getMessage());
	} catch (Exception e) {
		Assert.fail("pressacceptBtn \n" + e.getMessage());
	}

}
	
	public static void createModel() {
		try {
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Configure_Model_XPATH);

			BrowserAction.hoverOverElement(LoginPageObjects.Configure_Model_XPATH);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Blank_Model_XPATH);

			BrowserAction.click(LoginPageObjects.Blank_Model_XPATH);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Training_Model_XPATH);

			BrowserAction.click(LoginPageObjects.Training_Model_XPATH);
			
			GenericFunctions.staticWait(1);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Training_Next_XPATH);

			BrowserAction.click(LoginPageObjects.Training_Next_XPATH);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Model_Title_XPATH);

			BrowserAction.enterFieldValue(LoginPageObjects.Model_Title_XPATH, "Test New Model");
			
			GenericFunctions.staticWait(1);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Version_Name_XPATH);

			BrowserAction.enterFieldValue(LoginPageObjects.Version_Name_XPATH, "Test New Model");
			
			GenericFunctions.staticWait(1);
			
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Effective_Date_XPATH);

			BrowserAction.enterFieldValue(LoginPageObjects.Effective_Date_XPATH, "11/07/2019");
			
			GenericFunctions.staticWait(1);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Contract_Type_XPATH);

			Select s = new Select(driver.findElement(By.xpath(LoginPageObjects.Contract_Type_XPATH.toString())));

			s.selectByIndex(1);
			
			GenericFunctions.staticWait(2);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Catalog_Version_XPATH);

			s = new Select(driver.findElement(By.xpath(LoginPageObjects.Catalog_Version_XPATH.toString())));

			s.selectByVisibleText(" CS 2019 Jan");
			
			
			GenericFunctions.staticWait(1);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Sunset_Clause_XPATH);

			BrowserAction.enterFieldValue(LoginPageObjects.Sunset_Clause_XPATH, "11/29/2031");

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Model_Region_XPATH);

			s = new Select(driver.findElement(By.xpath(LoginPageObjects.Model_Region_XPATH.toString())));

			s.selectByVisibleText(" Americas");
			
			GenericFunctions.staticWait(3);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Model_SubRegion_XPATH);

			s = new Select(driver.findElement(By.xpath(LoginPageObjects.Model_SubRegion_XPATH.toString())));

			s.selectByVisibleText("Latin America");
			
			GenericFunctions.staticWait(1);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Create_Model_XPATH);

			BrowserAction.click(LoginPageObjects.Create_Model_XPATH);
			
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Model_ID_XPATH);
			
			System.out.println("Created model ID Details : "+BrowserAction.getElementText(LoginPageObjects.Model_ID_XPATH));
			

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public static void SiteDate() {
		try {
			
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.SiteDate_XPATH);
//			SimpleDateFormat formDate = new SimpleDateFormat("MM-dd-yyyy");
//			String strDate = formDate.format(new Date());
			BrowserAction.enterFieldValue(LoginPageObjects.SiteDate_XPATH,"11/07/2019");
			
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}
	}
	
	public static void AddSite() {
		try {
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.AddSite_XPATH);
			BrowserAction.click(LoginPageObjects.AddSite_XPATH);
			
			GenericFunctions.staticWait(2);
			BrowserAction.selectDropdownOptionByText(LoginPageObjects.SiteName_XPATH, "Annaba, Algeria");
			System.out.println("selected site");
			LoginObjects.SiteDate();
			BrowserAction.selectDropdownOptionByText(LoginPageObjects.RepairShop_XPATH, " ES - Houston, USA");
			
			
			
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.SiteAddbutton_XPATH);
			BrowserAction.click(LoginPageObjects.SiteAddbutton_XPATH);
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		} catch (Exception e) {
			Assert.fail("pressacceptBtn \n" + e.getMessage());
		}
	} 
	
	public static void addEquipment() {
		try {
			
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Equiplink_XPATH);
			BrowserAction.click(LoginPageObjects.Equiplink_XPATH);
			
			BrowserAction.selectDropdownOptionByText(LoginPageObjects.Technology_XPATH, "Gas Turbine");
			GenericFunctions.staticWait(2);
			
			BrowserAction.selectDropdownOptionByText(LoginPageObjects.Equip_Model_XPATH, "PG7231FA+");
			GenericFunctions.staticWait(2);
			
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.SiteNext_XPATH);
			BrowserAction.click(LoginPageObjects.SiteNext_XPATH);
			
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Equipment_DateCheckBox_XPATH);

			BrowserAction.click(LoginPageObjects.Equipment_DateCheckBox_XPATH);
			
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Equipment_Date_XPATH);

			BrowserAction.enterFieldValue(LoginPageObjects.Equipment_Date_XPATH,"11/29/2030");

			GenericFunctions.staticWait(2);
			
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Equipment_Performance_XPATH);

			BrowserAction.enterFieldValue(LoginPageObjects.Equipment_Performance_XPATH,"11/07/2019");
			
			GenericFunctions.staticWait(1);

			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Equipment_Next_XPATH);

			BrowserAction.click(LoginPageObjects.Equipment_Next_XPATH);
	

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public static void configurePartKits() {
		try {
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.CAP_ASSY_Drawing_XPATH);
			Select s = new Select(driver.findElement(By.xpath(LoginPageObjects.CAP_ASSY_Drawing_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.CI_CONSUMABLE_Drawing_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.Fuel_Nozzle_Drawing_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.Liner_Drawing_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.TRANSITION_PIECE_Drawing_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.CAP_ASSY_Description_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.CI_CONSUMABLE_Description_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.Liner_Description_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.TRANSITION_PIECE_Description_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.HGPRepresentative_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.HGPPartKit_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1bucketRepresentative_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(2);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1bucketPartKit_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(2);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1nozzleRepresentative_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1nozzlePartKit_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1shroudRepresentative_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG1shroudPartKit_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2bucketRepresentative_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2bucketPartKit_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2nozzleRepresentative_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2nozzlePartKit_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2shroudRepresentative_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG2shroudPartKit_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3bucketRepresentative_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3bucketPartKit_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3nozzleRepresentative_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3nozzlePartKit_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3shroudRepresentative_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.STG3shroudPartKit_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.MI_CONSUMABLE_Drawing_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.MI_PART_Drawing_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.MI_CONSUMABLE_Description_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(1);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.MI_PART_Description_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(2);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.ROTOR_MAINT_Drawing_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(2);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.ROTOR_REFURB_Drawing_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(2);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.ROTOR_MAINT_Description_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(2);
			
			s = new Select(driver.findElement(By.xpath(LoginPageObjects.ROTOR_REFURB_Description_XPATH.toString())));
			s.selectByIndex(1);
			GenericFunctions.staticWait(2);
			
	
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.PartKits_Configure_Next_XPATH);
			BrowserAction.click(LoginPageObjects.PartKits_Configure_Next_XPATH);
	

		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public static void savePartKits() {
		try {
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.PartKits_Install_Next_XPATH);
			BrowserAction.click(LoginPageObjects.PartKits_Install_Next_XPATH);
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Operating_Profile_XPATH);
			BrowserAction.click(LoginPageObjects.Operating_Profile_XPATH);
			GenericFunctions.staticWait(1);
			BrowserWait.waitUntilElementIsDisplayed(LoginPageObjects.Operating_Profile_Save_XPATH);
			BrowserAction.click(LoginPageObjects.Operating_Profile_Save_XPATH);
			GenericFunctions.staticWait(1);
			
		} catch (Exception e) {	
	
		}
	}
	

	
	
	//naina
	public static void enterVersion(String version_type) {
			GenericFunctions.staticWait(1);
			try {

				WebElement ver1 = driver.findElement(By.xpath("//table[@class='expandtable']/tbody/tr[1]/td[7]"));
				String version1 = ver1.getText();
				System.out.println("Version " + version1);
				if (version1.equals(version_type)) {
					driver.findElement(By.xpath("//table[@class='expandtable']/tbody/tr[1]/td[7]/a[contains(text()," + version_type + ")]")).click();
					System.out.println("clicked");
				}
				else {
				WebElement rowCont = driver.findElement(By.xpath("//table[@class='subtable']/tbody/tr"));
				int rows = rowCont.findElements(By.xpath("//table[@class='subtable']/tbody/tr")).size();
				System.out.println("row count" + rows);
				for (int i = 1; i <= rows; i++) {
					WebElement ver = driver.findElement(By.xpath("//table[@class='subtable']/tbody/tr[" + i + "]/td[7]"));
					String version = ver.getText();
					System.out.println("Version " + version);
					if (version.equals(version_type)) {
						System.out.println("version found");
						driver.findElement(By.xpath("//table[@class='subtable']/tbody/tr[" + i + "]/td[7]/a[contains(text()," + version_type + ")]")).click();
						System.out.println("clicked");
						break;
					} else {
						System.out.println("version not found");
					}
				}
			}
				
		} catch (TimeoutException e) {
			Assert.fail("Unable to locate the element.\n" + e.getMessage());
		
		}
}
	public static void Version(String version_type) throws Exception {
		GenericFunctions.staticWait(3);
		LoginObjects.enterVersion(version_type);
	}
}
