package com.ge.icam.common.map;

public enum LoginPageObjects {

	// GE SSO Login Page
	ICAM_SSO_username_NAME("username"), ICAM_SSO_password_NAME("password"), ICAM_SSO_submit_button_NAME("submitFrm"),

	// GE ICAM Login Page

	ICAM_accept_button_NAME("btnCreate"), ICAM_Selectbusiness_PGS_XPATH(
			"//*[@id=\"selBus\"]/option[2]"), ICAM_Selectrole_XPATH(
					"//*[@id=\"selRole\"]/option[10]"), ICAM_Select__button_XPATH("//*[@id=\"submitBtn\"]"),

	// ICAM homepage
	ICAM_Modelid_XPATH("//*[@name='txtModelID']"), ICAM_SEARCH_XPATH("//*[@name=\"Submit\"]"), SEARCH_IMAGE_XPATH(
			"//*[@id=\"menu3sign1\"]"), Version_type_PGS_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER101\")]"),

	// save as new version
	// NEW_VERSION_XPATH("//*[@name=\"btnSaveAsVersion\"]"),
	NEW_VERSION_XPATH(
			"//div[@id = \"modelDetails\" ]/table[*]/tbody/tr/td[*]/input[@name =\"btnSaveAsVersion\"]"), select_list_XPATH(
					"//*[@id=\"lstSaveAsVersionTypID\"]/option[428]"), version_XPATH(
							"//*[@id=\"versionDescription\"]"), save_version_XPATH("//*[@name=\"Submit\"]"),

	// Schedule
	schedule_XPATH("//*[@alt='Calculate Schedule']"),
	// finance
	Finance_XPATH("//*[@title=\"Calculate Financials\"]"), 
	pricing_XPATH("/html/body/center/table/tbody/tr/td/table[*]/tbody/tr/td[*]/form/table/tbody/tr/td/table/tbody/tr[*]/td/table/tbody/tr/td[1]"),
	// CR REPORT
	CR_REPORT_XPATH("//*[@id=\"mainContent\"]/table[*]/tbody/tr[*]/td[*]/table/tbody/tr/td[*]/font/a"),

	// Rahul

	red_schedule_XPATH("//*[@id=\"statusBarEventSch\"]/a/font[@color='red']"),

	red_finance_XPATH("//*[@id=\"statusBarFinance\"]/a/font[@color='red']"),

	RRR_IMAGE_XPATH("//*[@id=\"jdd39\"]"),

	RRR_XPATH("//*[@id=\"sdd63\"]"),

	PartKits_XPATH("//*[@id=\"chkBxAvailableSelectAll\"]"),

	KitsAssign_XPATH("//*[@id=\"criteriaForm\"]/table[4]/tbody/tr/td/table[3]/tbody/tr/td[2]/table/tbody/tr[1]/td/img"),

	showReport_XPATH("//*[@id=\"tt\"]"),
	
	schedule_bold_XPATH("//*[@id=\"statusBarEventSch\"]/a/strong/font"), 
	
	finance_bold_XPATH("//*[@id=\"statusBarFinance\"]/a/strong/font"),
	billing_period_XPATH("(//*/table[@class ='int_tbl_bg2']//ancestor::table)[6]/tbody/tr[2]/td[1]//table/tbody"), 
	

	downloadReport_XPATH(
			"/html/body/form/center/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table[2]/tbody/tr/td/table/tbody/tr/td[3]/input"),
	
	//Haripriya
	Manage_Fleet_XPATH("//*[@class='tabs_header'][3]"),
	Save_as_fleet_XPATH("//*[@name='saveAsNewFleetButton']"),
	Fleet_dropdwn_XPATH("//*[@id='newFleetVersion']/option[8]"),
	Fleet_Version_type_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"FLEET268\")]"),
	Save_as_new_fleet_XPATH("//*[@name='SubmitSave']"),
	Inventory_XPATH("//*[@class='icn-content'][5]"),
	
	//Billing
		Billing_XPATH("(//*[@class='icn-content'])[8]"),
		ActiveVersion_XPATH("//*/table[@class='tbl_bg2']/tbody/tr[1]/td[4]"),
		Yes_XPATH("//*/table[@class='tbl_bg2']/tbody/tr[2]/td[4]"),
		RadioButton_Xpath("//*/table[@class='tbl_bg2']/tbody/tr[2]/td[1]/input[@value='3']"),
		OpenButton_XPATH("/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/form/table/tbody/tr[2]/td/table[2]/tbody/tr/td[1]/input"),
		Export_XPATH("//*[@name='exportExcel']"),
	
		
		
		Version_type_Aero_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"OTR FC\")]"),
		Version_type_Alstom_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER109\")]"),
		Version_type_ONG_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER100\")]"),
		Version_type_Jenbacher_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER04\")]"), 
		
		
		ICAM_Selectbusiness_Aero_XPATH("//*[@id=\"selBus\"]/option[6]"),
		ICAM_Selectbusiness_Alstom_XPATH("//*[@id=\"selBus\"]/option[5]"),
		ICAM_Selectbusiness_ONG_XPATH("//*[@id=\"selBus\"]/option[4]"),
		ICAM_Selectbusiness_Jenbacher_XPATH("//*[@id=\"selBus\"]/option[7]"),
		
		
		//Naina
		schedule_table_XPATH("(//*/table/tbody/tr[@class='tbl_bg2_content'])[3]/ancestor::table[@id='siteEquip']"),
		
		Download_XPATH("//*[@id=\"icon\"]/iron-icon//svg"), 
	    year_table_XPATH("(//*/table[@class='tbl_bg2'])[7]/tbody"), 
		
	    billing_table_XPATH("(//*/table[@class ='int_tbl_bg2']//ancestor::table)[6]/tbody/tr[2]/td[2]//table/tbody"),
	    
	    import_actuals_XPATH("//*[@name=\"importStg\"]"),
		billing_save_XPATH("//*[@name=\"saveBtn\"]"),
		ok_XPATH("(//*[@class=\"table_bk\"])[4]/tbody/tr/td[1]/input"),
		events_from_XPATH("(//*[@class=\"table_bk\"])[3]/tbody/tr/td[2]/span/input[@name=\"txtStDt\"]"),
		events_to_XPATH("(//*[@class=\"table_bk\"])[3]/tbody/tr/td[2]/span/input[@name=\"txtEndDt\"]"),
	    
	    //Sanjay
	    Projected_event_XPATH("//span[contains(@style,'color: #0000FF')]"),
	    
	    schedule_Tab_XPATH("//*[@id=\"statusBarEventSch\"]/a"),
	    
	    /*
	     * 
	     * 
	     * 
	     * 
	     * Billing Module XPATH
	     * 
	     * 
	     * 
	     * 
	     * */
	    
	    
	    //TC10_TestCopyBilling
	    Version_type_Billing_RETAIN27_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"RETAIN27\")]"),
	    
	    Version_type_Billing_OTR_FC_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"OTR FC\")]"),
	    
	    Version_type_Billing_USER4026_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER4026\")]"),
	    
	    Version_type_Billing_USER112_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER112\")]"),
	    
	    Version_type_Billing_USER4033_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER4033\")]"),
	    
	    Version_type_Billing_RETAIN3_XPATH("(//*[@class=\"tbl_content\"]/a[contains(text(), \"RETAIN3\")])[2]"),
	    
	    Version_type_Billing_USER06_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER06\")]"),
	    
	    Version_type_Billing_USER512_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER512\")]"),
	    
	    Version_type_Billing_USER106_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER106\")]"),
		Version_type_Billing_USER101_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER101\")]"),
		Version_type_Billing_RETAIN14_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"RETAIN14\")]"),
		
		Version_type_Billing_RETAIN16_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"RETAIN16\")]"),
		Version_type_Billing_USER215_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER215\")]"),
		
		Version_type_Billing_RETAIN29_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"RETAIN29\")]"),
		Version_type_Billing_RETAIN26_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"RETAIN26\")]"),
		Version_type_Billing_USER131_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER131\")]"), 
		Version_type_Billing_USER03_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER03\")]"), 
		Version_type_Billing_USER108_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER108\")]"), 
		
		Version_type_Billing_RETAIN25_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"RETAIN25\")]"),
		Version_type_Billing_RETAIN2_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"RETAIN2\")]"),
		Version_type_Billing_USER4036_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER4036\")]"),
		Version_type_Billing_USER05_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER05\")]"),
		Version_type_Billing_RETAIN30_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"RETAIN30\")]"),
		Version_type_Billing_USER173_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER173\")]"),
		Version_type_Billing_USER227_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER227\")]"),
		Version_type_Billing_USER09_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER09\")]"),
		Version_type_Billing_USER103_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER103\")]"),
		Version_type_Billing_USER109_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER109\")]"),
		Version_type_Billing_USER02_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER02\")]"),
		Version_type_Billing_USER110_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER110\")]"),
		
		Version_type_Billing_Alstom_USER60_XPATH("//*[@class=\"tbl_content_trngModel\"]/a[contains(text(),'USER 60')]"),
		Version_type_Billing_Alstom_USER02_XPATH("//*[@class=\"tbl_content_trngModel\"]/a[contains(text(),'USER02')]"),
		Version_type_Billing_Alstom_USER101_XPATH("//*[@class=\"tbl_content_trngModel\"]/a[contains(text(),'USER101')]"),
		Version_type_Billing_Alstom_USER05_XPATH("//*[@class=\"tbl_content_trngModel\"]/a[contains(text(),'USER05')]"),
		
		Version_type_Billing_USER11_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER11\")]"),
		Version_type_Billing_USER57_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER57\")]"),
		
		Version_type_Billing_USER04_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER04\")]"),
		Version_type_Billing_USER100_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER100\")]"),
		Version_type_Billing_USER59_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER 59\")]"),
		Version_type_Billing_USER60_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER 60\")]"),
		
		Version_type_Billing_USER119_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER119\")]"),
		Version_type_Billing_USER322_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER322\")]"),
		Version_type_Billing_USER178_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER178\")]"),
	    Billing_Copy_XPATH("/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/form/table/tbody/tr[2]/td/table[2]/tbody/tr/td[7]/input"),
	    
	    Billing_Change_VersionName_XPATH("/html/body/center/table[1]/tbody/tr/td/table/tbody/tr/td[2]/form/table/tbody/tr[3]/td/div/table/tbody/tr[1]/td/table[1]/tbody/tr/td[2]/input"),
	    
	    Billing_Next_XPATH("/html/body/center/table[1]/tbody/tr/td/table/tbody/tr/td[2]/form/table/tbody/tr[3]/td/table[2]/tbody/tr/td[4]/input"),
	    
	    Billing_Fixed_Next_XPATH("//*[@id=\"frmFixedPay\"]/table[2]/tbody/tr/td[4]/input"),
	    
	    Billing_Variable_Next_XPATH("/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/form/table/tbody/tr[2]/td/table/tbody/tr/td/table/tbody/tr/td[6]/input"),
	    
	    Billing_Variable_Next2_XPATH("/html/body/center/table[1]/tbody/tr/td/table/tbody/tr/td[2]/form/table/tbody/tr[3]/td/table/tbody/tr/td[6]/input"),
	    
	    Billing_Milestone_Next_XPATH("/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/div/form/table/tbody/tr[2]/td/table/tbody/tr/td[4]/input"),
	    
	    Billing_Bonus_Next_XPATH("/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/form/table/tbody/tr[5]/td/table/tbody/tr/td[7]/input"),
	    
	    Billing_Copy_Save_XPATH("/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/form/table/tbody/tr[2]/td/table[2]/tbody/tr/td/table/tbody/tr[3]/td/table/tbody/tr[1]/td[2]/input"),
	    
	    
	    //Shree
	    
	    Table_Xpath("/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/form/table/tbody/tr[2]/td/table[1]"),
	    Same_Version_XPATH("//*[@id=\"Search\"]/tbody/tr/td[4]/font/b['version']"),
	    Billing_StreamFX_XPATH("//*[@class='tabs_header'][4]"),
	    
	    //Haripriya
	    Save_button_XPATH("/html/body/center/table/tbody/tr/td/table[1]/tbody/tr/td[2]/form/table/tbody/tr[2]/td/table[2]/tbody/tr/td/table/tbody/tr[3]/td/table/tbody/tr[1]/td[2]/input"),
	
	    
	    //Sanjay
	     
	  	
	  	
	  	
	  	
	  	
	  	Billing_Stream_Name_Radio_NAME("version"),
	  	Billing_Stream_NewVersion_Button_NAME("Submit5"),
	  	Billing_Stream_Open_Button_NAME("Submit223"),
	  	Billing_VersionName_XPATH("//input[@labelname='Version Name']"),
	  	Billing_Version_Desc_NAME("txtArVersionDesc"),
	  	Billing_Frequency_DD_NAME("drpDnBillingFreq"),
	  	Billing_BonusLD_Yes_XPATH("//input[@name='bonusLD' and @value='Y']"),
	  	Billing_Constraint_YES_XPATH("//input[@name='varConstInp' and @value='Y']"),
	  	Billing_Extrawork_Yes_XPATH("//input[@name='EWBillingConstInp' and @value='Y']"),
	  	Billing_FMV_Carveout_Yes_XPATH("//input[@name='FMVCarveoutInp' and @value='Y']"),
	  	Billing_Escxaltion_NO_XPATH("//input[@name='escalation' and @value='N']"),
	  	Billing_ContractLevel_XPATH("//input[@name='rdBtnBillingStrmOpt' and @value='ContractLvl']"),
	  	Billing_ForiegnExchange_Yes_XPATH("//input[@name='fx' and @value='Y']"),
	  	Billing_Currency_DD_NAME("drpDnFxCurrency"),
	  	Billing_FX_RATE_NAME("fixRate"),
	  	Billing_Next_NAME("Submit222"),
	      Billing_Fixed_EntireContract_XPATH("//input[@name='fixedMode' and @value='FixedEntContr']"),
	      Billing_FixedAmoutInput_NAME("fixedValue"),
	  	Billing_AutomaticSelection_OperatingMode_XPATH("//input[@name='varMode'and @value='Automatic']"),
	  	Billing_FFH_XPATH("//input[@name='opFact'and @value='FFH']"),
	  	Billing_OneRate_XPATH("//input[@name='fmode'and @value='OneRate']"),
	  	Billing_FFH_Rate_XPATH("//input[@name='varValue'and @value='hours']"),
	  	Billing_Event_Millestone_Radio_NAME("chkbxEventBased"),
	  	Billing_Event_Millestone_AddRow_NAME("AddEvent"),
	  	Billing_Event_Millestone_Equipment_DD_NAME("drpDnEventEquip_0"),
	  	Billing_Event_Millestone_Type_DD_NAME("drpDnEventType_0"),
	  	Billing_Event_Millestone_Occurance_DD_NAME("drpDnEventOccurance_0"),
	  	Billing_Event_Millestone_Months_DD_NAME("drpDnEventXMonths_0"),
	  	Billing_Event_Millestone_Amount_NAME("txtEventAmount_0"),
	  	Billing_BonusLD_Bonus_Period_Field_XPATH("//td[@id='avaiBonusID0']/input[@name='avaiBonus']"),
	  	Billing_BonusLD_LD_Period_Field_XPATH("//td[@id='avaiLDID0']/input[@name='avaiLD']"),
	      Billing_FMVCarveout_Carveout1_Period_Field_XPATH("//div[@id='DataTab']//table//tr[1]//td[@id='carveoutOne0']/input"),
	      Billing_table_XPATH("(//*/table[@class ='int_tbl_bg2']//ancestor::table)[6]/tbody/tr[2]/td[2]//table/tbody"),
	  	Billing_DownloadExcel_NAME("downloadRules"),
	  	Billing_UploadExcel_NAME("importExcel"),
	  	Billing_ChooseFile_NAME("billingExl"),
	  	Billing_SubmitFile_NAME("Submit"),
	  
	  	Billing_Save_NAME("saveBtn"),
	  	Billing_Calculate_Finance_XPATH("//a/*[@title='Calculate Financials']"),
	  	Billing_ExportExcel_NAME("exportExcel"),
	  	
	  	Billing_BillingStreamfx_XPATH("//td//*[contains(text(),'Billing Stream-Fx')]"),
	  	
	  	
	  	//Reconfigure
	  	Reconfigure_ReconfigureButton_XPATH("//input[@value='Re-configure']"),
	    Reconfigure_DateDependNo_XPATH("//input[@id='range_N']"),
	    Reconfigure_DateDependNext_XPATH("//input[@value='  Next >> ']"),
	    Reconfigure_RenconfigSelection_DD_XPATH("//select[@name='cmbSiteEquipLst']"),
	    Reconfigure_ChooseRenconfig_Radio_XPATH("//input[@name='choiceReconfigId']"),
	    Reconfigure_AddButton_XPATH("//input[@name='Submit' and @value='  Add  ']"),
	    Reconfigure_PartKitDD_ID("prtKitID_14_9"),
	    Reconfigure_Schedule_XPATH("//*[@id='statusBarEventSch']//font[contains(text(),'Schedule')]"),
	    Reconfigure_FirstEquipmet_XPATH("//input[@id='equipid1']/.."),
	    Reconfigure_DeterminPartKit_XPATH("//input[@value=' Determine Part/Kit ']"),
	    Reconfigure_AddReplaceButton_XPATH("//input[@name='Submit5']"),
	    ReconfigurePartKit_CAP_XPATH("//table[@id='LowerDataTable']//tr[1]//td[3][contains(text(),'CAP')]"),
	    AddCPL_TablefirstPartKit_XPATH("//div[@id='DataTab']//table[@class='int_tbl_main']//tr[1]//td[3]//font"),
	    AddCPL_AddCustomDetails_XPATH("//form[@id='frmCustomPartKit']//table[@class='tbl_bg2']//input[@value='Add Custom Details']"),
	    AddCPL_SelectRadio_NAME("selDetail"),
	    AddCPL_StartDate_XPATH("//input[@name='startDt0']"),
	    AddCPL_EndDate_XPATH("//input[@name='endDt0']"),
	    AddCPL_Save_XPATH("//input[@name='Submit6']"),
	    AddCPL_Reason_NAME("reasonCode0"),
	    AddCPL_Save_ICAMEventDetail_XPATH("//input[@name='Save']"),
	    AddCPL_CustomSectionLimit_Section_XPATH("//td[contains(text(),'Custom Section Limits')]"),
	    AddCPL_CustomPartKit_Section_XPATH("//td[contains(text(),'Custom Part Kit')]"),
	    RRR_RegressionImage_XPATH("//*[@id=\"jd39\"]"),
	    RRR_Regression_XPATH("//*[@id=\"sd63\"]"),
	
	
	//naina
	Priordropdown_XPATH("(//*[@name=\"priorMdlVer\"])[1]"),
	Excel_all_XPATH("//*[@name=\"exportExcel \"][contains(@value,' Export Excel for All ')]"), 
    //Version_type_Billing_USER173_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER173\")]"),
	Version_type_Billing_USER174_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER174\")]"),
	Version_type_Billing_USER166_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER166\")]"),
	Version_type_Billing_USER175_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER175\")]"),	
	Version_type_Billing_USER152_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER152\")]"),
	ExportButton_XPATH("//*[@name=\"btexport\"]"), 
	Fleet_RRR_type_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"FLEET 360\")]"),
	Fleet_image_XPATH("//*[@id=\"jdd24\"]"),
	Fleet_Report_XPATH("//*[@id=\"sdd31\"]"),
	Finance_Tab_XPATH("//*[@id=\"statusBarFinance\"]"),
	Export_Finance_XPATH("//*[@name=\"Submit354\"][contains(@value,'Export Financials')]"),
	Save_change_XPATH("//*[@name=\"Submit32222\"][contains(@value,'Save ')]"),
	Financials_screen_XPATH("(//*/table/tbody/tr/td[@class='tabs_header'])/a[contains(text(),'Financials')]"),
	Generator_ID("Generator"),
	Select_partkit_NAME("partKitId"),
	Version_type_AR72_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"AR Consistency Check 72\")]"), 
	RRR_revenue_XPATH("//a[text()=\" Revenue Recognition Report\"]"),
	Add_manualevent_XPATH("//*[@id=\"displayBtns\"]/tbody/tr/td[4]/input"),
	Add_eventdate_XPATH("//*[@id=\"evntDt\"]/td[2]/span/input"),
	Add_comment_XPATH("//*[@id=\"tr_comments\"]/td[2]/textarea"),
	Add_button_XPATH("//*[@id=\"addBtn\"]"),
	//LinkText_XPATH("//span[contains(@style,'color: #0000FF')]/../.."),
	MoveAndDelete_Event_XPATH("//*[@id=\"displayBtns\"]/tbody/tr/td[3]/input"),
	MoveAndDelete_table_XPATH("/html/body/form/table/tbody/tr/td/table/tbody/tr[3]/td/div/table/tbody/tr"),
	UpdateEvent_Button_XPATH("//*[@class='button_bg'][contains(@value,'  Update Selected Event Dates  ')]"),
	DeleteEvent_Button_XPATH("//*[@class='button_bg'][contains(@value,'  Delete Selected Events  ')]"),
	
	Catalog_admin_XPATH("//*[@id=\"p7\"]/a/p[contains(text(),'Catalog Administration')]"),
	Category_dropdown_XPATH("//table[@id='cateGorytb']/tbody/tr/td/select[@id='cateGory']"),
	Version_dropdown_XPATH("//table[@id='versiontb']/tbody/tr/td/select[@id='version']"),
	Catalog_select_XPATH("//*[@class='button_bg'][contains(@value,'Select')]"),
	Catalog_download_XPATH("//*[@id='bt_download'][contains(@value,'Download')]"),
	Catalog_copy_XPATH("//*[@id=\"bt_copy\"][contains(@value,'Copy')]"),
	Catalog_heading_XPATH("//table/tbody/tr/td[@class=\"tbl_bg2_content_hdr\"][contains(text(),'Catalog Administration')]"),
	New_copyText_XPATH("//*[@id=\"newCatalogName\"]"),
	New_copybutton_XPATH("//*[@name=\"b_copy\"][contains(@value,'Copy')]"),
	CopySuccess_XPATH("//*[@id='d_err_msg']/font[contains(text(),'Copy Successful!')]"),
	CreatedBy_XPATH("//table/tbody/tr/td[@id=\"str_created_by\"]"),
	Version_type_Billing_USER366_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER366\")]"),
	Version_type_Billing_USER364_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER364\")]"),
	Version_type_Billing_USER339_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER339\")]"),
	Version_type_Billing_USER222_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER222\")]"),
	Version_type_Billing_USER223_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER223\")]"), 
	Version_type_Billing_USER105_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER105\")]"),
	
		Service_XPATH("//*[@id=\"mainContent\"]/table[3]/tbody/tr[1]/td[9]/table/tbody/tr/td[11]/a[contains(., \"Services\")]"),
	 	Service_bold_XPATH("/html/body/table[3]/tbody/tr[1]/td[9]/table/tbody/tr/td[11]/a[contains(., \"Services\")]/strong"),
	 	Copyservices_XPATH("//*[@id=\"mainScreen\"]/tbody/tr/td/table/tbody/tr[2]/td/center/table/tbody/tr[2]/td[2]/input[@value='Copy Services']"),
	 	Copybutton_XPATH("//*[@id=\"copyButton\"]"),
	 	
	 	 //Regression TC_23
		  Version_type_USER120_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER120\")]"),
		  finance_Tab_XPATH("//*[@id=\"statusBarFinance\"]/a"),
		  
		  pricing_Tab_XPATH("//*[@id=\"frmActFinance\"]//a[contains(.,'Pricing')]"),
		  
		  Expand_Pricing_XPATH("//*/input[@name='expandAll']"),
		  Download_Pricing_XPATH("//*/input[@value='Download Pricing']"),
		  
		  Save_Model_XPATH("//*/a[contains(.,'save as new version')]"),
		    
		 Pricing_Table_XPATH("//*[@id=\"rule\"]/table"),
		 
		 
		 //Regression TC_24
		 Configure_Model_XPATH("//*[@id=\"p1\"]/p"),
		 Blank_Model_XPATH("//*[@id=\"1\"]/a"),
		 Training_Model_XPATH("//*/input[@value='radTrgModel']"),
		 Training_Next_XPATH("//*/input[@title=' Model Details ']"),
		 Model_Title_XPATH("//*/input[@name='modelTitle']"),
		 Version_Name_XPATH("//*/input[@name='versionDescription']"),
		 Effective_Date_XPATH("//*/input[@name='contractEffectiveDate']"),
		 Contract_Type_XPATH("//*/select[@name='contractType']"),
		 Catalog_Version_XPATH("//*/select[@name='catalogVersion']"),
		Sunset_Clause_XPATH("//*/input[@name='sunsetClause']"),
		 Model_Region_XPATH("//*/select[@name='region']"),
		Model_SubRegion_XPATH("//*/select[@name='subregion']"),
		Create_Model_XPATH("//*/input[@name='Submit3']"),
		
		Model_ID_XPATH("//*[@id=\"Search\"]/tbody/tr/td[3]/font/b"),
		
		Equipment_Performance_XPATH("//*/input[@name='perfStartDate']"),
		
		Equipment_DateCheckBox_XPATH("//*/input[@name='dateInd']"),
		
		Equipment_Date_XPATH("//*/input[@name='eotDate']"),
		
		Equipment_Next_XPATH("//*/input[@name='Modify_btnNext']"),
		
		CAP_ASSY_Drawing_XPATH("//*[@id=\"repDrgNum_14_9\"]"),
		CI_CONSUMABLE_Drawing_XPATH("//*[@id=\"repDrgNum_14_11\"]"),
		Fuel_Nozzle_Drawing_XPATH("//*[@id=\"repDrgNum_14_563\"]"),
		Liner_Drawing_XPATH("//*[@id=\"repDrgNum_14_562\"]"),
		TRANSITION_PIECE_Drawing_XPATH("//*[@id=\"repDrgNum_14_74\"]"),
		
		CAP_ASSY_Description_XPATH("//*[@id=\"prtKitDesc_14_9\"]"),
		CI_CONSUMABLE_Description_XPATH("//*[@id=\"prtKitDesc_14_11\"]"),
		Fuel_Nozzle_Description_XPATH("//*[@id=\"prtKitDesc_14_563\"]"),
		Liner_Description_XPATH("//*[@id=\"prtKitDesc_14_562\"]"),
		TRANSITION_PIECE_Description_XPATH("//*[@id=\"prtKitDesc_14_74\"]"),
		
		MI_CONSUMABLE_Drawing_XPATH("//*[@id=\"repDrgNum_52_16\"]"),
		MI_PART_Drawing_XPATH("//*[@id=\"repDrgNum_52_18\"]"),
		
		MI_CONSUMABLE_Description_XPATH("//*[@id=\"prtKitDesc_52_16\"]"),
		MI_PART_Description_XPATH("//*[@id=\"prtKitDesc_52_18\"]"),
		
		ROTOR_MAINT_Drawing_XPATH("//*[@id=\"repDrgNum_15_20\"]"),
		ROTOR_REFURB_Drawing_XPATH("//*[@id=\"repDrgNum_15_21\"]"),
		
		ROTOR_MAINT_Description_XPATH("//*[@id=\"prtKitDesc_15_20\"]"),
		ROTOR_REFURB_Description_XPATH("//*[@id=\"prtKitDesc_15_21\"]"),
		
		PartKits_Configure_Next_XPATH("//*[@id=\"frmCreateEquipmentParts\"]/table[2]/tbody/tr/td[6]/input"),
		
		PartKits_Install_Next_XPATH("//*[@id=\"HTopDiv1\"]/table/tbody/tr/td/table[2]/tbody/tr[1]/td[5]/div/input"),
		
		Operating_Profile_XPATH("//*[@id=\"HTab\"]/table/tbody/tr[1]/td[5]/input"),
		
		Operating_Profile_Save_XPATH("//*/input[@name='Save']"),
		
		
		
		SiteName_XPATH("//*[@id=\"rule\"]/table/tbody/tr[2]/td/table/tbody/tr[1]/td[2]/select"),
		
		AddSite_XPATH("//table/tbody/tr/td/a/span[contains(text(),'Add Site')]"),
		SiteDate_XPATH("//table/tbody/tr/td/span/input[contains(@name,'dtSiteAdded')]"),
		RepairShop_XPATH("//*/select[@name='repairShop']"),
		
		SiteAddbutton_XPATH("//table/tbody/tr/td/div/input[@class='button_bg'][contains(@value,'Add')]"),
		Equiplink_XPATH("//table/tbody/tr/td/a[@class=\"msg_txt\"][contains(text(),'Click here to Add an Equipment')]"),
		Technology_XPATH("//table/tbody/tr/td/select[@name=\"GO\"]"),
		
		Equip_Model_XPATH("//table/tbody/tr/td/select[@name=\"equipModel\"]"),
		
		SiteNext_XPATH("//table/tbody/tr/td/input[@name=\"Submit32\"][contains(@value,' Next >>')]"),
		
		HGPRepresentative_XPATH("//*/select[@name=\"repDrgNum_13_14\"]"),
		HGPPartKit_XPATH("//*/select[@name=\"prtKitDesc_13_14\"]"),
		STG1bucketRepresentative_XPATH("//*/select[@name=\"repDrgNum_13_22\"]"),
		STG1bucketPartKit_XPATH("//*/select[@name=\"prtKitDesc_13_22\"]"),
		STG1nozzleRepresentative_XPATH("//*/select[@name=\"repDrgNum_13_23\"]"),
		STG1nozzlePartKit_XPATH("//*/select[@name=\"prtKitDesc_13_23\"]"),
		STG1shroudRepresentative_XPATH("//*/select[@name=\"repDrgNum_13_24\"]"),
		STG1shroudPartKit_XPATH("//*/select[@name=\"prtKitDesc_13_24\"]"),
		STG2bucketRepresentative_XPATH("//*/select[@name=\"repDrgNum_13_25\"]"),
		STG2bucketPartKit_XPATH("//*/select[@name=\"prtKitDesc_13_25\"]"),
		STG2nozzleRepresentative_XPATH("//*/select[@name=\"repDrgNum_13_26\"]"),
		STG2nozzlePartKit_XPATH("//*/select[@name=\"prtKitDesc_13_26\"]"),
		STG2shroudRepresentative_XPATH("//*/select[@name=\"repDrgNum_13_27\"]"),
		STG2shroudPartKit_XPATH("//*/select[@name=\"prtKitDesc_13_27\"]"),
		STG3bucketRepresentative_XPATH("//*/select[@name=\"repDrgNum_13_28\"]"),
		STG3bucketPartKit_XPATH("//*/select[@name=\"prtKitDesc_13_28\"]"),
		STG3nozzleRepresentative_XPATH("//*/select[@name=\"repDrgNum_13_29\"]"),
		STG3nozzlePartKit_XPATH("//*/select[@name=\"prtKitDesc_13_29\"]"),
		STG3shroudRepresentative_XPATH("//*/select[@name=\"repDrgNum_13_30\"]"),
		STG3shroudPartKit_XPATH("//*/select[@name=\"prtKitDesc_13_30\"]"),
	
	Version_Table_XPATH("//table[@class='subtable']/tbody/tr");
	
	LoginPageObjects(String enumValue) {
		this.enumValue = enumValue;
	}

	private String enumValue;

	public String getEnumValue() {
		return toString();
	}

	public String toString() {
		return this.enumValue;
	}
}
