package com.ge.icam.common.map;

public enum loginpage_objects {

	// GE SSO Login Page
	ICAM_SSO_username_NAME("username"), ICAM_SSO_password_NAME("password"), ICAM_SSO_submit_button_NAME("submitFrm"),

	// GE ICAM Login Page

	ICAM_accept_button_NAME("btnCreate"), ICAM_Selectbusiness_XPATH(
			"//*[@id=\"selBus\"]/option[2]"), ICAM_Selectrole_XPATH(
					"//*[@id=\"selRole\"]/option[10]"), ICAM_Select__button_XPATH("//*[@id=\"submitBtn\"]"),

	// ICAM homepage
	ICAM_Modelid_XPATH("//*[@name='txtModelID']"), ICAM_SEARCH_XPATH("//*[@name=\"Submit\"]"), SEARCH_IMAGE_XPATH(
			"//*[@id=\"menu3sign1\"]"), Version_type_XPATH("//*[@class=\"tbl_content\"]/a[contains(., \"USER101\")]"),

	// save as new version
	// NEW_VERSION_XPATH("//*[@name=\"btnSaveAsVersion\"]"),
	NEW_VERSION_XPATH(
			"//div[@id = \"modelDetails\" ]/table[*]/tbody/tr/td[*]/input[@name =\"btnSaveAsVersion\"]"), select_list_XPATH(
					"//*[@id=\"lstSaveAsVersionTypID\"]/option[428]"), version_XPATH(
							"//*[@id=\"versionDescription\"]"), save_version_XPATH("//*[@name=\"Submit\"]"),

	// Schedule
	schedule_XPATH("//*[@title=\"Calculate Schedule\"]"),
	// finance
	Finance_XPATH("//*[@title=\"Calculate Financials\"]"), pricing_XPATH(
			"/html/body/center/table/tbody/tr/td/table[*]/tbody/tr/td[*]/form/table/tbody/tr/td/table/tbody/tr[*]/td/table/tbody/tr/td[1]"),
	// CR REPORT
	CR_REPORT_XPATH("//*[@id=\"mainContent\"]/table[*]/tbody/tr[*]/td[*]/table/tbody/tr/td[*]/font/a"),

	// Rahul

	red_schedule_XPATH("//*[@id=\"statusBarEventSch\"]/a/font"),

	red_finance_XPATH("//*[@id=\"statusBarFinance\"]/a/font"),

	//RRR_IMAGE_XPATH("//*[@id=\"ddd0\"]/div[11]/a[1]/img[@id=\"jdd39\"]"),
	RRR_IMAGE_XPATH("//*[@id=\"jdd39\"]"),

	RRR_XPATH("//*[@id=\"sdd63\"]"),

	PartKits_XPATH("//*[@id=\"chkBxAvailableSelectAll\"]"),

	KitsAssign_XPATH("//*[@id=\"criteriaForm\"]/table[4]/tbody/tr/td/table[3]/tbody/tr/td[2]/table/tbody/tr[1]/td/img"),

	showReport_XPATH("//*[@id=\"tt\"]"),
	
	schedule_bold_XPATH("//*[@id=\"statusBarEventSch\"]/a/strong/font"), 
	
	

	downloadReport_XPATH(
			"/html/body/form/center/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td/table/tbody/tr/td[2]/table/tbody/tr[2]/td/table[2]/tbody/tr/td/table/tbody/tr/td[3]/input");

	loginpage_objects(String enumValue) {
		this.enumValue = enumValue;
	}

	private String enumValue;

	public String getEnumValue() {
		return toString();
	}

	public String toString() {
		return this.enumValue;
	}
}
