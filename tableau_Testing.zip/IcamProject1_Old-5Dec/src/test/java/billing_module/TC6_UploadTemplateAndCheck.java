package billing_module;

import org.testng.annotations.Test;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC6_UploadTemplateAndCheck {
	@Test(priority = 1,enabled=true)
	@Documentation(step = "verify the billing stream is opening", expected = "billing stream opened successfully")
	@FailureMessage("failed to open billing")
	public void open_billing() throws Throwable {
		
		String Filename1="BillingImportTemplate.xlsx";
		String Filename2="BillingStreamReport.xlsx";
		
		String FixedBilling_Value= "1199.10";
		String VariableBilling_Value = "1399.00";
		String Adjustment_Value= "1299.20";
		String MilestoneBilling_Value = "1399.00";
		String Comments= "ABCD";
		
	    LoginObjects.Billing();
	    GenericFunctions.checkAlert();
		GenericFunctions.staticWait(2);
		LoginObjects.openActiveVersion();
		String DownloadedPath = LoginObjects.Billing_verify_DownloadTemplate(Filename1);
		LoginObjects.File_Verify_DownloadExcel(Filename1);
		int RowCount = LoginObjects.Excel_Download_Modify_Data(DownloadedPath,FixedBilling_Value,VariableBilling_Value,Adjustment_Value,MilestoneBilling_Value,Comments);
		LoginObjects.Billing_verify_Upload(DownloadedPath,FixedBilling_Value,VariableBilling_Value,Adjustment_Value,MilestoneBilling_Value,Comments);
		String ExportedPATH = LoginObjects.Billing_verify_ExportTemplate(Filename2);
		LoginObjects.File_Verify_DownloadExcel(Filename2);
		LoginObjects.Excel_Export_Verify_Data(ExportedPATH,FixedBilling_Value,VariableBilling_Value,Adjustment_Value,MilestoneBilling_Value,Comments,RowCount);
		LoginObjects.Excel_Delete(DownloadedPath);
		LoginObjects.Excel_Delete(ExportedPATH);
	}

	
}
