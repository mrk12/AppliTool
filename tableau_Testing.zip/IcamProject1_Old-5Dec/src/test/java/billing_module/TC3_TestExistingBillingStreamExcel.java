package billing_module;

import org.openqa.selenium.By;
import org.testng.annotations.Test;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC3_TestExistingBillingStreamExcel extends BaseTest {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Verify the values for Existing Billing version in Billing Stream Export to Excel.", expected = "Successully verified")
	@FailureMessage("failed")

	public void Billing() throws Throwable {

		LoginObjects.Billing();
		GenericFunctions.checkAlert();
		GenericFunctions.staticWait(60);
		LoginObjects.ActiveVersion();
		System.out.println("baseline downloaded");
		LoginObjects.schedule();
		LoginObjects.ChildBrowserWindow_Close();
		LoginObjects.finance();
		String v= driver.findElement(By.xpath(LoginPageObjects.Same_Version_XPATH.toString())).getText();
		System.out.println("version name in used  " +v);
		LoginObjects.Billing();
		LoginObjects.exportVersion();
		System.out.println("new excel downloaded");
	}
	

}
