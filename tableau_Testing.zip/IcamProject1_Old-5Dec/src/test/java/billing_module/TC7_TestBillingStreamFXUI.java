package billing_module;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC7_TestBillingStreamFXUI{
	@Test(priority = 1,enabled=true)
	@Documentation(step = "Verify user successfully logged in into system", expected = "Successully logged IN")
	@FailureMessage("User didn't login into application")
	public void Billing() throws Throwable {
					GenericFunctions.checkAlertDismiss();
					LoginObjects.Billing();
					GenericFunctions.checkAlert();
					GenericFunctions.staticWait(60);
					LoginObjects.openActiveVersion();
					LoginObjects.billingStreamFX();
					LoginObjects.exportVersion();
					LoginObjects.schedule();
					LoginObjects.ChildBrowserWindow_Close();
					LoginObjects.finance();
					String v=GenericFunctions.driver.findElement(By.xpath(LoginPageObjects.Same_Version_XPATH.toString())).getText();
					System.out.println(v);
					LoginObjects.Billing();
					LoginObjects.openActiveVersion();
					LoginObjects.billingStreamFX();
 
	}
	


}
