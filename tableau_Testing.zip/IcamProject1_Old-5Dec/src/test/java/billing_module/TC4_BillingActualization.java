package billing_module;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC4_BillingActualization {
	@Test(priority = 1,enabled=true)
	@Documentation(step = "BillingActualization calculated", expected = "Successully calculated BillingActualization")
	@FailureMessage("BillingActualization is not calculated")
	public void BillingActualization() throws Throwable {
		
		GenericFunctions.checkAlert();
		if (LoginObjects.checkRedSchedule()) {
			LoginObjects.schedule();
			LoginObjects.ChildBrowserWindow_Close();
			GenericFunctions.staticWait(3);
			GenericFunctions.checkAlert();
		}
		if (LoginObjects.checkRedFinance()) {
			LoginObjects.finance();
			GenericFunctions.checkAlert();
			GenericFunctions.staticWait(3);
		}
		LoginObjects.Billing();
		LoginObjects.openActiveVersion();
		GenericFunctions.driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
	    GenericFunctions.checkAlert();
	    LoginObjects.validateBilling();
		LoginObjects.saveActualization();
		GenericFunctions.checkAlert(); 
		GenericFunctions.checkAlert();
		if (LoginObjects.checkRedFinance()) {
			LoginObjects.finance();
			LoginObjects.Billing();
			LoginObjects.openActiveVersion();
			GenericFunctions.staticWait(3);
		} 

		LoginObjects.exportActualizationTable();
		
	}
	


}