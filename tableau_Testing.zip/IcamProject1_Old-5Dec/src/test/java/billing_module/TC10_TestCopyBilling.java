package billing_module;

import org.testng.annotations.Test;

import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.digital.itops.testng.PDFReporter;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC10_TestCopyBilling {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Verify if User is able to make a copy of existing Billing version", expected = "User is able to copy billing version")
	@FailureMessage("User is not able to copy billing version")

	public void testCopyBilling() throws Throwable {
		
		LoginObjects.Billing();
		
		GenericFunctions.checkAlert();
		GenericFunctions.staticWait(1);
		
		//Download baseline report
		LoginObjects.ActiveVersion();
		System.out.println("download baseline");
		
		
		//Open Billing again
		LoginObjects.Billing();
		System.out.println("opening billing");
		
		LoginObjects.selectActiveVersion();
		
		//Copy billing
		LoginObjects.copyBilling();


		GenericFunctions.staticWait(3);
		PDFReporter.takeExtraScreenshot();
		System.out.println("Taking Screenshot");

	}
}
