package billing_module;



import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;

import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC2_TestExistingBillingStreamUI{
	@Test(priority = 1,enabled=true)
	@Documentation(step = "Verify the values for Existing Billing version on Billing Stream UI.", expected = "Successully verified")
	@FailureMessage("Not verified")
	public void Billing() throws Throwable {		
					LoginObjects.Billing();
					GenericFunctions.checkAlert();
					GenericFunctions.staticWait(60);
					LoginObjects.ActiveVersion();			
					LoginObjects.schedule();
					LoginObjects.ChildBrowserWindow_Close();
					GenericFunctions.staticWait(5);
					LoginObjects.finance();
					GenericFunctions.staticWait(5);
					String v=GenericFunctions.driver.findElement(By.xpath(LoginPageObjects.Same_Version_XPATH.toString())).getText();
					System.out.println(v);
					LoginObjects.Billing();
					LoginObjects.openActiveVersion();
 
	}
	


}
						 
						 

