package billing_module;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.Set;
import java.util.Calendar;
import java.util.Date;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;
import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC5_ImportActuals {
	
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Verify the values for Existing Billing version in Billing Stream Export to Excel.", expected = "Successully verified")
	@FailureMessage("failed")
	public void Billing() throws Throwable {

	   // Common.validate_user_logged_into_Applicaction();
	                    LoginObjects.Billing();
					GenericFunctions.checkAlert();
						GenericFunctions.staticWait(10);
						LoginObjects.ActiveVersion();
						LoginObjects.Import_actuals();
						String currentWindow = GenericFunctions.driver.getWindowHandle(); 
						Set<String> set =GenericFunctions.driver.getWindowHandles();
						Iterator<String> itr= set.iterator();
						 while(itr.hasNext()){
						 String Window2=itr.next();
						 if(!currentWindow.equals(Window2)){
							 GenericFunctions.driver.switchTo().window(Window2); 
						 }}
						 WebElement events_from = GenericFunctions.driver.findElement(By.xpath(LoginPageObjects.events_from_XPATH.toString()));
			   	         String from_date = events_from.getAttribute("value");
						 System.out.println("Date before Addition: "+from_date);
							SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy");
							Calendar c = Calendar.getInstance();
							try{
							   c.setTime(sdf.parse(from_date));
							}catch(ParseException e){
							   e.printStackTrace();
							 }
							//Incrementing the date by 1 day
							c.add(Calendar.DAY_OF_MONTH, 30);  
							String newDate = sdf.format(c.getTime());  
							System.out.println("Date Incremented by One: "+newDate);
							 BrowserAction.clear(LoginPageObjects.events_to_XPATH);
							 BrowserAction.enterFieldValue(LoginPageObjects.events_to_XPATH,newDate);
							 LoginObjects.ok_button();
							 
							 GenericFunctions.checkAlert();
							 GenericFunctions.driver.switchTo().window(currentWindow);
							 
							 @SuppressWarnings("deprecation")
							Date date = new Date(newDate);  
							 SimpleDateFormat formatter = new SimpleDateFormat("dd MMMM yyyy");  
								String strDate = formatter.format(date);  
							    System.out.println("Date Format with dd MMMM yyyy : "+strDate);
							    String[] Str_Array = strDate.split(" ");
								String Date = Str_Array[0];
								String Month = Str_Array[1];
								String Year = Str_Array[2];
								System.out.println("fyfgy");
								//td[contains(text(),"2018")and contains(text(),"May")] 
								LoginObjects.validatebilling_5(Month,Year);
						
                                  LoginObjects.Billing_save();
					
						 }
	

	
	
}
