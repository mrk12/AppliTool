package billing_module;

import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC9_TestBillingStreamSemiAnnually {
	@Test(priority = 1,enabled=true)
	@Documentation(step = "verify the billing stream is opening", expected = "billing stream opened successfully")
	@FailureMessage("failed to open billing")
	public void open_billing() throws Throwable {
		
		String Filename1="BillingImportTemplateFx.xlsx";
		String Filename2="BillingStreamFxReport.xlsx";
		
		String FixedBilling_Value= "6666.06";
		String Argument_Value= "7777.07";
		String MilestoneBilling_Value = "8888.08";
		String Comments= "XYZ";
		double Cell_Value=38.35;
		
	    LoginObjects.Billing();
	    GenericFunctions.checkAlert();
		GenericFunctions.staticWait(2);
		LoginObjects.openActiveVersion();
		GenericFunctions.staticWait(1);
		GenericFunctions.checkAlert();
		BrowserAction.click(LoginPageObjects.Billing_BillingStreamfx_XPATH);
		String DownloadedPath = LoginObjects.Billing_verify_DownloadTemplate(Filename1);	
		LoginObjects.File_Verify_DownloadExcel(Filename1);
		int RowCount = LoginObjects.Excel_FX_Download_Modify_Data(DownloadedPath,FixedBilling_Value,Argument_Value,MilestoneBilling_Value,Comments);
		LoginObjects.Billing_verify_Fx_Upload(DownloadedPath,FixedBilling_Value,Argument_Value,MilestoneBilling_Value,Comments);
		String ExportedPATH = LoginObjects.Billing_verify_ExportTemplate(Filename2);
		LoginObjects.File_Verify_DownloadExcel(Filename2);
		LoginObjects.Excel_Export_FX_Verify_Data(ExportedPATH,RowCount,FixedBilling_Value,Argument_Value,MilestoneBilling_Value,Comments);
		LoginObjects.Excel_Delete(DownloadedPath);
		LoginObjects.Excel_Delete(ExportedPATH);
	}
}
