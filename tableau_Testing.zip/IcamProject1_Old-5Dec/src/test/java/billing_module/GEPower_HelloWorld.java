package billing_module;

import com.applitools.eyes.BatchInfo;
import com.applitools.eyes.ProxySettings;
import com.applitools.eyes.RectangleSize;
import com.applitools.eyes.StdoutLogHandler;
import com.applitools.eyes.TestResults;
import com.applitools.eyes.selenium.Eyes;
import com.applitools.eyes.selenium.StitchMode;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class GEPower_HelloWorld {

    public void verifyHelloWorld(int i) {
        //DriverUtils.getPathForChromeDriverFromMachine();
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\503114663\\Documents\\AutomationUseCase\\src\\test\\resources\\Config\\chromedriver.exe"); 
    	WebDriver driver = new ChromeDriver();
    	/*ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--headless", "--disable-gpu", "--ignore-certificate-errors", "--window-size=400,400");
        WebDriver driver = new ChromeDriver(chromeOptions);*/

    	
    	//Create object of Dimensions class
        //Dimension d = new Dimension(1200,800);
    	//RectangleSize  obj = new RectangleSize(1200,800);
        //Resize the current window to the given dimension
        //driver.manage().window().setSize(d);
        // Initialize the eyes SDK and set your private 378355API key.
        Eyes eyes = new Eyes();
       // RectangleSize viewportSize = new RectangleSize(/*width*/ 1200, /*height*/ 800 );
        //driver = eyes.open(driver,
          //  "Hello World App", "Hello World Test", viewportSize);
        //eyes.open(driver.manage().window().setSize(1200,800));
        //eyes.open(driver.manage().window().setSize(d));
        //eyes.open(driver, "AppName", "TestName", new RectangleSize(1200, 800));
        BatchInfo batch = new BatchInfo("HelloWorld");
        eyes.setBatch(batch);
        eyes.setLogHandler(new StdoutLogHandler(true));
        eyes.setForceFullPageScreenshot(false);
        eyes.setStitchMode(StitchMode.CSS);
        System.out.println("Testing");
        // Set the API key from the env variable. Please read the "Important Note"
        //eyes.setApiKey("U7fj1017103zVsL5Druekb9Dmo1TekZJFgy6BlP61PGZOhA110");
        //eyes.setApiKey("T98Bwp8nW6KPGrQTpdVY9102QAWqdIWbgEy991LO6fBCG54110"); 
        //New API Key
        eyes.setApiKey("T98Bwp8nW6KPGrQTpdVY9102QAWqdIWbgEy991LO6fBCG54110");        
        //eyes.setProxy(new ProxySettings("http://10.114.19.200:80"));
      //eyes.setProxy(new ProxySettings("http://3.209.30.23/nonssopac.pac"));
        //eyes.setProxy(new ProxySettings("http://sjc1intproxy02.crd.ge.com:8080"));
         //eyes.setProxy(new ProxySettings("http://corp.setpac.ge.com/pac.pac"));
          //eyes.setProxy(new ProxySettings("http://PITC-Zscaler-Americas-Cincinnati3PR.proxy.corporate.ge.com:80")); 
        eyes.setProxy(new ProxySettings("http://PITC-Zscaler-Americas-Cincinnati3PR.proxy.corporate.ge.com:80")); 
        try {
        	
            // Start the test by setting AUT's name, window or the page name that's being tested, viewport width and height
            eyes.open(driver, "HelloWorld", "HelloWorld", new RectangleSize(800,500));
        	//eyes.open(driver, "HelloWorld", "HelloWorld");

            driver.get("https://applitools.com/helloworld");
            eyes.checkWindow("home");

            /*for (int stepNumber = 0; stepNumber < i; stepNumber++) {
                driver.findElement(By.linkText("?diff1")).click();
                eyes.checkWindow("click-" + stepNumber);
                Thread.sleep(1000);
            }
            // Click the "Click me!" button.
            driver.findElement(By.tagName("button")).click();
            eyes.checkWindow("After click");*/
            // End the test.
            TestResults testResults = eyes.close(false);
            System.out.println("Visual Test results: " + testResults);

        } catch (Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
        } finally {
            // Close the browser.
        	TestResults testResults = eyes.abortIfNotClosed();
        	System.out.println("Testing");
            System.out.println("Visual Test results: " + testResults);
        	//eyes.abortIfNotClosed();
            driver.close();
            

            // If the test was aborted before eyes.close was called, ends the test as aborted.
            //TestResults testResults = eyes.abortIfNotClosed();
            //System.out.println("Visual Test results (finally): " + testResults);
        }
    }
    
    public void firstTablueTest() {
        //DriverUtils.getPathForChromeDriverFromMachine();
    	System.setProperty("webdriver.chrome.driver","C:\\Users\\503114663\\Documents\\AutomationUseCase\\src\\test\\resources\\Config\\chromedriver.exe"); 
    	WebDriver driver = new ChromeDriver();
    	/*ChromeOptions chromeOptions = new ChromeOptions();
        chromeOptions.addArguments("--headless", "--disable-gpu", "--ignore-certificate-errors", "--window-size=400,400");
        WebDriver driver = new ChromeDriver(chromeOptions);*/

    	
    	Eyes eyes = new Eyes();
        //eyes.open(driver, "AppName", "TestName", new RectangleSize(1200, 800));
        BatchInfo batch = new BatchInfo("HelloWorld");
        eyes.setBatch(batch);
        eyes.setLogHandler(new StdoutLogHandler(true));
        eyes.setForceFullPageScreenshot(false);
        eyes.setStitchMode(StitchMode.CSS);
        System.out.println("Testing");
        //New API Key
        eyes.setApiKey("T98Bwp8nW6KPGrQTpdVY9102QAWqdIWbgEy991LO6fBCG54110");        
        eyes.setProxy(new ProxySettings("http://PITC-Zscaler-Americas-Cincinnati3PR.proxy.corporate.ge.com:80")); 
        try {
        	
            // Start the test by setting AUT's name, window or the page name that's being tested, viewport width and height
            eyes.open(driver, "Tableau", "Tableau", new RectangleSize(800,500));
        	//eyes.open(driver, "HelloWorld", "HelloWorld");

            
            driver.get("https://tableau.cloud.digital.ge.com/#/views/ProjectPermissionAssignmentsbyIDMGroup/ProjectPermissionAssignmentGroups?:iid=1");

            LoginToGE(driver, "503088227", "Igate@123ge");
            Thread.sleep(10000);
            eyes.checkWindow("home");

     
            // End the test.
            TestResults testResults = eyes.close(false);
            System.out.println("Visual Test results: " + testResults);

        } catch (Exception e) {
            System.out.println(e.toString());
            e.printStackTrace();
        } finally {
            // Close the browser.
        	TestResults testResults = eyes.abortIfNotClosed();
        	System.out.println("Testing");
            System.out.println("Visual Test results: " + testResults);
        	//eyes.abortIfNotClosed();
            driver.close();
            

            // If the test was aborted before eyes.close was called, ends the test as aborted.
            //TestResults testResults = eyes.abortIfNotClosed();
            //System.out.println("Visual Test results (finally): " + testResults);
        }
    }
    
    public static void LoginToGE(WebDriver driver, String UserName, String Password) throws InterruptedException {
    	Thread.sleep(5000);
    	driver.findElement(By.id("username")).sendKeys(UserName);
    	driver.findElement(By.id("password")).sendKeys(Password);
    	//Thread.sleep(5000);
    	driver.findElement(By.id("submitFrm")).click();

    	Thread.sleep(5000);
    	
    }

    public static void main(String[] args) {
       // new GEPower_HelloWorld().verifyHelloWorld(2); // hellow world example 
        new GEPower_HelloWorld().firstTablueTest();
        
     
    }
}
