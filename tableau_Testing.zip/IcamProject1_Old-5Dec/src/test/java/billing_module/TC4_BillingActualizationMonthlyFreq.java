package billing_module;

import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.openqa.selenium.Keys;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC4_BillingActualizationMonthlyFreq {

	@Test(priority = 1,enabled=true)
	@Documentation(step = "BillingActualization calculated", expected = "Successully calculated BillingActualization")
	@FailureMessage("BillingActualization is not calculated")
	public void BillingActualizationmonthly() throws Throwable {
	
	LoginObjects.Billing();
	LoginObjects.openActiveVersion();
	GenericFunctions.driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
    GenericFunctions.checkAlert();
	LoginObjects.monthlyvalidatebilling();
	LoginObjects.saveActualization();
	GenericFunctions.checkAlert();
	GenericFunctions.checkAlert();
	LoginObjects.exportVersion();
	
}
	

	
}