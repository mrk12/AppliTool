package Regression_testing;

import java.util.ArrayList;
import org.junit.Assert;
import org.testng.annotations.Test;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.digital.itops.testng.PDFReporter;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC_23_PricingScreenTest {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Verify the data on Pricing Screen", expected = "Data on Pricing Screen displayed correctly")
	@FailureMessage("Failed to verify data on pricing screen")
	public void check_pricing_data() throws Throwable {
			String Filename1 = "Pricing Details";
			String Filename2 = "Pricing Details";
			
			//String Filename2 = "Pricing Details (1)";
			LoginPageObjects DownloadPricingXpath = LoginPageObjects.Download_Pricing_XPATH;

			// Go to Finance Page
			LoginObjects.clickFinance();

			// Go to pricing tab
			LoginObjects.clickPricing();

			// Verify Pricing		
			ArrayList<String> pricingBeforeSchFinCal=LoginObjects.verifyPricingData();

			// Download Report before schedule and finance calculation
			String FileDownload_Path_01 = LoginObjects.download_and_ReturnFilePath(DownloadPricingXpath, Filename1);

			// Make Save As copy
			LoginObjects.makeSaveAsCopy();

			// Calculate Schedule
			LoginObjects.schedule();
			GenericFunctions.staticWait(3);

			// Calculate Finance
			LoginObjects.finance();
			GenericFunctions.staticWait(3);

			// Go to Finance and click on Pricing tab
			LoginObjects.clickFinance();
			LoginObjects.clickPricing();

			// Verify Pricing
			ArrayList<String> pricingAfterSchFinCal=LoginObjects.verifyPricingData();
			
			//Compare the Pricing details before and after schedule and finance calculation
			Assert.assertEquals(pricingBeforeSchFinCal,pricingAfterSchFinCal);

			// Download Report after schedule and finance calculation
			String FileDownload_Path_02 = LoginObjects.download_and_ReturnFilePath_MultipleFiles(DownloadPricingXpath, Filename2);

			// Compare Excel
			LoginObjects.ExcelCompare(FileDownload_Path_01, FileDownload_Path_02);

			System.out.println("Test case passed");
			
			PDFReporter.takeExtraScreenshot();
			System.out.println("Taking Screenshot");
	}
}
