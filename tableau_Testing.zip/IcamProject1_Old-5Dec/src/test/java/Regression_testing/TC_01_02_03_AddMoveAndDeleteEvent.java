package Regression_testing;


import org.testng.annotations.Test;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC_01_02_03_AddMoveAndDeleteEvent{
	@Test(priority = 1, enabled = true)
	@Documentation(step = "AddManualEvent", expected = "Manual event is successfully added")
	@FailureMessage("failed to add manual event")
	public void AddEvent() throws Throwable {
		LoginObjects.Schedule_page();
		LoginObjects.manual_event();
		LoginObjects.ValidateEvent();	
		LoginObjects.schedule();
		GenericFunctions.staticWait(20);
		System.out.println("added");
		LoginObjects.MoveAndDeleteEvent();
		//GenericFunctions.staticWait(10);
		LoginObjects.MoveEvent();
		System.out.println("moved");
		LoginObjects.ValidateMoveEvent();
		LoginObjects.schedule();
		GenericFunctions.staticWait(20);
		LoginObjects.ValidateEvent();
		LoginObjects.MoveAndDeleteEvent();
		LoginObjects.DeleteEvent();
		LoginObjects.ValidateEvent();
	}
}
