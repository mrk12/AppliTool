package Regression_testing;

import org.testng.annotations.Test;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.LoginObjects;

public class TC_11_Copycatalog {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "category admin catalog copied", expected = "copied successfully")
	@FailureMessage("failed coping")
	public void copycatalog() throws Throwable {
		LoginObjects.CatalogCopy();
	}
}