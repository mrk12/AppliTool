package Regression_testing.Aero;

import org.testng.annotations.Test;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.IcamExcelUtils;
import com.ge.icam.common.page.LoginObjects;

public class Common_10_11 extends BaseTest {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Verify user successfully logged in into system", expected = "Successully logged IN")
	@FailureMessage("User didn't login into application")
	public static void validate_user_logged_into_Applicaction() throws Throwable {
		String user = IcamExcelUtils.storeUserCredential("user1", "user");
		String password = IcamExcelUtils.storeUserCredential("user1", "pswd");
		System.out.println(user);
		System.out.println("*********");
		
		LoginObjects.loginIntoApplication_via_SSO(user, password);
		
		LoginObjects.selectAeroBusinessList();	
		LoginObjects.selectrolelist();
		LoginObjects.selectButton();
		
		GenericFunctions.checkAlert();
		System.out.println("popup got handled");
		LoginObjects.CatalogAdmin();
		GenericFunctions.selectValueFromDropdownByLabelID("busGrpID", " Aero Energy");
		GenericFunctions.selectValueFromDropdownByLabelID("busTier2ID", "CS");
		GenericFunctions.staticWait(2);
		GenericFunctions.selectValueFromDropdownByLabelID("catalogID", "AE 2018 Jan - copy vk");
		LoginObjects.CatalogSelect();
	}
}
