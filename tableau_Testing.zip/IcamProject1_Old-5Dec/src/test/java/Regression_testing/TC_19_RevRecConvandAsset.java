package Regression_testing;

import java.util.Set;

import org.testng.annotations.Test;

import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC_19_RevRecConvandAsset {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Check variance in CR report for a exsiting model having Convenience tab configured", expected = "for a exsiting model having Convenience tab configured")
	@FailureMessage("For a exsiting model having Convenience tab not configured")
	public void TC_19_RevRecBoth() throws Throwable {
		
		String Filename1="RepairReplace";
		String Filename2="RepairReplace";
		LoginPageObjects  DownloadReportXpath= LoginPageObjects.ExportButton_XPATH;
		GenericFunctions.staticWait(3);
		
		LoginObjects.RevPdfdownload_19();
		LoginObjects.RevExceldownload();
		
		String FileDownload_Path_01 = LoginObjects.download_and_ReturnFilePath(DownloadReportXpath,Filename1);
		
		String currentWindow = GenericFunctions.driver.getWindowHandle();
		Set<String> set = GenericFunctions.driver.getWindowHandles();
		GenericFunctions.driver.switchTo().window(currentWindow);
		
		LoginObjects.finance();
		LoginObjects.RRR_revenue_ImageButton();
		LoginObjects.RevPdfdownload_19();
		LoginObjects.RevExceldownload();
		
		String FileDownload_Path_02 = LoginObjects.download_and_ReturnFilePath_MultipleFiles(DownloadReportXpath,Filename2);
		GenericFunctions.staticWait(2);
		LoginObjects.ExcelCompare(FileDownload_Path_01,FileDownload_Path_02);
	}
}
