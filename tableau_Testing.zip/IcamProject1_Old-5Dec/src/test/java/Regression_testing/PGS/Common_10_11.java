package Regression_testing.PGS;

import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.IcamExcelUtils;
import com.ge.icam.common.page.LoginObjects;

public class Common_10_11 extends BaseTest {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Verify user successfully logged in into system", expected = "Successully logged IN")
	@FailureMessage("User didn't login into application")
	public static void validate_user_logged_into_Applicaction() throws Throwable {
		String user = IcamExcelUtils.storeUserCredential("user1", "user");
		String password = IcamExcelUtils.storeUserCredential("user1", "pswd");
		System.out.println(user);
		System.out.println("*********");
		
		LoginObjects.loginIntoApplication_via_SSO(user, password);
		
		LoginObjects.selectPGSBusinessList();	
		LoginObjects.selectrolelist();
		LoginObjects.selectButton();
		
		GenericFunctions.checkAlert();
		System.out.println("popup got handled");
		LoginObjects.CatalogAdmin();
		GenericFunctions.selectValueFromDropdownByLabelID("busGrpID", " Energy Services");
		GenericFunctions.selectValueFromDropdownByLabelID("busTier2ID", "CS");
		GenericFunctions.staticWait(2);
		BrowserAction.selectDropdownOptionByText(LoginPageObjects.Category_dropdown_XPATH, "Catalog");
		System.out.println("catalog");
		BrowserAction.selectDropdownOptionByText(LoginPageObjects.Version_dropdown_XPATH, "CS 2017 Apr");
		System.out.println("version");
		LoginObjects.CatalogSelect();
	}
}
