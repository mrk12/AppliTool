package Regression_testing.PGS;

import org.testng.annotations.Test;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.IcamExcelUtils;
import com.ge.icam.common.page.LoginObjects;

public class Common_23 extends BaseTest {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Verify user successfully logged in into system", expected = "Successully logged IN")
	@FailureMessage("User didn't login into application")
	public static void validate_user_logged_into_Applicaction() throws Throwable {
		String user = IcamExcelUtils.storeUserCredential("user1", "user");
		String password = IcamExcelUtils.storeUserCredential("user1", "pswd");
		System.out.println(user);
		System.out.println("*********");
		
		LoginObjects.loginIntoApplication_via_SSO(user, password);
		
		LoginObjects.selectPGSBusinessList();
		LoginObjects.selectrolelist();
		LoginObjects.selectButton();
		

		GenericFunctions.checkAlert();
		System.out.println("popup got handled");
		String modelid_value = IcamExcelUtils.storeTestData_FromGenericTestData_sheet_BasedOn_key("Regression_TC_23_PGS");
		System.out.println(modelid_value);
		LoginObjects.modelid(modelid_value);
		
		LoginObjects.versiontypeUSER120();
				
		GenericFunctions.checkAlert();	
		
	}
}