package Regression_testing;

import org.testng.annotations.Test;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;



public class TC_05_AddCSLandVerify {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "AddCPLandVerify", expected = "AddCPLandVerify")
	@FailureMessage("failed to open billing")
	public void AddCPLandVerify() throws Throwable {
		
		String Custom_Section = "Custom Section Limits";
		GenericFunctions.staticWait(2);
		String EventName= LoginObjects.Store_Schedule_event_name();
		LoginObjects.AddCPL(EventName,Custom_Section);
		
	}
}