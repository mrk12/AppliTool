package Regression_testing;

import java.util.List;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.TimeUnit;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;



public class TC_13_EventBasedReconfiguration {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "verify the billing stream is opening", expected = "billing stream opened successfully")
	@FailureMessage("failed to open billing")
	public void open_billing() throws Throwable {
		
		GenericFunctions.staticWait(2);
		String EventDate = LoginObjects.Store_Schedule_event_date();
		String EquipmentName= LoginObjects.get_equipment_name();
		LoginObjects.Reconfigure(EquipmentName);
		
	}
}
