package Regression_testing;


import org.testng.annotations.Test;

import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;

import com.ge.icam.common.page.LoginObjects;

public class TC_25_CopyServiceTest {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "Copy Service test", expected = "Copied Service test successfully")
	@FailureMessage("failed Copy Service test")
	public void Servicetest() throws Throwable {
		LoginObjects.services();
		LoginObjects.ServiceItem();	
		
	}

}