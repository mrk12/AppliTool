package Report_module;

import java.util.Set;

import org.testng.annotations.Test;

import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.icam.common.map.LoginPageObjects;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.LoginObjects;

public class TC_19_RevRecReport {
	@Test(priority = 1, enabled = true)
	@Documentation(step = "REV REC REPORT", expected = "PASSED")
	@FailureMessage("FAILED")
	public void RevRecReport() throws Throwable {
		
		String Filename1="RevRecData_report";
		String Filename2="RevRecData_report";
		
		LoginPageObjects  DownloadReportXpath= LoginPageObjects.ExportButton_XPATH;
		GenericFunctions.staticWait(3);
		LoginObjects.RevExceldownload();
		
		String FileDownload_Path_01 = LoginObjects.download_and_ReturnFilePath(DownloadReportXpath,Filename1);
		
		String currentWindow = GenericFunctions.driver.getWindowHandle();
		Set<String> set = GenericFunctions.driver.getWindowHandles();
		GenericFunctions.driver.switchTo().window(currentWindow);
		
		LoginObjects.finance();
		LoginObjects.RRR_revenue_ImageButton();
		LoginObjects.RevExceldownload();
		String FileDownload_Path_02 = LoginObjects.download_and_ReturnFilePath_MultipleFiles(DownloadReportXpath,Filename2);
		GenericFunctions.staticWait(2);
		LoginObjects.ExcelCompare(FileDownload_Path_01,FileDownload_Path_02);
	
	}
}
