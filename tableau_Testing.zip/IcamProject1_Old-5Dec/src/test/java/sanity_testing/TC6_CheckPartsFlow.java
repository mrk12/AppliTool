package sanity_testing;

import java.util.Iterator;
import java.util.Set;

import org.testng.annotations.Test;

import com.ge.digital.itops.browser.BrowserAction;
import com.ge.digital.itops.testng.Documentation;
import com.ge.digital.itops.testng.FailureMessage;
import com.ge.digital.itops.testng.PDFReporter;
import com.ge.icam.common.page.BaseTest;
import com.ge.icam.common.page.GenericFunctions;
import com.ge.icam.common.page.IcamExcelUtils;
import com.ge.icam.common.page.LoginObjects;


public class TC6_CheckPartsFlow{
	@Test(priority = 1,enabled=true)
	@Documentation(step = "verify the Projected events flow", expected = "Projected events flow is successfully tested")
	@FailureMessage("Schedule is not completed")
			public void calculate_schedule() throws Throwable {
		
		
		GenericFunctions.staticWait(3);

		// Calculate Schedule if it is in Red Color

		if (LoginObjects.checkRedSchedule()) {
			LoginObjects.schedule();
			GenericFunctions.staticWait(3);
		}
		else {
		    LoginObjects.clickSchedule();
		    GenericFunctions.staticWait(3);
				
		}
		GenericFunctions.checkAlert();
			    LoginObjects.Schedule_ProjectedEvent();
			}
} 
 
